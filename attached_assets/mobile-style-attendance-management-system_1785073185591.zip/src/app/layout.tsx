import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "تطبيق دوام الذكي (Enterprise AI Punch) • Mobile Card UI",
  description: "Enterprise Architecture Employee Attendance Management System with 3D Biometrics, Minute Calculations, AI Assistant, and Master Control Center. Zero tables, all touch card system.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-cyan-500 selection:text-slate-950">
        {children}
      </body>
    </html>
  );
}
