"use client";
import React, { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import MobileFrame from "@/components/MobileFrame";
import AuthModule from "@/components/AuthModule";
import DashboardModule from "@/components/DashboardModule";
import EmployeesModule from "@/components/EmployeesModule";
import AttendanceModule from "@/components/AttendanceModule";
import ShiftsModule from "@/components/ShiftsModule";
import LeavesModule from "@/components/LeavesModule";
import PayrollModule from "@/components/PayrollModule";
import ReportsModule from "@/components/ReportsModule";
import NotificationsModule from "@/components/NotificationsModule";
import AIEngineModule from "@/components/AIEngineModule";
import SecurityModule from "@/components/SecurityModule";
import SettingsModule from "@/components/SettingsModule";
import DatabaseModule from "@/components/DatabaseModule";
import SystemMasterMap from "@/components/SystemMasterMap";

import { Cpu } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState<
    "master_map" | "dashboard" | "auth" | "employees" | "attendance" | "shifts" | "leaves" | "payroll" | "reports" | "notifications" | "ai" | "security" | "settings" | "database"
  >("master_map");

  const [language, setLanguage] = useState<"ar" | "en">("ar");
  const [isMobileMode, setIsMobileMode] = useState<boolean>(false);
  const [clockMode, setClockMode] = useState<string>("3d_cyber");
  const [themeMode, setThemeMode] = useState<string>("dark_cyber");
  const [loading, setLoading] = useState<boolean>(true);

  const [systemData, setSystemData] = useState<any>({
    departments: [],
    employees: [],
    attendance: [],
    shifts: [],
    leaves: [],
    payrolls: [],
    notifications: [],
    aiAnalytics: [],
    faceRecognition: [],
    gpsTracking: [],
    settings: [],
  });

  const loadData = async () => {
    try {
      const res = await fetch("/api/init");
      const data = await res.json();
      if (data.status === "success" && data.data) {
        setSystemData(data.data);
        const clockSet = data.data.settings?.find((s: any) => s.settingKey === "clockType");
        if (clockSet) setClockMode(clockSet.settingValue);
        const langSet = data.data.settings?.find((s: any) => s.settingKey === "language");
        if (langSet) setLanguage(langSet.settingValue === "en" ? "en" : "ar");
      }
    } catch (err) {
      console.error("Failed to fetch initial data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleBiometricPunch = (method: string) => {
    loadData();
  };

  let themeClass = "bg-slate-950 text-slate-100";
  if (themeMode === "midnight") themeClass = "bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-950 text-purple-100";
  if (themeMode === "neon_emerald") themeClass = "bg-gradient-to-br from-slate-950 via-teal-950 to-emerald-950 text-emerald-100";
  if (themeMode === "light_elegance") themeClass = "bg-slate-100 text-slate-900";

  return (
    <div className={`min-h-screen ${themeClass} font-sans selection:bg-cyan-500 selection:text-black transition-colors duration-500 ${language === "ar" ? "dir-rtl text-right" : "dir-ltr text-left"}`} dir={language === "ar" ? "rtl" : "ltr"}>
      
      {/* Main Container: Flex Sidebar + Content Area */}
      <div className="flex w-full min-h-screen">
        {/* New Dedicated Sidebar Navigation replacing the bottom bar! */}
        <Sidebar
          language={language}
          activeTab={activeTab}
          onSelectTab={(t) => setActiveTab(t as any)}
          systemData={systemData}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-x-hidden">
          <Navbar
            language={language}
            onLanguageChange={(l) => setLanguage(l as any)}
            isMobileMode={isMobileMode}
            onToggleMobileMode={() => setIsMobileMode(!isMobileMode)}
            clockMode={clockMode}
            activeTab={activeTab}
            onSelectTab={(t) => setActiveTab(t as any)}
          />

          <main className="py-6 px-2 sm:px-4 lg:px-6 flex-1 mb-8">
            {loading ? (
              <div className="flex flex-col items-center justify-center min-h-[65vh] space-y-4">
                <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-indigo-500 via-purple-600 to-cyan-400 p-1 animate-spin">
                  <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center">
                    <Cpu className="w-8 h-8 text-cyan-400 animate-pulse" />
                  </div>
                </div>
                <p className="text-sm font-bold text-slate-300 font-mono tracking-wider animate-pulse">
                  {language === "ar" ? "جاري تهيئة مركز القيادة والمخطط الشامل (13 Roots & 170+ Leaves)..." : "Initializing Exact Enterprise Schema Matrix..."}
                </p>
              </div>
            ) : (
              <MobileFrame isMobileMode={isMobileMode} onToggleMode={() => setIsMobileMode(!isMobileMode)} language={language}>
                <div className="space-y-6">
                  {/* Active Module Rendering based on Sidebar selection */}
                  {activeTab === "master_map" && (
                    <SystemMasterMap language={language} onSelectModule={(m) => setActiveTab(m as any)} />
                  )}
                  {activeTab === "dashboard" && (
                    <DashboardModule language={language} data={systemData} onNavigate={(t) => setActiveTab(t as any)} />
                  )}
                  {activeTab === "attendance" && (
                    <AttendanceModule language={language} employees={systemData.employees} attendance={systemData.attendance} onRefresh={loadData} />
                  )}
                  {activeTab === "employees" && (
                    <EmployeesModule language={language} employees={systemData.employees} departments={systemData.departments} onRefresh={loadData} />
                  )}
                  {activeTab === "auth" && (
                    <AuthModule language={language} employees={systemData.employees} onBiometricPunch={handleBiometricPunch} />
                  )}
                  {activeTab === "ai" && (
                    <AIEngineModule language={language} aiAnalytics={systemData.aiAnalytics} employees={systemData.employees} />
                  )}
                  {activeTab === "payroll" && (
                    <PayrollModule language={language} payrolls={systemData.payrolls} employees={systemData.employees} onRefresh={loadData} />
                  )}
                  {activeTab === "leaves" && (
                    <LeavesModule language={language} leaves={systemData.leaves} employees={systemData.employees} onRefresh={loadData} />
                  )}
                  {activeTab === "shifts" && (
                    <ShiftsModule language={language} shifts={systemData.shifts} />
                  )}
                  {activeTab === "reports" && (
                    <ReportsModule language={language} data={systemData} />
                  )}
                  {activeTab === "notifications" && (
                    <NotificationsModule language={language} notifications={systemData.notifications} employees={systemData.employees} onRefresh={loadData} />
                  )}
                  {activeTab === "security" && (
                    <SecurityModule language={language} auditLogs={systemData.auditLogs || []} />
                  )}
                  {activeTab === "database" && (
                    <DatabaseModule language={language} data={systemData} onRefresh={loadData} />
                  )}
                  {activeTab === "settings" && (
                    <SettingsModule
                      language={language}
                      onLanguageChange={(l) => setLanguage(l as any)}
                      onClockModeChange={(m) => setClockMode(m)}
                      onThemeChange={(thm) => setThemeMode(thm)}
                    />
                  )}
                </div>
              </MobileFrame>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
