import { NextResponse } from "next/server";
import { db } from "@/db";
import { leaves, notifications, employees } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, leaveId, employeeId, leaveType, startDate, endDate, daysCount, reason } = body;

    if (action === "create") {
      const emp = await db.select().from(employees).where(eq(employees.id, Number(employeeId)));
      const [newLeave] = await db.insert(leaves).values({
        employeeId: Number(employeeId),
        leaveType: leaveType || "Annual Leave",
        startDate: startDate || new Date().toISOString().split("T")[0],
        endDate: endDate || new Date().toISOString().split("T")[0],
        daysCount: Number(daysCount) || 3,
        reason: reason || "طلب إجازة عبر النظام الذكي",
        status: "Approved",
        approvalWorkflowStep: "تم الاعتماد آلياً بواسطة AI Workflow & Manager",
        remainingBalance: 18,
      }).returning();

      if (emp.length > 0) {
        await db.insert(notifications).values({
          channel: "Push Notifications",
          title: "اعتماد طلب الإجازة (Leave Approved)",
          message: `تم اعتماد إجازة (${leaveType}) للموظف ${emp[0].fullNameAr} بنجاح وحفظ الرصيد المتبقي.`,
          recipientName: emp[0].fullNameAr,
          recipientPhoneOrEmail: emp[0].phone || "hr@enterprise.ai",
          status: "Delivered",
          isRead: false,
        });
      }

      return NextResponse.json({ status: "success", message: "تم إدراج واعتماد الإجازة بنجاح.", leave: newLeave });
    } else if (action === "status" && leaveId) {
      const { status, step } = body;
      const [upd] = await db.update(leaves)
        .set({ 
          status: status || "Approved",
          approvalWorkflowStep: step || "موافق عليه من قبل مدير القسم والموارد البشرية"
        })
        .where(eq(leaves.id, Number(leaveId)))
        .returning();
      return NextResponse.json({ status: "success", message: `تم تبيين حالة الإجازة إلى ${status}`, leave: upd });
    }

    return NextResponse.json({ status: "error", message: "Invalid action parameters" }, { status: 400 });
  } catch (err: any) {
    console.error("Leaves Action Error:", err);
    return NextResponse.json({ status: "error", message: err?.message || "Internal server error" }, { status: 500 });
  }
}
