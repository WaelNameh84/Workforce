import { NextResponse } from "next/server";
import { db } from "@/db";
import { systemSettings } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { updates } = body; 
    // updates is an array of { category, settingKey, settingValue }

    if (!updates || !Array.isArray(updates)) {
      return NextResponse.json({ status: "error", message: "Invalid updates payload" }, { status: 400 });
    }

    const updatedResults = [];
    for (const item of updates) {
      if (item.settingKey) {
        // Find existing setting
        const existing = await db.select().from(systemSettings).where(
          and(
            eq(systemSettings.settingKey, item.settingKey),
            item.category ? eq(systemSettings.category, item.category) : undefined
          )
        );

        if (existing.length > 0) {
          const [upd] = await db.update(systemSettings)
            .set({ settingValue: String(item.settingValue) })
            .where(eq(systemSettings.id, existing[0].id))
            .returning();
          updatedResults.push(upd);
        } else {
          const [ins] = await db.insert(systemSettings).values({
            category: item.category || "general",
            settingKey: item.settingKey,
            settingValue: String(item.settingValue),
            description: item.description || "Custom setting from MCC",
          }).returning();
          updatedResults.push(ins);
        }
      }
    }

    return NextResponse.json({
      status: "success",
      message: "تم تحديث إعدادات النظام ومركز التحكم المتقدم بنجاح.",
      data: updatedResults
    });
  } catch (err: any) {
    console.error("Settings Update Error:", err);
    return NextResponse.json({ status: "error", message: err?.message || "Error updating settings" }, { status: 500 });
  }
}
