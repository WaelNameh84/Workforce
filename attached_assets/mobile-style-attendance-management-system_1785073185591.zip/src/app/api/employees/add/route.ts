import { NextResponse } from "next/server";
import { db } from "@/db";
import { employees } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { 
      id, fullNameAr, fullNameEn, email, phone, position, 
      contractType, basicSalary, departmentId, status,
      assignedWifiSsid, assignedLatitude, assignedLongitude,
      emergencyContactName, emergencyContactPhone, emergencyContactRelation
    } = body;

    const bVal = Number(basicSalary) || 5000;
    const daily = bVal / 25;
    const hourly = daily / 8;

    if (id) {
      // Update employee
      const [upd] = await db.update(employees).set({
        fullNameAr: fullNameAr || undefined,
        fullNameEn: fullNameEn || undefined,
        email: email || undefined,
        phone: phone || undefined,
        position: position || undefined,
        contractType: contractType || "Full-Time",
        basicSalary: bVal,
        dailyWage: daily,
        hourlyWage: hourly,
        departmentId: Number(departmentId) || undefined,
        status: status || "Active",
        assignedWifiSsid: assignedWifiSsid || "Corporate_HQ_5G",
        emergencyContactName: emergencyContactName || undefined,
        emergencyContactPhone: emergencyContactPhone || undefined,
        emergencyContactRelation: emergencyContactRelation || undefined,
      }).where(eq(employees.id, Number(id))).returning();

      return NextResponse.json({ status: "success", message: "تم تحديث بيانات ملف الموظف الرقمي بنجاح.", employee: upd });
    } else {
      // Create employee
      const [ins] = await db.insert(employees).values({
        employeeNumber: `EMP-${9000 + Math.floor(Math.random() * 900)}`,
        fullNameAr: fullNameAr || "موظف جديد",
        fullNameEn: fullNameEn || "New Employee",
        email: email || `emp.${Date.now()}@enterprise.ai`,
        phone: phone || "+966 50 000 0000",
        avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=250&auto=format&fit=crop&q=80",
        departmentId: Number(departmentId) || 1,
        position: position || "أخصائي تطوير مالي وإداري",
        contractType: contractType || "Full-Time",
        basicSalary: bVal,
        dailyWage: daily,
        hourlyWage: hourly,
        hireDate: new Date().toISOString().split("T")[0],
        status: status || "Active",
        assignedWifiSsid: assignedWifiSsid || "Corporate_HQ_5G",
        assignedLatitude: Number(assignedLatitude) || 24.7136,
        assignedLongitude: Number(assignedLongitude) || 46.6753,
        emergencyContactName: emergencyContactName || "غير محدد",
        emergencyContactPhone: emergencyContactPhone || "+966500000000",
        emergencyContactRelation: emergencyContactRelation || "Relative",
        documentsList: [{ id: 1, title: "عقد عمل أولي", type: "Contract", status: "Verified", date: new Date().toISOString().split("T")[0] }],
        certificatesList: [],
      }).returning();

      return NextResponse.json({ status: "success", message: "تم تسجيل وإدراج الموظف المؤسسي بنجاح في قاعدة البيانات.", employee: ins });
    }
  } catch (err: any) {
    console.error("Employee Action Error:", err);
    return NextResponse.json({ status: "error", message: err?.message || "Internal server error" }, { status: 500 });
  }
}
