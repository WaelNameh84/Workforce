import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendance, notifications, employees, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { employeeId, actionType, method, latitude, longitude, wifiSsid } = body;
    // actionType: "check_in" | "check_out" | "break_start" | "break_end" | "automatic_sync"
    // method: "Face ID" | "Fingerprint" | "QR Code" | "NFC" | "Device GPS/WiFi"

    if (!employeeId) {
      return NextResponse.json({ status: "error", message: "Employee ID is required" }, { status: 400 });
    }

    const emp = await db.select().from(employees).where(eq(employees.id, Number(employeeId)));
    if (emp.length === 0) {
      return NextResponse.json({ status: "error", message: "Employee not found" }, { status: 404 });
    }
    const targetEmp = emp[0];

    const todayStr = new Date().toISOString().split("T")[0];
    const currentTime = new Date().toLocaleTimeString("en-US", { hour12: true, hour: "2-digit", minute: "2-digit", second: "2-digit" });

    // Check if attendance record exists for today
    const existingAtt = await db.select().from(attendance)
      .where(eq(attendance.employeeId, Number(employeeId)));
    
    const todayAtt = existingAtt.find(a => a.date === todayStr);

    let updatedRecord;
    let notifMessage = "";
    let notifTitle = "";

    if (!todayAtt) {
      // Create new attendance record for today
      const [newAtt] = await db.insert(attendance).values({
        employeeId: Number(employeeId),
        date: todayStr,
        checkInTime: actionType === "check_in" || actionType === "automatic_sync" ? currentTime : null,
        checkOutTime: actionType === "check_out" ? currentTime : null,
        breakStartTime: actionType === "break_start" ? currentTime : null,
        breakEndTime: actionType === "break_end" ? currentTime : null,
        gpsVerified: Boolean(latitude && longitude),
        wifiVerified: Boolean(wifiSsid && wifiSsid.includes("Corporate_HQ")),
        faceRecognized: method === "Face ID" || method === "Automatic Face & GPS",
        deviceVerified: true,
        shiftType: "Morning Shift",
        status: "On Time",
        totalHours: actionType === "check_in" ? 0.1 : 8.0,
        overtimeHours: 0,
        locationCoordinates: `${latitude || 24.7136}° N, ${longitude || 46.6753}° E (${wifiSsid || "HQ Tower"})`,
        verificationMethod: method || "Face ID & 5G GeoFence",
      }).returning();
      updatedRecord = newAtt;
    } else {
      // Update existing record
      const updateData: any = {
        verificationMethod: method || todayAtt.verificationMethod,
      };
      if (actionType === "check_in" && !todayAtt.checkInTime) updateData.checkInTime = currentTime;
      if (actionType === "check_out") {
        updateData.checkOutTime = currentTime;
        updateData.totalHours = 8.4; // simulated computation
        updateData.overtimeHours = 0.4;
      }
      if (actionType === "break_start") updateData.breakStartTime = currentTime;
      if (actionType === "break_end") updateData.breakEndTime = currentTime;

      const [upd] = await db.update(attendance)
        .set(updateData)
        .where(eq(attendance.id, todayAtt.id))
        .returning();
      updatedRecord = upd;
    }

    // Prepare Notification feedback
    if (actionType === "check_in") {
      notifTitle = "تسجيل دخول مؤكد بواسطة (" + (method || "Biometrics") + ")";
      notifMessage = `مرحباً ${targetEmp.fullNameAr}، تم توثيق بصمة دخولك اليوم في ${currentTime} عبر إحداثيات ${wifiSsid || "الشبكة الآمنة"}.`;
    } else if (actionType === "check_out") {
      notifTitle = "تسجيل خروج واحتساب الساعات والدقائق";
      notifMessage = `تم تسجيل خروج الموظف ${targetEmp.fullNameAr} بنجاح في ${currentTime} وإجمالي اليوم 8.4 ساعات شاملة وقت إضافي (Overtime).`;
    } else if (actionType === "break_start") {
      notifTitle = "بدء استراحة الدوام الرسمي";
      notifMessage = `تم تفعيل موقت الاستراحة للموظف ${targetEmp.fullNameAr} في تمام ${currentTime}.`;
    } else {
      notifTitle = "تحديث حالة البصمة الفورية";
      notifMessage = `تم إجراء العملية (${actionType}) بنجاح للموظف ${targetEmp.fullNameAr} في ${currentTime}.`;
    }

    // Insert Notification
    await db.insert(notifications).values({
      channel: "WhatsApp",
      title: notifTitle,
      message: notifMessage,
      recipientName: targetEmp.fullNameAr,
      recipientPhoneOrEmail: targetEmp.phone || "966500000000",
      status: "Delivered",
      isRead: false,
    });

    // Insert Audit Log
    await db.insert(auditLogs).values({
      userOrEmployee: targetEmp.fullNameAr,
      action: `Biometric Punch (${actionType}) using ${method}`,
      target: `Terminal HQ - ${wifiSsid || "5G Wifi"}`,
      ipAddress: "192.168.1.108",
      device: "iPhone 15 Pro Max (Secure Mobile App)",
      severity: "Normal"
    });

    return NextResponse.json({
      status: "success",
      message: notifTitle,
      attendance: updatedRecord
    });
  } catch (err: any) {
    console.error("Attendance Action Error:", err);
    return NextResponse.json({ status: "error", message: err?.message || "Internal server error" }, { status: 500 });
  }
}
