import { NextResponse } from "next/server";
import { db } from "@/db";
import { payroll, employees, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { employeeId, monthYear, bonuses, deductions, overtimeHours } = body;

    const emp = await db.select().from(employees).where(eq(employees.id, Number(employeeId)));
    if (emp.length === 0) {
      return NextResponse.json({ status: "error", message: "Employee not found" }, { status: 404 });
    }
    const e = emp[0];

    const basic = e.basicSalary || 5000;
    const daily = e.dailyWage || (basic / 25);
    const hourly = e.hourlyWage || (daily / 8);
    const minuteRate = hourly / 60;

    const ovPay = Number(overtimeHours || 0) * (hourly * 1.5); // 150% overtime pay
    const bon = Number(bonuses) || 1200;
    const ded = Number(deductions) || 0;
    const insurance = Math.round(basic * 0.05); // 5% GOSI/Insurance
    const tax = Math.round(basic * 0.0); // 0% tax for local employees

    // Minute Calculation simulation (e.g., worked 160 hours = 9600 minutes)
    const minutesWorked = 9600 + Math.round((Number(overtimeHours || 0) * 60));
    const finalSal = Math.round(basic + ovPay + bon - ded - insurance - tax);

    const targetMonth = monthYear || "April 2026";
    const payslipId = `PAY-${targetMonth.replace(/\s+/g, "").toUpperCase()}-${e.employeeNumber}`;

    const [newPay] = await db.insert(payroll).values({
      employeeId: e.id,
      monthYear: targetMonth,
      basicSalary: basic,
      dailyWage: daily,
      hourlyWage: hourly,
      minutesWorked: minutesWorked,
      overtimePay: Math.round(ovPay),
      bonuses: bon,
      deductions: ded,
      taxAmount: tax,
      insuranceAmount: insurance,
      finalSalary: finalSal,
      status: "Paid",
      paymentDate: new Date().toISOString().split("T")[0],
      payslipId: payslipId,
    }).returning();

    // Send payslip notification
    await db.insert(notifications).values({
      channel: "Email",
      title: `قسيمة راتب شهر ${targetMonth} (Payslip Issued)`,
      message: `تم إصدار وتوثيق كشف حساب الراتب للموظف ${e.fullNameAr} بقيمة صارمة ${finalSal.toLocaleString()} ريال، مع إمكانية التحميل الفوري بصيغة PDF.`,
      recipientName: e.fullNameAr,
      recipientPhoneOrEmail: e.email || "employee@enterprise.ai",
      status: "Delivered",
      isRead: false,
    });

    return NextResponse.json({
      status: "success",
      message: `تم احتساب وإصدار الراتب النهائي (${finalSal.toLocaleString()} ريال) وقسيمة PDF للموظف بنجاح.`,
      payroll: newPay,
      minuteCalculationDetails: {
        minuteRate: minuteRate.toFixed(2),
        totalMinutesWorked: minutesWorked,
        overtimeMinutes: Number(overtimeHours || 0) * 60,
      }
    });
  } catch (err: any) {
    console.error("Payroll Generate Error:", err);
    return NextResponse.json({ status: "error", message: err?.message || "Internal server error" }, { status: 500 });
  }
}
