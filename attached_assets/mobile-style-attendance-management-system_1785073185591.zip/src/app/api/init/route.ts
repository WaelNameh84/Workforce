import { NextResponse } from "next/server";
import { db } from "@/db";
import { 
  users, departments, employees, attendance, shifts, leaves, 
  payroll, schedules, documents, notifications, auditLogs, 
  aiAnalytics, faceRecognition, gpsTracking, systemSettings 
} from "@/db/schema";

export async function GET() {
  try {
    // Check if seeded
    const existingDepts = await db.select().from(departments);
    if (existingDepts.length === 0) {
      // Seed Departments
      const insertedDepts = await db.insert(departments).values([
        {
          nameAr: "الإدارة التخصصية والقيادة (HQ Executive)",
          nameEn: "HQ Executive Leadership",
          code: "EXC-01",
          managerName: "طارق المنصور",
          headCount: 4,
          budget: 1200000,
          icon: "ShieldAlert",
          colorBadge: "purple",
          description: "الإدارة العليا لمركز القيادة والتوجيه الاستراتيجي للتطبيقات والشؤون الهندسية.",
        },
        {
          nameAr: "الذكاء الاصطناعي وهندسة البيانات (AI & Data)",
          nameEn: "AI & Data Engineering",
          code: "AIE-02",
          managerName: "سارة العتيبي",
          headCount: 12,
          budget: 2500000,
          icon: "Cpu",
          colorBadge: "cyan",
          description: "مركز تطوير النماذج الذكية التنبؤية وكشف الاحتيال البيومترى وإدراك الوجوه.",
        },
        {
          nameAr: "هندسة البرمجيات والأنظمة (Software Eng)",
          nameEn: "Software & Cloud Systems",
          code: "ENG-03",
          managerName: "خالد الغامدي",
          headCount: 18,
          budget: 3100000,
          icon: "Code2",
          colorBadge: "indigo",
          description: "فئة التطوير المتقدم وتطبيق أنظمة التتبع عبر الأجهزة المحمولة والحوسبة الحيوية.",
        },
        {
          nameAr: "الموارد البشرية والشؤون الأمنية (HR & Security)",
          nameEn: "Human Resources & Security",
          code: "HRS-04",
          managerName: "ريناد الشمري",
          headCount: 7,
          budget: 980000,
          icon: "Users2",
          colorBadge: "rose",
          description: "إدارة العقود، التوثيق، الإجازات ومراجعة امتثال الصدقات الأمنية للشركات.",
        },
        {
          nameAr: "التسويق وتجربة العلاء (Customer Exp)",
          nameEn: "Marketing & Growth",
          code: "MKT-05",
          managerName: "عمر القحطاني",
          headCount: 9,
          budget: 850000,
          icon: "Sparkles",
          colorBadge: "amber",
          description: "التأكد من التفاعل والمجتمع الوظيفي وتجربة المستخدم ونشر التقارير الرقمية.",
        },
      ]).returning();

      // Seed Employees
      const insertedEmps = await db.insert(employees).values([
        {
          employeeNumber: "EMP-9001",
          fullNameAr: "طارق المنصور",
          fullNameEn: "Tariq Al-Mansour",
          email: "tariq.mansour@enterprise.ai",
          phone: "+966 50 123 4567",
          avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=250&auto=format&fit=crop&q=80",
          departmentId: insertedDepts[0].id,
          position: "الرئيس التنفيذي للأنظمة (Chief Systems Officer)",
          contractType: "Full-Time",
          basicSalary: 32000,
          dailyWage: 1280,
          hourlyWage: 160,
          hireDate: "2022-01-15",
          status: "Active",
          assignedWifiSsid: "Corporate_HQ_5G_VIP",
          assignedLatitude: 24.7136,
          assignedLongitude: 46.6753,
          emergencyContactName: "عبدالعزيز المنصور",
          emergencyContactPhone: "+966 55 987 6543",
          emergencyContactRelation: "Brother",
          documentsList: [
            { id: 1, title: "عقد العمل المؤسسي الدائم", type: "Employment Contract", status: "Verified", date: "2022-01-15" },
            { id: 2, title: "الهوية الوطنية الرقمية (NFC Bound)", type: "ID Card", status: "Verified", date: "2023-05-10" },
          ],
          certificatesList: [
            { title: "Enterprise Architecture Cert (TOGAF)", issuer: "The Open Group", year: "2023" },
            { title: "Executive AI Security Strategy", issuer: "MIT Sloane", year: "2024" }
          ],
          employmentHistory: [
            { role: "Senior Director", company: "Saudi Tech Vanguard", period: "2018 - 2021" }
          ],
        },
        {
          employeeNumber: "EMP-9002",
          fullNameAr: "سارة العتيبي",
          fullNameEn: "Sarah Al-Otaibi",
          email: "sarah.otaibi@enterprise.ai",
          phone: "+966 54 444 3322",
          avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=250&auto=format&fit=crop&q=80",
          departmentId: insertedDepts[1].id,
          position: "كبير مهندسي ذكاء التموضع والقياس (Principal AI Lead)",
          contractType: "Full-Time",
          basicSalary: 28500,
          dailyWage: 1140,
          hourlyWage: 142.5,
          hireDate: "2023-03-01",
          status: "Active",
          assignedWifiSsid: "Corporate_HQ_5G_AI",
          assignedLatitude: 24.7142,
          assignedLongitude: 46.6761,
          emergencyContactName: "نورة العتيبي",
          emergencyContactPhone: "+966 56 112 2334",
          emergencyContactRelation: "Sister",
          documentsList: [
            { id: 1, title: "عقد قيادي في الذكاء الاصطناعي", type: "Contract", status: "Verified", date: "2023-03-01" }
          ],
          certificatesList: [
            { title: "Deep Learning & Biometrics Specialization", issuer: "Stanford Online", year: "2023" }
          ],
        },
        {
          employeeNumber: "EMP-9003",
          fullNameAr: "خالد الغامدي",
          fullNameEn: "Khalid Al-Ghamdi",
          email: "khalid.ghamdi@enterprise.ai",
          phone: "+966 59 888 7766",
          avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=250&auto=format&fit=crop&q=80",
          departmentId: insertedDepts[2].id,
          position: "مهندس واجهات وأنظمة مدمجة (Staff Mobile Engineer)",
          contractType: "Full-Time",
          basicSalary: 24000,
          dailyWage: 960,
          hourlyWage: 120,
          hireDate: "2023-06-10",
          status: "Active",
          assignedWifiSsid: "Corporate_HQ_5G",
          assignedLatitude: 24.7136,
          assignedLongitude: 46.6753,
          emergencyContactName: "فهد الغامدي",
          emergencyContactPhone: "+966 50 333 9988",
          emergencyContactRelation: "Father",
        },
        {
          employeeNumber: "EMP-9004",
          fullNameAr: "ريناد الشمري",
          fullNameEn: "Reenad Al-Shammari",
          email: "reenad.shammari@enterprise.ai",
          phone: "+966 53 777 6655",
          avatarUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=250&auto=format&fit=crop&q=80",
          departmentId: insertedDepts[3].id,
          position: "مديرة التدقيق الأمني والموارد (HR & Compliance Manager)",
          contractType: "Full-Time",
          basicSalary: 22000,
          dailyWage: 880,
          hourlyWage: 110,
          hireDate: "2022-09-01",
          status: "Active",
          assignedWifiSsid: "Corporate_HQ_5G",
          assignedLatitude: 24.7136,
          assignedLongitude: 46.6753,
          emergencyContactName: "فيصل الشمري",
          emergencyContactPhone: "+966 58 222 3344",
          emergencyContactRelation: "Spouse",
        },
        {
          employeeNumber: "EMP-9005",
          fullNameAr: "عمر القحطاني",
          fullNameEn: "Omar Al-Qahtani",
          email: "omar.qahtani@enterprise.ai",
          phone: "+966 55 555 4433",
          avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=250&auto=format&fit=crop&q=80",
          departmentId: insertedDepts[4].id,
          position: "مدير تجربة الابتكار والنمو (Head of Growth & UX)",
          contractType: "Flexible",
          basicSalary: 19500,
          dailyWage: 780,
          hourlyWage: 97.5,
          hireDate: "2024-01-05",
          status: "Active",
          assignedWifiSsid: "Corporate_HQ_5G",
          assignedLatitude: 24.7136,
          assignedLongitude: 46.6753,
          emergencyContactName: "محمد القحطاني",
          emergencyContactPhone: "+966 55 123 7890",
          emergencyContactRelation: "Brother",
        },
        {
          employeeNumber: "EMP-9006",
          fullNameAr: "ليلى الزهراني",
          fullNameEn: "Layla Al-Zahrani",
          email: "layla.zahrani@enterprise.ai",
          phone: "+966 56 999 1111",
          avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=250&auto=format&fit=crop&q=80",
          departmentId: insertedDepts[1].id,
          position: "عالمة بيانات ونظم الرصد التلقائي (Data Scientist)",
          contractType: "Remote",
          basicSalary: 21000,
          dailyWage: 840,
          hourlyWage: 105,
          hireDate: "2024-02-15",
          status: "Active",
          assignedWifiSsid: "Home_Fiber_GHz",
          assignedLatitude: 21.4858,
          assignedLongitude: 39.1925, // Jeddah
        }
      ]).returning();

      // Seed Shifts
      await db.insert(shifts).values([
        {
          name: "الوردية الصباحية المباشرة (Morning Shift)",
          startTime: "08:00",
          endTime: "16:00",
          graceMinutes: 15,
          isFlexible: false,
          workDays: ["Sun", "Mon", "Tue", "Wed", "Thu"],
          shiftType: "Morning Shift",
          color: "indigo",
        },
        {
          name: "الوردية المسائية الديناميكية (Evening Shift)",
          startTime: "14:00",
          endTime: "22:00",
          graceMinutes: 20,
          isFlexible: false,
          workDays: ["Sun", "Mon", "Tue", "Wed", "Thu"],
          shiftType: "Evening Shift",
          color: "amber",
        },
        {
          name: "وردية الطوارئ والمراقبة الليلية (Night Shift)",
          startTime: "22:00",
          endTime: "06:00",
          graceMinutes: 10,
          isFlexible: false,
          workDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
          shiftType: "Night Shift",
          color: "purple",
        },
        {
          name: "الدوام المرن الذاتي (Flexible Shift)",
          startTime: "07:00",
          endTime: "19:00",
          graceMinutes: 60,
          isFlexible: true,
          workDays: ["Sun", "Mon", "Tue", "Wed", "Thu"],
          shiftType: "Flexible Shift",
          color: "emerald",
        },
        {
          name: "جدول التناوب المؤسسي (Rotation Schedule A/B)",
          startTime: "09:00",
          endTime: "17:00",
          graceMinutes: 30,
          isFlexible: true,
          workDays: ["Sun", "Tue", "Thu"],
          shiftType: "Rotation Schedule",
          color: "rose",
        },
      ]);

      // Seed Attendance for Today and Yesterday
      const todayStr = new Date().toISOString().split("T")[0];
      await db.insert(attendance).values([
        {
          employeeId: insertedEmps[0].id,
          date: todayStr,
          checkInTime: "07:52:14 AM",
          checkOutTime: null,
          breakStartTime: "12:15:00 PM",
          breakEndTime: "01:00:00 PM",
          gpsVerified: true,
          wifiVerified: true,
          faceRecognized: true,
          deviceVerified: true,
          shiftType: "Morning Shift",
          status: "On Time",
          totalHours: 5.5,
          overtimeHours: 0,
          locationCoordinates: "24.7136° N, 46.6753° E (HQ Tower)",
          verificationMethod: "Face ID & 5G GeoFence",
        },
        {
          employeeId: insertedEmps[1].id,
          date: todayStr,
          checkInTime: "07:58:30 AM",
          checkOutTime: null,
          breakStartTime: null,
          breakEndTime: null,
          gpsVerified: true,
          wifiVerified: true,
          faceRecognized: true,
          deviceVerified: true,
          shiftType: "Morning Shift",
          status: "On Time",
          totalHours: 6.2,
          overtimeHours: 0.5,
          locationCoordinates: "24.7142° N, 46.6761° E (AI Labs)",
          verificationMethod: "Face Recognition 3D",
        },
        {
          employeeId: insertedEmps[2].id,
          date: todayStr,
          checkInTime: "08:24:10 AM",
          checkOutTime: null,
          breakStartTime: "12:30:00 PM",
          breakEndTime: "01:15:00 PM",
          gpsVerified: true,
          wifiVerified: true,
          faceRecognized: false,
          deviceVerified: true,
          shiftType: "Morning Shift",
          status: "Late",
          totalHours: 5.1,
          overtimeHours: 0,
          locationCoordinates: "24.7136° N, 46.6753° E (Engineering Wing)",
          verificationMethod: "Fingerprint & NFC",
        },
        {
          employeeId: insertedEmps[3].id,
          date: todayStr,
          checkInTime: "08:05:00 AM",
          checkOutTime: "04:30:00 PM",
          breakStartTime: "01:00:00 PM",
          breakEndTime: "02:00:00 PM",
          gpsVerified: true,
          wifiVerified: true,
          faceRecognized: true,
          deviceVerified: true,
          shiftType: "Morning Shift",
          status: "On Time",
          totalHours: 8.5,
          overtimeHours: 0.5,
          locationCoordinates: "24.7136° N, 46.6753° E (HR Office)",
          verificationMethod: "QR Code Scan & Device Token",
        },
        {
          employeeId: insertedEmps[4].id,
          date: todayStr,
          checkInTime: "09:15:20 AM",
          checkOutTime: null,
          breakStartTime: null,
          breakEndTime: null,
          gpsVerified: true,
          wifiVerified: false,
          faceRecognized: true,
          deviceVerified: true,
          shiftType: "Flexible Shift",
          status: "On Time",
          totalHours: 4.8,
          overtimeHours: 0,
          locationCoordinates: "24.7180° N, 46.6800° E (Client On-Site)",
          verificationMethod: "GPS Geofencing Only",
        },
      ]);

      // Seed Leaves
      await db.insert(leaves).values([
        {
          employeeId: insertedEmps[2].id,
          leaveType: "Annual Leave (إجازة سنوية رصيد)",
          startDate: "2026-04-10",
          endDate: "2026-04-24",
          daysCount: 14,
          reason: "إجازة سفر عائلي وسياحة سنوية.",
          status: "Approved",
          approvalWorkflowStep: "معتمد النهائي (HR Director & AI Verified)",
          remainingBalance: 16,
        },
        {
          employeeId: insertedEmps[4].id,
          leaveType: "Sick Leave (إجازة مرضية مبررة)",
          startDate: "2026-03-02",
          endDate: "2026-03-04",
          daysCount: 3,
          reason: "وعكة صحية وإرفاق تقرير منصة صحتي الإلكتروني.",
          status: "Approved",
          approvalWorkflowStep: "معتمد تلقائي بواسطة (AI Engine Health Sync)",
          remainingBalance: 28,
        },
        {
          employeeId: insertedEmps[1].id,
          leaveType: "Emergency Leave (إجازة طارئة مستعجلة)",
          startDate: "2026-03-25",
          endDate: "2026-03-26",
          daysCount: 2,
          reason: "ظرف عائلي طارئ يتطلب التفرغ المؤقت.",
          status: "Pending",
          approvalWorkflowStep: "قيد المراجعة في مكتب القيادة التنفيذية",
          remainingBalance: 21,
        }
      ]);

      // Seed Payrolls
      await db.insert(payroll).values([
        {
          employeeId: insertedEmps[0].id,
          monthYear: "March 2026",
          basicSalary: 32000,
          dailyWage: 1280,
          hourlyWage: 160,
          minutesWorked: 9850, // extra minutes!
          overtimePay: 1440,
          bonuses: 3500,
          deductions: 0,
          taxAmount: 0,
          insuranceAmount: 1600,
          finalSalary: 35340,
          status: "Paid",
          paymentDate: "2026-03-27",
          payslipId: "PAY-2026-03-9001",
        },
        {
          employeeId: insertedEmps[1].id,
          monthYear: "March 2026",
          basicSalary: 28500,
          dailyWage: 1140,
          hourlyWage: 142.5,
          minutesWorked: 9700,
          overtimePay: 950,
          bonuses: 2500,
          deductions: 0,
          taxAmount: 0,
          insuranceAmount: 1425,
          finalSalary: 30525,
          status: "Paid",
          paymentDate: "2026-03-27",
          payslipId: "PAY-2026-03-9002",
        },
        {
          employeeId: insertedEmps[2].id,
          monthYear: "March 2026",
          basicSalary: 24000,
          dailyWage: 960,
          hourlyWage: 120,
          minutesWorked: 9400, // slightly less due to lateness
          overtimePay: 0,
          bonuses: 1000,
          deductions: 350, // Late arriving reduction
          taxAmount: 0,
          insuranceAmount: 1200,
          finalSalary: 23450,
          status: "Pending Approval",
          paymentDate: "2026-03-28",
          payslipId: "PAY-2026-03-9003",
        },
        {
          employeeId: insertedEmps[3].id,
          monthYear: "March 2026",
          basicSalary: 22000,
          dailyWage: 880,
          hourlyWage: 110,
          minutesWorked: 9600,
          overtimePay: 600,
          bonuses: 1500,
          deductions: 0,
          taxAmount: 0,
          insuranceAmount: 1100,
          finalSalary: 23000,
          status: "Paid",
          paymentDate: "2026-03-27",
          payslipId: "PAY-2026-03-9004",
        }
      ]);

      // Seed Notifications
      await db.insert(notifications).values([
        {
          channel: "WhatsApp",
          title: "تأكيد بصمة الدخول الصباحي (Verified Check-In)",
          message: "مرحباً طارق، تم تسجيل دخولك بنجاح في الساعة 07:52 AM باستخدام تقنية التعرف على الوجه ثلاثي الأبعاد Face ID وإحداثيات برج القيادة.",
          recipientName: "طارق المنصور",
          recipientPhoneOrEmail: "+966501234567",
          status: "Delivered",
          isRead: true,
        },
        {
          channel: "Push Notifications",
          title: "تنبيه ذكاء اصطناعي: تأخر طفيف",
          message: "تنبيه للنظام: الموظف خالد الغامدي سجل الدخول متأخراً بمقدار 24 دقيقة في الوردية الصباحية اليوم.",
          recipientName: "مكتب الموارد البشرية (HR)",
          recipientPhoneOrEmail: "hr@enterprise.ai",
          status: "Delivered",
          isRead: false,
        },
        {
          channel: "Email",
          title: "إشعار صدور كشف الراتب الإلكتروني (Payslip Generated)",
          message: "تم إصدار قسيمة راتب شهر مارس 2026 بنجاح. يمكنك الآن استعراض وتحميل قسيمة PDF بملف الراتب النهائي عبر تطبيق الجوال والويب.",
          recipientName: "سارة العتيبي",
          recipientPhoneOrEmail: "sarah.otaibi@enterprise.ai",
          status: "Delivered",
          isRead: true,
        },
        {
          channel: "SMS",
          title: "مصادقة ثنائية ناجحة (2FA Security)",
          message: "تم التحقق من بصمة جهاز iPhone 15 Pro Max الخاص بك كجهاز موثوق لنظام البصمة في نطاق WiFi الشركة.",
          recipientName: "عمر القحطاني",
          recipientPhoneOrEmail: "+966555554433",
          status: "Delivered",
          isRead: true,
        },
      ]);

      // Seed AI Analytics
      await db.insert(aiAnalytics).values([
        {
          employeeId: insertedEmps[0].id,
          attendancePredictionScore: 99.8,
          fraudDetectionRisk: "Low (0.02% Risk - Safe)",
          faceMatchingConfidence: 99.9,
          productivityScore: 98.4,
          performanceSummary: "أداء استثنائي وانضباط كامل في التوقيت والإنتاجية القيادية.",
          smartRecommendations: "ترشيح متجدد لمكافأة القيادة الابتكارية للربع الحالي.",
        },
        {
          employeeId: insertedEmps[1].id,
          attendancePredictionScore: 98.2,
          fraudDetectionRisk: "Low (0.05% Risk - Safe)",
          faceMatchingConfidence: 99.7,
          productivityScore: 97.1,
          performanceSummary: "التزام فني عالي المستوى وإدارة فعالة لنطاقات الذكاء الاصطناعي.",
          smartRecommendations: "إتاحة ساعة مرونة يومية إضافية لإنجازاتها الفائقة في البحث التمهيدي.",
        },
        {
          employeeId: insertedEmps[2].id,
          attendancePredictionScore: 88.4,
          fraudDetectionRisk: "Low-Med (3.4% Lateness Risk)",
          faceMatchingConfidence: 96.2,
          productivityScore: 89.0,
          performanceSummary: "كفاءة برمجية ممتازة مع ملاحظة تكرر التأخر الصباحي بنسبة 4% هذا الشهر.",
          smartRecommendations: "اقتراح تحويل الموظف إلى الوردية المرنة لتطابق طبيعة مهامه التطويرية.",
        },
      ]);

      // Seed Face Recognition
      await db.insert(faceRecognition).values([
        {
          employeeId: insertedEmps[0].id,
          biometricTemplateHash: "SHA256:8f4c9c22e038d8f99e2a8904711f5d6a2f3a61bc",
          lastMatchedConfidence: 99.9,
          status: "Verified 3D Neural Map",
          photoSnapshotUrl: insertedEmps[0].avatarUrl,
        },
        {
          employeeId: insertedEmps[1].id,
          biometricTemplateHash: "SHA256:4d8a221b339fe51f86b68a44b593fa8802d091cd",
          lastMatchedConfidence: 99.7,
          status: "Verified 3D Neural Map",
          photoSnapshotUrl: insertedEmps[1].avatarUrl,
        },
      ]);

      // Seed GPS Tracking
      await db.insert(gpsTracking).values([
        {
          employeeId: insertedEmps[0].id,
          locationName: "المركز الرئيسي - برج الابتكار الرياض (HQ Tower)",
          latitude: 24.7136,
          longitude: 46.6753,
          accuracyMeters: 2.1,
          isWithinGeofence: true,
        },
        {
          employeeId: insertedEmps[1].id,
          locationName: "مختبرات الحوسبة فائقة السرعة (AI Campus)",
          latitude: 24.7142,
          longitude: 46.6761,
          accuracyMeters: 1.8,
          isWithinGeofence: true,
        },
      ]);

      // Seed System Settings (Master Control Center)
      await db.insert(systemSettings).values([
        // General
        { category: "general", settingKey: "appName", settingValue: "تطبيق دوام الذكي (Enterprise AI Punch)", description: "Application Name" },
        { category: "general", settingKey: "companyName", settingValue: "شركة الابتكار الرقمي القابضة (Vanguard AI Tech)", description: "Company Name" },
        { category: "general", settingKey: "welcomeMessage", settingValue: "مرحباً بك في المنصة الموحدة الذكية لتسجيل الدوام والإشعارات المؤسسية.", description: "Welcome Message" },
        { category: "general", settingKey: "language", settingValue: "ar", description: "Language (ar / en)" },
        { category: "general", settingKey: "timeZone", settingValue: "Asia/Riyadh (GMT+03:00)", description: "Time Zone" },
        { category: "general", settingKey: "dateFormat", settingValue: "YYYY-MM-DD", description: "Date Format" },
        { category: "general", settingKey: "timeFormat", settingValue: "24h", description: "Time Format (12h or 24h)" },
        // Appearance
        { category: "appearance", settingKey: "themeMode", settingValue: "dark", description: "Theme Mode (dark, light, midnight, neon)" },
        { category: "appearance", settingKey: "cardColorStyle", settingValue: "glass-gradient", description: "Card Color Style" },
        { category: "appearance", settingKey: "primaryColor", settingValue: "indigo-purple", description: "Application Accent Color" },
        { category: "appearance", settingKey: "fontFamily", settingValue: "Cairo / Tajawal", description: "Fonts Library" },
        { category: "appearance", settingKey: "borderRadius", settingValue: "rounded-3xl", description: "Border Radius for Cards" },
        { category: "appearance", settingKey: "animationsEnabled", settingValue: "true", description: "Smooth Card Animations & Confetti" },
        // Live Clock
        { category: "live_clock", settingKey: "clockEnabled", settingValue: "true", description: "Enable Live Clock" },
        { category: "live_clock", settingKey: "clockType", settingValue: "3d_cyber", description: "Clock Design (digital, analog, 3d_cyber, minimalist)" },
        { category: "live_clock", settingKey: "showSeconds", settingValue: "true", description: "Show Seconds Live Tick" },
        { category: "live_clock", settingKey: "showDate", settingValue: "true", description: "Show Date & Hijri Calendar" },
        // Smart Assistant
        { category: "smart_assistant", settingKey: "assistantEnabled", settingValue: "true", description: "Enable AI Assistant Chatbot" },
        { category: "smart_assistant", settingKey: "assistantName", settingValue: "المستشار الذكي (Aura AI)", description: "Assistant Name" },
        { category: "smart_assistant", settingKey: "aiModel", settingValue: "GPT-4o & Claude 3.5 Sonnet Ensemble", description: "Active AI Model" },
        { category: "smart_assistant", settingKey: "personality", settingValue: "مساعد إداري مؤسسي ذكاء عالي وتجاوب لحظي", description: "Personality" },
        // API Keys & Integrations
        { category: "api_keys", settingKey: "openaiApi", settingValue: "sk-proj-ai-ent-9988-xxxxx-vanguard", description: "OpenAI API" },
        { category: "api_keys", settingKey: "googleMapsApi", settingValue: "AIz-SyC-Geocode-K99-Geofence-Pro", description: "Google Maps" },
        { category: "api_keys", settingKey: "whatsappApi", settingValue: "WAPP-CLOUD-GRAPH-v18.0-TOKEN-AUTH", description: "WhatsApp Business API" },
        { category: "api_keys", settingKey: "firebaseApi", settingValue: "AIz-SyB-Firebase-Push-Notification-FCM", description: "Firebase Cloud Messaging" },
        { category: "api_keys", settingKey: "supabaseApi", settingValue: "sb_token_prod_jwt_enterprise_sec_0091", description: "Supabase DB Mirror" },
        { category: "api_keys", settingKey: "stripeApi", settingValue: "sk_live_51M_enterprise_payroll_direct_deposit", description: "Stripe / Payroll Gateway" },
        // Notifications & Alarm
        { category: "notifications_alarm", settingKey: "soundSettings", settingValue: "chime_v2", description: "Notification Sound Effect" },
        { category: "notifications_alarm", settingKey: "vibration", settingValue: "true", description: "Haptic Feedback Vibration on Mobile" },
        { category: "notifications_alarm", settingKey: "attendanceAlarm", settingValue: "true", description: "Attendance Reminder 15 min before shift" },
        // Security
        { category: "security", settingKey: "twoFactorAuth", settingValue: "mandatory_all", description: "2FA Policy" },
        { category: "security", settingKey: "faceIdMandatory", settingValue: "true", description: "Face ID Required for Check-In" },
        { category: "security", settingKey: "trustedDevicesOnly", settingValue: "true", description: "Allow only registered corporate NFC devices" },
        // Advanced System Control
        { category: "advanced", settingKey: "maintenanceMode", settingValue: "false", description: "Maintenance Mode" },
        { category: "advanced", settingKey: "systemMonitor", settingValue: "Online (CPU 12%, RAM 1.8GB, Latency 4ms)", description: "System Performance Monitor" },
        { category: "advanced", settingKey: "cacheManager", settingValue: "Optimized Redis Edge Cache Enabled", description: "Cache Manager Status" },
      ]);
    }

    // Fetch all current data
    const allDepts = await db.select().from(departments);
    const allEmps = await db.select().from(employees);
    const allAtt = await db.select().from(attendance);
    const allShifts = await db.select().from(shifts);
    const allLeaves = await db.select().from(leaves);
    const allPayrolls = await db.select().from(payroll);
    const allNotifs = await db.select().from(notifications);
    const allAI = await db.select().from(aiAnalytics);
    const allFace = await db.select().from(faceRecognition);
    const allGPS = await db.select().from(gpsTracking);
    const allSettings = await db.select().from(systemSettings);

    return NextResponse.json({
      status: "success",
      data: {
        departments: allDepts,
        employees: allEmps,
        attendance: allAtt,
        shifts: allShifts,
        leaves: allLeaves,
        payrolls: allPayrolls,
        notifications: allNotifs,
        aiAnalytics: allAI,
        faceRecognition: allFace,
        gpsTracking: allGPS,
        settings: allSettings,
      }
    });
  } catch (err: any) {
    console.error("Initialization Error:", err);
    return NextResponse.json({ status: "error", message: err?.message || "Error fetching initial data" }, { status: 500 });
  }
}
