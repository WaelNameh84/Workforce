import { pgTable, serial, text, integer, boolean, timestamp, real, jsonb, varchar } from "drizzle-orm/pg-core";

// 1. Users & Authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 50 }).default("employee"), // admin, manager, hr, security, employee
  faceIdToken: text("face_id_token"),
  fingerprintHash: text("fingerprint_hash"),
  qrCodeToken: text("qr_code_token"),
  nfcId: text("nfc_id"),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  twoFactorSecret: text("two_factor_secret"),
  permissions: jsonb("permissions").default(["attendance", "profile", "leaves", "payslip"]),
  avatar: text("avatar"),
  createdAt: timestamp("created_at").defaultNow(),
});

// 2. Departments
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  nameAr: varchar("name_ar", { length: 150 }).notNull(),
  nameEn: varchar("name_en", { length: 150 }).notNull(),
  code: varchar("code", { length: 50 }).notNull(),
  managerName: varchar("manager_name", { length: 150 }),
  headCount: integer("head_count").default(0),
  budget: real("budget").default(0),
  icon: text("icon").default("Briefcase"),
  colorBadge: varchar("color_badge", { length: 50 }).default("blue"),
  description: text("description"),
});

// 3. Employees (Profiles & Management)
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  employeeNumber: varchar("employee_number", { length: 50 }).notNull(),
  fullNameAr: varchar("full_name_ar", { length: 150 }).notNull(),
  fullNameEn: varchar("full_name_en", { length: 150 }).notNull(),
  email: varchar("email", { length: 150 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  avatarUrl: text("avatar_url"),
  departmentId: integer("department_id"),
  position: varchar("position", { length: 150 }),
  contractType: varchar("contract_type", { length: 50 }).default("Full-Time"), // Full-Time, Part-Time, Contract, Remote
  basicSalary: real("basic_salary").default(5000),
  dailyWage: real("daily_wage").default(200),
  hourlyWage: real("hourly_wage").default(25),
  hireDate: varchar("hire_date", { length: 50 }),
  status: varchar("status", { length: 50 }).default("Active"), // Active, On Leave, Remote, Terminated
  assignedWifiSsid: varchar("assigned_wifi_ssid", { length: 100 }).default("Corporate_HQ_5G"),
  assignedLatitude: real("assigned_latitude").default(24.7136),
  assignedLongitude: real("assigned_longitude").default(46.6753),
  emergencyContactName: varchar("emergency_contact_name", { length: 150 }),
  emergencyContactPhone: varchar("emergency_contact_phone", { length: 50 }),
  emergencyContactRelation: varchar("emergency_contact_relation", { length: 50 }),
  documentsList: jsonb("documents_list").default([]),
  certificatesList: jsonb("certificates_list").default([]),
  employmentHistory: jsonb("employment_history").default([]),
});

// 4. Attendance Records
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  date: varchar("date", { length: 50 }).notNull(),
  checkInTime: varchar("check_in_time", { length: 50 }),
  checkOutTime: varchar("check_out_time", { length: 50 }),
  breakStartTime: varchar("break_start_time", { length: 50 }),
  breakEndTime: varchar("break_end_time", { length: 50 }),
  gpsVerified: boolean("gps_verified").default(true),
  wifiVerified: boolean("wifi_verified").default(true),
  faceRecognized: boolean("face_recognized").default(true),
  deviceVerified: boolean("device_verified").default(true),
  shiftType: varchar("shift_type", { length: 100 }).default("Morning Shift"),
  status: varchar("status", { length: 50 }).default("On Time"), // On Time, Late, Overtime, Absent, Half Day
  totalHours: real("total_hours").default(0),
  overtimeHours: real("overtime_hours").default(0),
  locationCoordinates: text("location_coordinates").default("24.7136, 46.6753"),
  verificationMethod: varchar("verification_method", { length: 50 }).default("Face ID & GPS"),
});

// 5. Shifts Management
export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(), // Morning Shift, Evening Shift, Night Shift, Flexible Shift, Rotation
  startTime: varchar("start_time", { length: 50 }).notNull(),
  endTime: varchar("end_time", { length: 50 }).notNull(),
  graceMinutes: integer("grace_minutes").default(15),
  isFlexible: boolean("is_flexible").default(false),
  workDays: jsonb("work_days").default(["Sun", "Mon", "Tue", "Wed", "Thu"]),
  shiftType: varchar("shift_type", { length: 100 }).default("Standard"),
  color: varchar("color", { length: 50 }).default("indigo"),
});

// 6. Leave Management
export const leaves = pgTable("leaves", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  leaveType: varchar("leave_type", { length: 100 }).notNull(), // Annual Leave, Sick Leave, Emergency Leave, Maternity Leave, Unpaid Leave
  startDate: varchar("start_date", { length: 50 }).notNull(),
  endDate: varchar("end_date", { length: 50 }).notNull(),
  daysCount: integer("days_count").default(1),
  reason: text("reason"),
  status: varchar("status", { length: 50 }).default("Approved"), // Approved, Pending, Rejected
  approvalWorkflowStep: varchar("approval_workflow_step", { length: 100 }).default("HR Director Approved"),
  remainingBalance: integer("remaining_balance").default(21),
});

// 7. Payroll & Salary Calculations
export const payroll = pgTable("payroll", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  monthYear: varchar("month_year", { length: 50 }).notNull(), // e.g. "March 2026"
  basicSalary: real("basic_salary").notNull(),
  dailyWage: real("daily_wage").default(200),
  hourlyWage: real("hourly_wage").default(25),
  minutesWorked: integer("minutes_worked").default(9600), // ~160 hours
  overtimePay: real("overtime_pay").default(0),
  bonuses: real("bonuses").default(0),
  deductions: real("deductions").default(0),
  taxAmount: real("tax_amount").default(0),
  insuranceAmount: real("insurance_amount").default(0),
  finalSalary: real("final_salary").notNull(),
  status: varchar("status", { length: 50 }).default("Paid"), // Paid, Pending Approval, Draft
  paymentDate: varchar("payment_date", { length: 50 }),
  payslipId: varchar("payslip_id", { length: 100 }),
});

// 8. Schedules & Holidays Calendar
export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 150 }).notNull(),
  date: varchar("date", { length: 50 }).notNull(),
  type: varchar("type", { length: 50 }).default("Holiday"), // Holiday, Rotation, Event
  isPublicHoliday: boolean("is_public_holiday").default(false),
  description: text("description"),
  departmentId: integer("department_id"),
});

// 9. Documents
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id"),
  title: varchar("title", { length: 200 }).notNull(),
  docType: varchar("doc_type", { length: 100 }).notNull(), // Contract, ID Card, Certificate, Visa, Insurance
  fileUrl: text("file_url").default("#"),
  uploadDate: varchar("upload_date", { length: 50 }),
  expiryDate: varchar("expiry_date", { length: 50 }),
  isVerified: boolean("is_verified").default(true),
});

// 10. Notifications & Communication Channels
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  channel: varchar("channel", { length: 50 }).notNull(), // Email, SMS, Push Notifications, WhatsApp, In-App Notifications
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message").notNull(),
  recipientName: varchar("recipient_name", { length: 150 }).notNull(),
  recipientPhoneOrEmail: varchar("recipient_phone_or_email", { length: 150 }),
  status: varchar("status", { length: 50 }).default("Delivered"), // Delivered, Failed, Pending
  timestamp: timestamp("timestamp").defaultNow(),
  isRead: boolean("is_read").default(false),
});

// 11. Audit Logs (Security & Monitoring)
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userOrEmployee: varchar("user_or_employee", { length: 150 }).notNull(),
  action: varchar("action", { length: 250 }).notNull(),
  target: varchar("target", { length: 150 }),
  ipAddress: varchar("ip_address", { length: 50 }).default("192.168.1.104"),
  device: varchar("device", { length: 150 }).default("iPhone 15 Pro Max (Mobile Terminal)"),
  severity: varchar("severity", { length: 50 }).default("Normal"), // Normal, Warning, Critical
  timestamp: timestamp("timestamp").defaultNow(),
});

// 12. AI Analytics & Predictions
export const aiAnalytics = pgTable("ai_analytics", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  attendancePredictionScore: real("attendance_prediction_score").default(98.5), // Percentage
  fraudDetectionRisk: varchar("fraud_detection_risk", { length: 50 }).default("Low (0.2%)"), // Low, Medium, High
  faceMatchingConfidence: real("face_matching_confidence").default(99.4),
  productivityScore: real("productivity_score").default(94.8),
  performanceSummary: text("performance_summary").default("Excellent punctuality and strong task fulfillment."),
  smartRecommendations: text("smart_recommendations").default("Recommend for quarterly performance bonus."),
  generatedAt: timestamp("generated_at").defaultNow(),
});

// 13. Face Recognition Logs & Models
export const faceRecognition = pgTable("face_recognition", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  biometricTemplateHash: text("biometric_template_hash").default("SHA256:8f4c9c22e038..."),
  lastMatchedConfidence: real("last_matched_confidence").default(99.7),
  status: varchar("status", { length: 50 }).default("Verified & Active"),
  photoSnapshotUrl: text("photo_snapshot_url"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// 14. GPS Tracking & Geofencing
export const gpsTracking = pgTable("gps_tracking", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  locationName: varchar("location_name", { length: 200 }).default("Riyadh Digital City - Main HQ"),
  latitude: real("latitude").default(24.7136),
  longitude: real("longitude").default(46.6753),
  accuracyMeters: real("accuracy_meters").default(4.5),
  isWithinGeofence: boolean("is_within_geofence").default(true),
  timestamp: timestamp("timestamp").defaultNow(),
});

// 15. System Settings (Master Control Center - ALL Categories & Modules)
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  category: varchar("category", { length: 100 }).notNull(), 
  // general, appearance, live_clock, smart_assistant, api_keys, notifications_alarm, security, advanced_control
  settingKey: varchar("setting_key", { length: 150 }).notNull(),
  settingValue: text("setting_value").notNull(),
  dataType: varchar("data_type", { length: 50 }).default("string"), // string, boolean, number, json, color
  description: text("description"),
});
