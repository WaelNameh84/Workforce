"use client";
import React, { ReactNode } from "react";
import { Wifi, Battery, Signal, Lock, ShieldCheck, Smartphone, Monitor, Globe } from "lucide-react";

interface MobileFrameProps {
  children: ReactNode;
  isMobileMode: boolean;
  onToggleMode: () => void;
  language?: string;
}

export default function MobileFrame({
  children,
  isMobileMode,
  onToggleMode,
  language = "ar",
}: MobileFrameProps) {
  if (!isMobileMode) {
    // Desktop Full Widescreen Mode with Mobile feel cards
    return <div className="w-full max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 transition-all duration-300">{children}</div>;
  }

  // Mobile Simulator Mode
  return (
    <div className="my-2 flex flex-col items-center justify-center w-full min-h-screen transition-all duration-500">
      <div className="mb-4 flex items-center justify-center gap-2 bg-gradient-to-r from-slate-800 to-indigo-900 px-4 py-1.5 rounded-full border border-indigo-500/30 text-xs text-indigo-200 shadow-md">
        <Smartphone className="w-4 h-4 text-cyan-400 animate-bounce" />
        <span className="font-semibold">
          {language === "ar"
            ? "الآن في وضع تجربة الهاتف المحمول (Mobile App UI Mode) - تندر تماماً الجداول!"
            : "Mobile Super-App UI Mode (Touch Optimized Card System)"}
        </span>
      </div>

      <div className="relative w-full max-w-[430px] min-h-[860px] bg-slate-950 rounded-[48px] p-[12px] shadow-[0_0_50px_rgba(79,70,229,0.35)] border-[6px] border-slate-800 ring-1 ring-white/10 overflow-hidden transition-all duration-300">
        {/* Phone Speaker & Dynamic Island */}
        <div className="absolute top-[16px] left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-full flex items-center justify-between px-3 z-50 shadow-inner">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700/60 flex items-center justify-center">
            <div className="w-1 h-1 rounded-full bg-indigo-500/80 animate-pulse"></div>
          </div>
          <div className="w-10 h-1.5 bg-slate-800/80 rounded-full"></div>
          <ShieldCheck className="w-3 h-3 text-emerald-400" />
        </div>

        {/* Mobile Screen Area */}
        <div className="relative w-full h-full min-h-[820px] max-h-[88vh] overflow-y-auto overflow-x-hidden bg-gradient-to-b from-slate-900 via-slate-950 to-indigo-950/90 rounded-[38px] flex flex-col no-scrollbar">
          {/* Status Bar */}
          <div className="w-full pt-3 pb-2 px-6 flex items-center justify-between text-[11px] font-mono font-semibold text-slate-300 bg-slate-950/80 sticky top-0 z-40 backdrop-blur-md border-b border-slate-800/50">
            <span>{new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] bg-indigo-600 text-white px-1 rounded font-bold">5G</span>
              <Signal className="w-3.5 h-3.5 text-emerald-400" />
              <Wifi className="w-3.5 h-3.5 text-cyan-400" />
              <Battery className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          {/* Actual App Content */}
          <div className="flex-1 pb-16 pt-2 px-3">{children}</div>

          {/* Bottom Home Indicator Bar */}
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-36 h-1.5 bg-slate-500/60 rounded-full z-40"></div>
        </div>

        {/* Side Buttons Simulated */}
        <div className="absolute -left-[8px] top-[120px] w-[3px] h-[35px] bg-slate-700 rounded-l-md" />
        <div className="absolute -left-[8px] top-[170px] w-[3px] h-[50px] bg-slate-700 rounded-l-md" />
        <div className="absolute -left-[8px] top-[230px] w-[3px] h-[50px] bg-slate-700 rounded-l-md" />
        <div className="absolute -right-[8px] top-[160px] w-[3px] h-[75px] bg-slate-700 rounded-r-md" />
      </div>

      <button
        onClick={onToggleMode}
        className="mt-6 flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-2xl shadow-lg transition-transform active:scale-95 text-sm"
      >
        <Monitor className="w-4 h-4" />
        <span>
          {language === "ar"
            ? "التوسيع إلى شاشة العرض الكاملة (Desktop Wide Experience)"
            : "Expand to Full Screen Dashboard"}
        </span>
      </button>
    </div>
  );
}
