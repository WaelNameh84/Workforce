"use client";
import React, { useState } from "react";
import { 
  User, Briefcase, FileText, Award, PhoneCall, History, 
  Plus, Edit3, CheckCircle, MapPin, Wifi, DollarSign, 
  ChevronRight, ShieldCheck, Download, ExternalLink, X
} from "lucide-react";

interface EmployeesProps {
  language: string;
  employees: any[];
  departments: any[];
  onRefresh: () => void;
}

export default function EmployeesModule({ language = "ar", employees = [], departments = [], onRefresh }: EmployeesProps) {
  const [selectedEmp, setSelectedEmp] = useState<any>(employees[0] || null);
  const [filterDept, setFilterDept] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<"profile" | "contracts" | "docs" | "emergency" | "history">("profile");
  const [showAddModal, setShowAddModal] = useState(false);
  
  // Form State for adding new employee
  const [formData, setFormData] = useState({
    fullNameAr: "",
    fullNameEn: "",
    email: "",
    phone: "+966 50 123 4567",
    position: "أخصائي هندسة ذكاء الأنظمة",
    basicSalary: 18500,
    departmentId: 1,
    contractType: "Full-Time",
    emergencyContactName: "خالد المنصور",
    emergencyContactPhone: "+966 55 987 6543",
    emergencyContactRelation: "Brother"
  });

  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/employees/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.status === "success") {
        setShowAddModal(false);
        onRefresh();
      } else {
        alert("Error saving employee: " + data.message);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredEmps = filterDept ? employees.filter(e => e.departmentId === filterDept) : employees;
  const currentDept = departments.find(d => d.id === (selectedEmp?.departmentId || 1));

  return (
    <div className="space-y-6">
      {/* Top Header Card & Department Filter Badges */}
      <div className="bg-slate-900/80 backdrop-blur-2xl p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-indigo-400" />
              <span>{language === "ar" ? "إدارة الموظفين والبطاقات الرقمية" : "Employee Directory & Mobile Card Deck"}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {language === "ar" 
                ? "انقر على بطاقة أي موظف لاستعراض ملفه بالكامل (عقود الدوام، وجهات الطوارئ، الشهادات والتاريخ الوظيفي)."
                : "Interactive digital identity cards displaying profiles, departments, emergency contacts & contracts."}
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-2xl text-xs shadow-lg flex items-center gap-2 transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4 text-cyan-300" />
            <span>{language === "ar" ? "إضافة موظف جديد (New Card)" : "Register Employee Card"}</span>
          </button>
        </div>

        {/* Department Badge Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            onClick={() => setFilterDept(null)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap border transition-all ${
              filterDept === null 
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-white/30 shadow-md" 
                : "bg-slate-950/80 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-white"
            }`}
          >
            {language === "ar" ? "جميع الأقسام والفرق (" + employees.length + ")" : `All Departments (${employees.length})`}
          </button>
          {departments.map((d) => (
            <button
              key={d.id}
              onClick={() => setFilterDept(d.id)}
              className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap border transition-all flex items-center gap-2 ${
                filterDept === d.id 
                  ? "bg-indigo-950 text-cyan-300 border-cyan-500/50 shadow-md" 
                  : "bg-slate-950/70 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800/80"
              }`}
            >
              <span>{language === "ar" ? d.nameAr : d.nameEn}</span>
              <span className="px-1.5 py-0.5 bg-black/40 text-[10px] font-mono rounded-md text-slate-300">{d.code}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area: Left list of ID Cards, Right Detail Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Employee Cards Deck (No Tables!) */}
        <div className="space-y-3 lg:col-span-1 max-h-[720px] overflow-y-auto no-scrollbar pr-1">
          {filteredEmps.map((emp) => {
            const isSelected = selectedEmp && selectedEmp.id === emp.id;
            return (
              <div
                key={emp.id}
                onClick={() => setSelectedEmp(emp)}
                className={`p-4 rounded-3xl border transition-all duration-200 cursor-pointer relative overflow-hidden shadow-md flex items-center gap-4 ${
                  isSelected
                    ? "bg-gradient-to-r from-indigo-900/80 to-purple-900/70 border-cyan-400/50 shadow-indigo-500/20 scale-[1.02]"
                    : "bg-slate-900/70 hover:bg-slate-800/80 border-slate-800"
                }`}
              >
                <div className="relative">
                  <img 
                    src={emp.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
                    alt="avatar" 
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-400 shadow-sm flex-shrink-0"
                  />
                  <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-900" />
                </div>
                <div className="flex flex-col flex-1 truncate text-right">
                  <span className="font-mono text-[10px] text-cyan-400 font-bold tracking-wider">{emp.employeeNumber}</span>
                  <span className="font-bold text-sm text-white truncate">{language === "ar" ? emp.fullNameAr : emp.fullNameEn}</span>
                  <span className="text-xs text-slate-300 font-medium truncate mt-0.5">{emp.position}</span>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-[10px] px-2 py-0.5 bg-black/40 rounded-lg text-emerald-300 font-mono font-bold">
                      {emp.contractType || "Full-Time"}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{emp.basicSalary?.toLocaleString()} SAR</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Employee Comprehensive Detail View */}
        {selectedEmp && (
          <div className="lg:col-span-2 bg-slate-900/90 backdrop-blur-2xl p-6 rounded-3xl border border-slate-700/60 shadow-2xl flex flex-col justify-between space-y-6">
            {/* Header Identity Card */}
            <div className="p-5 bg-gradient-to-r from-slate-950 via-indigo-950/80 to-slate-950 rounded-3xl border border-indigo-500/40 shadow-inner flex flex-col sm:flex-row items-center sm:items-start justify-between gap-6 text-center sm:text-right">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
                <img 
                  src={selectedEmp.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300"} 
                  alt="Avatar" 
                  className="w-24 h-24 rounded-3xl object-cover border-4 border-indigo-500/60 shadow-xl"
                />
                <div>
                  <div className="flex items-center justify-center sm:justify-start gap-2">
                    <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-mono rounded-md border border-indigo-500/30 font-bold">
                      {selectedEmp.employeeNumber}
                    </span>
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono rounded-md border border-emerald-500/30">
                      Active Biometric Subject
                    </span>
                  </div>
                  <h3 className="text-2xl font-black text-white mt-2">{language === "ar" ? selectedEmp.fullNameAr : selectedEmp.fullNameEn}</h3>
                  <p className="text-xs font-bold text-cyan-300 mt-1">{selectedEmp.position}</p>
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-3 text-xs text-slate-300">
                    <span className="flex items-center gap-1 font-mono"><Wifi className="w-3.5 h-3.5 text-cyan-400" /> {selectedEmp.assignedWifiSsid}</span>
                    <span className="flex items-center gap-1 font-mono"><MapPin className="w-3.5 h-3.5 text-rose-400" /> {selectedEmp.assignedLatitude?.toFixed(4)}, {selectedEmp.assignedLongitude?.toFixed(4)}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 text-center flex flex-col items-center">
                <span className="text-[11px] text-slate-400 font-bold">{language === "ar" ? "الراتب الأساسي الشهري" : "Basic Salary"}</span>
                <span className="text-2xl font-black font-mono text-emerald-400 mt-1">{selectedEmp.basicSalary?.toLocaleString()}</span>
                <span className="text-[10px] font-sans text-slate-400">{language === "ar" ? "ريال سعودي / شهر" : "SAR / Month"}</span>
              </div>
            </div>

            {/* Sub-Navigation Tabs for Selected Employee */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 border-y border-slate-800 py-3">
              {[
                { id: "profile", ar: "الملف والأقسام", en: "Profile", icon: User },
                { id: "contracts", ar: "العقود والرواتب", en: "Contracts", icon: Briefcase },
                { id: "docs", ar: "المستندات والشهادات", en: "Documents", icon: FileText },
                { id: "emergency", ar: "جهة الطوارئ", en: "Emergency", icon: PhoneCall },
                { id: "history", ar: "التاريخ الوظيفي", en: "History", icon: History },
              ].map((t) => {
                const Icon = t.icon;
                const active = activeTab === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setActiveTab(t.id as any)}
                    className={`p-2.5 rounded-2xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                      active
                        ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20"
                        : "bg-slate-950/60 text-slate-400 hover:bg-slate-800/80 hover:text-white"
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{language === "ar" ? t.ar : t.en}</span>
                  </button>
                );
              })}
            </div>

            {/* Tab 1: Profile & Departments */}
            {activeTab === "profile" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-3">
                  <div className="text-xs text-slate-400 font-bold">{language === "ar" ? "تفاصيل القسم المسؤول" : "Department Info"}</div>
                  <div className="font-bold text-base text-cyan-300">{language === "ar" ? currentDept?.nameAr : currentDept?.nameEn}</div>
                  <div className="text-xs text-slate-300">{currentDept?.description}</div>
                  <div className="px-2 py-1 bg-indigo-950/80 text-indigo-300 text-[11px] font-mono rounded-xl w-max">
                    {language === "ar" ? "مدير الإدارة: " : "Manager: "} {currentDept?.managerName || "مكتب القيادة"}
                  </div>
                </div>

                <div className="p-4 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-3">
                  <div className="text-xs text-slate-400 font-bold">{language === "ar" ? "معلومات الاتصال الرسمي" : "Contact & Hire Data"}</div>
                  <div className="text-xs font-mono text-slate-200">Email: {selectedEmp.email}</div>
                  <div className="text-xs font-mono text-slate-200">Phone: {selectedEmp.phone || "+966 50 000 0000"}</div>
                  <div className="text-xs font-mono text-slate-200">Hire Date: {selectedEmp.hireDate || "2022-01-15"}</div>
                  <div className="flex items-center gap-1 text-emerald-400 text-xs font-bold">
                    <ShieldCheck className="w-4 h-4" /> {language === "ar" ? "حالة الامتثال البيومتري: نشط" : "Biometrics Compliant"}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Contracts & Wages Breakdown Card */}
            {activeTab === "contracts" && (
              <div className="space-y-4">
                <div className="p-5 bg-gradient-to-r from-indigo-950/60 to-slate-950 rounded-2xl border border-indigo-500/40 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white text-base">{language === "ar" ? "عقد العمل المؤسسي الدائم (Employment Contract)" : "Full-Time Corporate Employment Contract"}</h4>
                    <p className="text-xs text-slate-300 mt-1">{language === "ar" ? "يتضمن الراتب الأساسي، بدلات السفر والاتصال الرقمي، واحتساب الدقيقة والساعة في نظام الرواتب التلقائي." : "Includes daily/hourly rate guarantees and automated Drizzle ORM precision billing."}</p>
                  </div>
                  <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 font-bold text-xs rounded-xl border border-emerald-500/40">
                    {selectedEmp.contractType || "Full-Time"}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">{language === "ar" ? "الأجر اليومي المحتسب" : "Daily Wage"}</div>
                    <div className="text-lg font-bold text-cyan-300 font-mono mt-1">{(selectedEmp.dailyWage || (selectedEmp.basicSalary / 25))?.toFixed(0)} SAR</div>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">{language === "ar" ? "أجر الساعة (Hourly Wage)" : "Hourly Wage"}</div>
                    <div className="text-lg font-bold text-purple-300 font-mono mt-1">{(selectedEmp.hourlyWage || (selectedEmp.basicSalary / 200))?.toFixed(1)} SAR</div>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">{language === "ar" ? "أجر الدقيقة (Minute Rate)" : "Minute Calc Rate"}</div>
                    <div className="text-lg font-bold text-emerald-400 font-mono mt-1">{((selectedEmp.hourlyWage || 120) / 60)?.toFixed(2)} SAR</div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Documents & Certificates */}
            {activeTab === "docs" && (
              <div className="space-y-3">
                <div className="font-bold text-sm text-white flex items-center justify-between">
                  <span>{language === "ar" ? "وثائق وشهادات الموظف الموثقة بصمياً" : "Verified Documents & Certificates"}</span>
                  <span className="text-xs text-cyan-400 font-mono">2 Verified Files</span>
                </div>
                {[
                  { title: language === "ar" ? "عقد العمل الإلكتروني والمصادقة بالبصمة" : "Signed Employment Contract", type: "Contract PDF", date: "2023-01-15" },
                  { title: language === "ar" ? "شهادة الاعتماد المؤسسي في الذكاء الاصطناعي" : "TOGAF Enterprise Cert", type: "Certificate", date: "2024-05-20" },
                ].map((doc, i) => (
                  <div key={i} className="p-3.5 bg-slate-950 hover:bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-indigo-900/30 text-indigo-400 rounded-xl">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-bold text-sm text-white">{doc.title}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{doc.type} • Uploaded {doc.date}</div>
                      </div>
                    </div>
                    <button 
                      onClick={() => alert(language === "ar" ? "تم تحميل نسخة المستند بصيغة PDF بنجاح." : "Document downloaded successfully!")}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-indigo-600 hover:text-white rounded-xl text-xs text-slate-300 font-bold transition-all flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{language === "ar" ? "تحميل" : "Download"}</span>
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 4: Emergency Contacts */}
            {activeTab === "emergency" && (
              <div className="p-6 bg-gradient-to-r from-rose-950/40 via-slate-950 to-slate-950 rounded-2xl border border-rose-500/40 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 rounded-3xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center shadow-lg animate-pulse">
                  <PhoneCall className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-black text-white">{selectedEmp.emergencyContactName || (language === "ar" ? "عبدالعزيز المنصور" : "Abdulaziz Al-Mansour")}</h4>
                  <p className="text-xs font-bold text-rose-300 mt-1">{language === "ar" ? "صلة القرابة: " : "Relation: "} {selectedEmp.emergencyContactRelation || "Brother (شقيق)"}</p>
                  <div className="mt-3 py-2 px-4 bg-slate-900 rounded-xl border border-slate-700 font-mono text-lg text-cyan-300 font-black">
                    {selectedEmp.emergencyContactPhone || "+966 55 987 6543"}
                  </div>
                </div>
                <button 
                  onClick={() => alert(language === "ar" ? `جاري الاتصال السريع برقم الطوارئ: ${selectedEmp.emergencyContactPhone || "+966559876543"} عبر تطبيق الهاتف...` : "Initiating quick cellular emergency dial...")}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-2xl text-xs shadow-md transition-transform active:scale-95 flex items-center gap-2"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>{language === "ar" ? "إجراء اتصال طوارئ سريع الآن (Simulate Call)" : "Call Emergency Contact Now"}</span>
                </button>
              </div>
            )}

            {/* Tab 5: Employee History */}
            {activeTab === "history" && (
              <div className="space-y-4 py-2">
                <h4 className="font-bold text-sm text-white">{language === "ar" ? "السجل التاريخي والترقيات بالمؤسسة" : "Career Chronology & History"}</h4>
                <div className="space-y-3 pl-2 sm:pl-4 border-l-2 border-indigo-500/50">
                  {[
                    { year: "2024 - Present", title: language === "ar" ? "ترقية إلى منصب قيادي رفيع" : "Promoted to Principal Staff Role", desc: language === "ar" ? "تم التعيين بناءً على تقييم 99.8% بالذكاء الاصطناعي." : "Appointed following 99.8% AI productivity scoring." },
                    { year: "2023", title: language === "ar" ? "إنجاز نظام الربط البيومتري بالبصمة" : "Lead Engineering Biometrics Deployment", desc: language === "ar" ? "إدارة أكثر من 15 ألف حركة دخول وانصراف آمنة." : "Executed secure geofenced wireless verification architecture." },
                    { year: "2022", title: language === "ar" ? "الالتحاق بالمؤسسة (Onboarding)" : "Corporate Onboarding & Contract Signing", desc: language === "ar" ? "إتمام استلام الهوية الوطنية الرقمية وتوثيق الـ NFC." : "Received digital identity NFC bounds and 5G terminal sync." },
                  ].map((h, i) => (
                    <div key={i} className="relative pl-4 bg-slate-950/70 p-3 rounded-2xl border border-slate-800 shadow-sm">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded">{h.year}</span>
                      <div className="font-bold text-sm text-white mt-1">{h.title}</div>
                      <div className="text-xs text-slate-400 mt-0.5">{h.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 rounded-3xl border border-indigo-500/40 p-6 shadow-2xl space-y-5 animate-scale-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-black text-lg text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-cyan-400" />
                <span>{language === "ar" ? "إصدار بطاقة موظف جديد" : "Register New Employee Profile Card"}</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEmployee} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "الاسم الكامل (بالعربية)" : "Full Name (Arabic)"}</label>
                <input 
                  type="text" 
                  required
                  value={formData.fullNameAr}
                  onChange={(e) => setFormData({...formData, fullNameAr: e.target.value})}
                  placeholder="مثال: فهد عبدالكريم التميمي"
                  className="w-full px-4 py-2.5 bg-slate-950 rounded-xl border border-slate-700 text-white text-sm font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "الاسم بالإنجليزية (English Name)" : "Full Name (English)"}</label>
                <input 
                  type="text" 
                  required
                  value={formData.fullNameEn}
                  onChange={(e) => setFormData({...formData, fullNameEn: e.target.value})}
                  placeholder="e.g. Fahad Al-Tamimi"
                  className="w-full px-4 py-2.5 bg-slate-950 rounded-xl border border-slate-700 text-white text-sm font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "المسمى الوظيفي" : "Position"}</label>
                  <input 
                    type="text" 
                    value={formData.position}
                    onChange={(e) => setFormData({...formData, position: e.target.value})}
                    className="w-full px-3.5 py-2 bg-slate-950 rounded-xl border border-slate-700 text-white text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "الراتب الأساسي (SAR)" : "Basic Salary"}</label>
                  <input 
                    type="number" 
                    value={formData.basicSalary}
                    onChange={(e) => setFormData({...formData, basicSalary: Number(e.target.value)})}
                    className="w-full px-3.5 py-2 bg-slate-950 rounded-xl border border-slate-700 text-cyan-300 font-mono font-bold text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "القسم المسؤول" : "Department"}</label>
                  <select 
                    value={formData.departmentId}
                    onChange={(e) => setFormData({...formData, departmentId: Number(e.target.value)})}
                    className="w-full px-3 py-2 bg-slate-950 rounded-xl border border-slate-700 text-white text-xs font-bold"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>{language === "ar" ? d.nameAr : d.nameEn}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "نوع العقد" : "Contract Type"}</label>
                  <select 
                    value={formData.contractType}
                    onChange={(e) => setFormData({...formData, contractType: e.target.value})}
                    className="w-full px-3 py-2 bg-slate-950 rounded-xl border border-slate-700 text-emerald-300 text-xs font-bold"
                  >
                    <option value="Full-Time">Full-Time (دائم)</option>
                    <option value="Flexible">Flexible (مرن)</option>
                    <option value="Remote">Remote (عن بُعد)</option>
                    <option value="Contract">Contract (عقد محدد)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl font-bold text-xs text-slate-300"
                >
                  {language === "ar" ? "إلغاء" : "Cancel"}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 rounded-xl font-bold text-xs text-white shadow-lg shadow-indigo-500/30"
                >
                  {language === "ar" ? "حفظ وإدراج البطاقة في القوى العاملة" : "Save & Create Profile Card"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
