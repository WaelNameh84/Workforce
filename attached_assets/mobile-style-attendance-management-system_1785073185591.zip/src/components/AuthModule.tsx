"use client";
import React, { useState } from "react";
import { 
  Shield, Key, Fingerprint, QrCode, Smartphone, UserCheck, 
  CheckCircle2, AlertCircle, RefreshCw, Lock, Sparkles, ScanFace,
  Radio, Unlock, ShieldAlert, Cpu
} from "lucide-react";
import confetti from "canvas-confetti";

interface AuthProps {
  language: string;
  employees: any[];
  onBiometricPunch: (method: string) => void;
}

export default function AuthModule({ language = "ar", employees = [], onBiometricPunch }: AuthProps) {
  const [selectedMethod, setSelectedMethod] = useState<"face" | "fingerprint" | "qr" | "nfc" | "2fa" | "permissions">("face");
  const [scanning, setScanning] = useState(false);
  const [success, setSuccess] = useState(false);
  const [selectedEmp, setSelectedEmp] = useState(employees[0]?.id || 1);
  const [otp, setOtp] = useState(["4", "8", "1", "9", "2", "6"]);

  const triggerScan = (methodName: string) => {
    setScanning(true);
    setSuccess(false);
    setTimeout(() => {
      setScanning(false);
      setSuccess(true);
      confetti({ particleCount: 60, spread: 55, origin: { y: 0.7 } });
      onBiometricPunch(methodName);
    }, 1800);
  };

  const activeEmployee = employees.find(e => e.id === Number(selectedEmp)) || employees[0];

  return (
    <div className="space-y-6">
      {/* Title Header Card */}
      <div className="bg-gradient-to-r from-indigo-900/60 via-purple-900/50 to-slate-900/80 backdrop-blur-xl p-5 rounded-3xl border border-indigo-500/30 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 text-white font-bold">
            <ScanFace className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              {language === "ar" ? "نظام المصادقة والبصمة المتعددة" : "Multi-Modal Biometric & Security Auth"}
              <span className="text-xs px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full border border-emerald-500/30 font-normal">
                {language === "ar" ? "مشفر AES-256" : "AES-256 Secure"}
              </span>
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              {language === "ar" 
                ? "تفاعل مباشر مع تقنيات Face ID، البصمة الحية، المسح الضوئي QR، وقارئ NFC اللاسلكي بدون جداول روتينية."
                : "Interactive multi-factor terminal with Face ID, Fingerprint, QR scanner & NFC tap simulation."}
            </p>
          </div>
        </div>

        {/* Employee Selector for Biometric Simulation */}
        <div className="w-full sm:w-auto bg-slate-950/80 px-4 py-2 rounded-2xl border border-slate-700/60 flex items-center gap-3">
          <img 
            src={activeEmployee?.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
            alt="avatar" 
            className="w-10 h-10 rounded-full object-cover border-2 border-indigo-400"
          />
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 font-bold uppercase">{language === "ar" ? "الموظف النشط" : "Active Subject"}</span>
            <select 
              value={selectedEmp} 
              onChange={(e) => { setSelectedEmp(Number(e.target.value)); setSuccess(false); }}
              className="bg-transparent font-bold text-xs text-cyan-300 focus:outline-none cursor-pointer"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id} className="bg-slate-900 text-white">
                  {language === "ar" ? emp.fullNameAr : emp.fullNameEn}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Touch Navigation Pills */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {[
          { id: "face", titleAr: "Face ID", titleEn: "Face ID", icon: ScanFace, color: "from-cyan-600 to-blue-600" },
          { id: "fingerprint", titleAr: "بصمة الإصبع", titleEn: "Fingerprint", icon: Fingerprint, color: "from-purple-600 to-indigo-600" },
          { id: "qr", titleAr: "مسح QR Code", titleEn: "QR Code", icon: QrCode, color: "from-amber-600 to-orange-600" },
          { id: "nfc", titleAr: "قارئ NFC", titleEn: "NFC Tag", icon: Radio, color: "from-emerald-600 to-teal-600" },
          { id: "2fa", titleAr: "مصادقة 2FA", titleEn: "2FA PIN", icon: Key, color: "from-rose-600 to-pink-600" },
          { id: "permissions", titleAr: "الصلاحيات والرتب", titleEn: "Permissions", icon: ShieldAlert, color: "from-indigo-600 to-slate-800" },
        ].map((item) => {
          const Icon = item.icon;
          const isActive = selectedMethod === item.id;
          return (
            <button
              key={item.id}
              onClick={() => { setSelectedMethod(item.id as any); setSuccess(false); }}
              className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all duration-200 shadow-md ${
                isActive 
                  ? `bg-gradient-to-br ${item.color} text-white border-white/40 shadow-indigo-500/30 scale-105` 
                  : "bg-slate-900/70 text-slate-400 border-slate-800 hover:bg-slate-800/80 hover:text-white"
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive ? "animate-bounce" : ""}`} />
              <span className="text-xs font-bold text-center">{language === "ar" ? item.titleAr : item.titleEn}</span>
            </button>
          );
        })}
      </div>

      {/* Active Method Simulation Area */}
      <div className="bg-slate-900/80 backdrop-blur-2xl p-6 rounded-3xl border border-slate-700/60 shadow-2xl relative overflow-hidden">
        {/* Face ID Section */}
        {selectedMethod === "face" && (
          <div className="flex flex-col items-center justify-center py-6 text-center space-y-6">
            <div className="relative w-56 h-56 rounded-3xl overflow-hidden border-4 border-cyan-500/50 bg-black flex items-center justify-center shadow-[0_0_35px_rgba(6,182,212,0.35)]">
              <img 
                src={activeEmployee?.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300"} 
                alt="Face Target" 
                className="w-full h-full object-cover opacity-80 filter brightness-110"
              />
              {/* Laser Scanner Line */}
              {scanning && (
                <div className="absolute inset-w-0 left-0 w-full h-2 bg-cyan-400 shadow-[0_0_15px_rgba(6,182,212,1)] animate-[ping_1.5s_infinite] border-y border-white" />
              )}
              <div className="absolute inset-0 border-[3px] border-dashed border-cyan-400/40 pointer-events-none rounded-3xl" />
              <div className="absolute top-2 right-2 px-2 py-0.5 bg-cyan-950/90 text-cyan-300 font-mono text-[10px] rounded-lg border border-cyan-500/30 flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                3D Depth Camera
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-white">
                {language === "ar" ? "المسح البيومتري الثلاثي الأبعاد (Face ID 3D Map)" : "3D Facial Biometric Verification"}
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
                {language === "ar"
                  ? "يتم التحقق من ملامح الوجه وعرض النطاق الحراري بالتعاون مع محرك الذكاء الاصطناعي لمنع صور الشاشات أو الصور المطبوعة."
                  : "Verifies infrared neural facial depth coordinates via AI Engine to prevent display & print spoofing."}
              </p>
            </div>

            {success ? (
              <div className="p-4 bg-emerald-950/80 border border-emerald-500 text-emerald-300 rounded-2xl flex items-center gap-3 shadow-lg animate-fade-in max-w-sm">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 flex-shrink-0" />
                <div className="text-right flex-1">
                  <div className="font-bold text-sm">
                    {language === "ar" ? "تمت المصادقة بنجاح!" : "Authentication Successful!"}
                  </div>
                  <div className="text-[11px] text-emerald-200">
                    {language === "ar" ? `نسبة تطابق الوجه: 99.8% للموظف (${activeEmployee?.fullNameAr})` : `Match Confidence: 99.8% (${activeEmployee?.fullNameEn})`}
                  </div>
                </div>
              </div>
            ) : (
              <button
                onClick={() => triggerScan("Face ID 3D Biometrics")}
                disabled={scanning}
                className="px-8 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 font-black rounded-2xl shadow-xl text-white flex items-center gap-2 transform active:scale-95 transition-all text-sm"
              >
                {scanning ? <RefreshCw className="w-5 h-5 animate-spin" /> : <ScanFace className="w-5 h-5" />}
                <span>{scanning ? (language === "ar" ? "جاري مسح البصمة..." : "Scanning Face...") : (language === "ar" ? "إجراء بصمة الوجه الآن (Simulated Touch)" : "Start Face ID Scan")}</span>
              </button>
            )}
          </div>
        )}

        {/* Fingerprint Section */}
        {selectedMethod === "fingerprint" && (
          <div className="flex flex-col items-center justify-center py-8 text-center space-y-6">
            <div className={`w-36 h-36 rounded-full border-4 ${scanning ? "border-purple-400 animate-pulse bg-purple-900/30" : "border-purple-500/30 bg-slate-950"} flex items-center justify-center shadow-[0_0_40px_rgba(168,85,247,0.3)] transition-all duration-300 cursor-pointer hover:scale-105`}
              onClick={() => !scanning && triggerScan("Fingerprint WebAuthn")}
            >
              <Fingerprint className={`w-20 h-20 ${scanning ? "text-purple-400 animate-bounce" : "text-purple-500"}`} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">
                {language === "ar" ? "بصمة الإصبع الحية (WebAuthn & Touch Sensor)" : "Fingerprint Biometric Touch Sensor"}
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
                {language === "ar" 
                  ? "اضغط على زر البصمة لإنشاء توقيع بيومتري فوري مطابق للمواصفات الأمنية في المحمول."
                  : "Tap on the fingerprint sensor ring above to trigger real-time cryptographic cryptographic hardware verification."}
              </p>
            </div>
            {success ? (
              <div className="p-4 bg-purple-950/80 border border-purple-500 text-purple-200 rounded-2xl flex items-center gap-3 shadow-lg">
                <CheckCircle2 className="w-7 h-7 text-purple-400" />
                <span className="font-bold text-sm">{language === "ar" ? "بصمة إصبع مطابقة 100%! تم توثيق الدوام." : "Fingerprint match verified!"}</span>
              </div>
            ) : (
              <button
                onClick={() => triggerScan("Fingerprint WebAuthn")}
                className="px-8 py-3 bg-purple-600 hover:bg-purple-500 font-bold rounded-2xl text-white shadow-lg shadow-purple-600/30 transition-transform active:scale-95 text-sm"
              >
                {language === "ar" ? "اضغط للبصمة (Tap to Touch)" : "Tap Sensor Ring"}
              </button>
            )}
          </div>
        )}

        {/* QR Code Scanner */}
        {selectedMethod === "qr" && (
          <div className="flex flex-col sm:flex-row items-center justify-around gap-8 py-4">
            <div className="flex flex-col items-center bg-slate-950 p-6 rounded-3xl border border-amber-500/40 shadow-xl">
              <div className="p-3 bg-white rounded-2xl">
                <QrCode className="w-40 h-40 text-slate-950" />
              </div>
              <span className="mt-3 font-mono text-xs text-amber-400 font-bold">TOKEN: ENT-2026-9988-SEC</span>
              <span className="text-[10px] text-slate-400 mt-1">{language === "ar" ? "يتم تجديد الباركود كل 15 ثانية" : "Refreshes every 15s"}</span>
            </div>
            <div className="flex-1 max-w-md space-y-4 text-right">
              <h3 className="text-xl font-bold text-white flex items-center justify-end gap-2">
                {language === "ar" ? "مسح رمز QR الديناميكي" : "Dynamic QR Code Terminal Scanner"}
                <QrCode className="w-6 h-6 text-amber-400" />
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {language === "ar"
                  ? "قم بتوجيه كاميرا جهاز المحمول التجاري الخاص بالشركة نحو الباركود المتغير لتسجيل الدخول السريع في نقاط التفتيش ومداخل الأبواب."
                  : "Aim the corporate terminal device camera at the shifting QR badge to register check-in without physical contact."}
              </p>
              <button
                onClick={() => triggerScan("Dynamic QR Code Token")}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 font-bold rounded-2xl text-white shadow-lg flex items-center justify-center gap-2 text-sm"
              >
                <QrCode className="w-5 h-5" />
                <span>{language === "ar" ? "محاكاة مسح QR Code بنجاح" : "Simulate QR Scanner Scan"}</span>
              </button>
              {success && <p className="text-emerald-400 font-bold text-xs text-center">{language === "ar" ? "تمت قراءة الرمز بنجاح وتوثيق الحركة!" : "QR Code scanned and validated!"}</p>}
            </div>
          </div>
        )}

        {/* NFC Section */}
        {selectedMethod === "nfc" && (
          <div className="flex flex-col items-center justify-center py-6 space-y-5 text-center">
            <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-emerald-500/20 to-teal-900/40 border-2 border-emerald-400/50 flex items-center justify-center relative animate-pulse shadow-[0_0_35px_rgba(16,185,129,0.3)]">
              <Radio className="w-16 h-16 text-emerald-400" />
              <div className="absolute -bottom-2 px-3 py-0.5 bg-emerald-500 text-slate-950 font-black text-[10px] rounded-full">
                NFC READY
              </div>
            </div>
            <h3 className="text-xl font-bold text-white">
              {language === "ar" ? "قارئ المدي القصير (NFC Tap & Go)" : "NFC Near-Field Tap Verification"}
            </h3>
            <p className="text-xs text-slate-300 max-w-sm">
              {language === "ar" ? "مرر بطاقة الموظف الذكية (ID Badge) أو سوار الـ NFC فوق القارئ اللاسلكي." : "Wave the employee intelligent RFID/NFC identity card over the wireless transceiver."}
            </p>
            <button
              onClick={() => triggerScan("NFC Wireless Tap Card")}
              className="px-8 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-2xl shadow-lg shadow-emerald-500/20 text-sm"
            >
              {language === "ar" ? "تمرير بطاقة NFC الآن (Simulate Tap)" : "Simulate NFC Card Tap"}
            </button>
          </div>
        )}

        {/* Two Factor Authentication (2FA) */}
        {selectedMethod === "2fa" && (
          <div className="max-w-md mx-auto py-4 space-y-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center mx-auto shadow-lg">
              <Key className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                {language === "ar" ? "المصادقة الثنائية (Two-Factor OTP Security)" : "Two-Factor Authentication (2FA)"}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                {language === "ar" ? "تم إرسال رمز الأمان لمرة واحدة إلى تطبيق Google Authenticator ورقم الجوال الموثوق." : "Enter the 6-digit Time-based One Time Password generated in Google Authenticator."}
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 rtl:flex-row-reverse">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  type="text"
                  readOnly
                  value={digit}
                  className="w-11 h-12 rounded-xl bg-slate-950 border border-slate-700 text-center font-mono font-black text-lg text-rose-400 shadow-inner"
                />
              ))}
            </div>
            <button
              onClick={() => triggerScan("2FA OTP Pin")}
              className="w-full py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 text-white font-bold rounded-2xl shadow-md text-sm"
            >
              {language === "ar" ? "تأكيد الرمز والمصادقة (Verify 2FA Token)" : "Verify 2FA Security Pin"}
            </button>
          </div>
        )}

        {/* Permissions Module */}
        {selectedMethod === "permissions" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Unlock className="w-5 h-5 text-indigo-400" />
                <span>{language === "ar" ? "صلاحيات ومستوى الوصول (Enterprise RBAC)" : "Role-Based Access Control Permissions"}</span>
              </h3>
              <span className="text-xs text-slate-400">{language === "ar" ? "6 رتب أمنية نشطة" : "6 Active Roles"}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { role: "Executive Admin", ar: "مسؤول قيادي عليا", badge: "All Access + MCC", color: "border-purple-500/40 bg-purple-950/40 text-purple-300" },
                { role: "HR & Compliance Lead", ar: "مدير الموارد والتدقيق", badge: "Leaves, Payroll, Documents", color: "border-cyan-500/40 bg-cyan-950/40 text-cyan-300" },
                { role: "AI Security Principal", ar: "مهندس ذكاء كشف الاحتيال", badge: "AI Engine, Biometric Maps", color: "border-emerald-500/40 bg-emerald-950/40 text-emerald-300" },
                { role: "Shift Supervisor", ar: "مشرف ورديات المناوبة", badge: "Attendance & Schedules", color: "border-amber-500/40 bg-amber-950/40 text-amber-300" },
                { role: "Regular Employee", ar: "موظف دوام أساسي", badge: "Own Profile & Self Punch", color: "border-indigo-500/40 bg-indigo-950/40 text-indigo-300" },
                { role: "Audit Auditor", ar: "مراقب السجلات والأمن", badge: "Audit Logs & Backup Only", color: "border-rose-500/40 bg-rose-950/40 text-rose-300" },
              ].map((r, idx) => (
                <div key={idx} className={`p-4 rounded-2xl border ${r.color} flex flex-col justify-between space-y-3 shadow-sm`}>
                  <div className="flex items-start justify-between">
                    <div className="font-bold text-sm text-white">{language === "ar" ? r.ar : r.role}</div>
                    <Shield className="w-4 h-4 opacity-70" />
                  </div>
                  <div className="text-[11px] font-mono font-semibold opacity-90 px-2 py-1 bg-black/40 rounded-lg w-max">
                    {r.badge}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
