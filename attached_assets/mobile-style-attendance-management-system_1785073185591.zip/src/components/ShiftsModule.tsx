"use client";
import React, { useState } from "react";
import { 
  Calendar, Clock, Sun, Sunset, Moon, Sparkles, RefreshCcw, 
  Users, Check, ArrowRight, ShieldCheck, Flame, CalendarDays 
} from "lucide-react";

interface ShiftsProps {
  language: string;
  shifts: any[];
}

export default function ShiftsModule({ language = "ar", shifts = [] }: ShiftsProps) {
  const [activeView, setActiveView] = useState<"shifts" | "holidays">("shifts");
  const [selectedShift, setSelectedShift] = useState("Morning Shift");

  return (
    <div className="space-y-6">
      {/* Header Tabs Card */}
      <div className="bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Clock className="w-6 h-6 text-amber-400" />
            <span>{language === "ar" ? "إدارة الورديات، التناوب وروزنامة العطلات" : "Shift Management & Holiday Calendar Deck"}</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            {language === "ar" 
              ? "أنظمة الورديات الثابتة والمرنة، مع جداول المناوبات التلقائية وربط العطلات الرسمية والمناسبات الوطنية."
              : "Comprehensive card deck for Morning, Evening, Night & Flexible shifting + interactive Holiday timeline."}
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveView("shifts")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeView === "shifts" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white"
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{language === "ar" ? "بطاقات الورديات (5)" : "Shifts & Rotation (5)"}</span>
          </button>
          <button
            onClick={() => setActiveView("holidays")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeView === "holidays" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white"
            }`}
          >
            <CalendarDays className="w-4 h-4 text-emerald-400" />
            <span>{language === "ar" ? "روزنامة العطلات الرسمية" : "Holiday Calendar"}</span>
          </button>
        </div>
      </div>

      {activeView === "shifts" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              id: "Morning Shift",
              titleAr: "الوردية الصباحية المباشرة",
              titleEn: "Morning Shift",
              time: "08:00 AM - 04:00 PM",
              grace: "15 دقيقة سماح",
              days: ["Sun", "Mon", "Tue", "Wed", "Thu"],
              staffCount: 14,
              icon: Sun,
              color: "from-amber-500/20 to-orange-950/40 border-amber-500/40 text-amber-400",
              badge: "الأكثر نشاطاً اليوم"
            },
            {
              id: "Evening Shift",
              titleAr: "الوردية المسائية الديناميكية",
              titleEn: "Evening Shift",
              time: "02:00 PM - 10:00 PM",
              grace: "20 دقيقة سماح",
              days: ["Sun", "Mon", "Tue", "Wed", "Thu"],
              staffCount: 8,
              icon: Sunset,
              color: "from-indigo-500/20 to-blue-950/40 border-indigo-500/40 text-indigo-400",
              badge: "المناوبة الثانية"
            },
            {
              id: "Night Shift",
              titleAr: "وردية الطوارئ والمراقبة الليلية",
              titleEn: "Night Shift (Overnight)",
              time: "10:00 PM - 06:00 AM",
              grace: "10 دقائق سماح",
              days: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
              staffCount: 5,
              icon: Moon,
              color: "from-purple-500/20 to-slate-950 border-purple-500/40 text-purple-400",
              badge: "مكافأة ليلية +25%"
            },
            {
              id: "Flexible Shift",
              titleAr: "الدوام المرن الذاتي (Core Hours)",
              titleEn: "Flexible Shift",
              time: "07:00 AM - 07:00 PM (أي 8 ساعات)",
              grace: "60 دقيقة سماح مرن",
              days: ["Sun", "Mon", "Tue", "Wed", "Thu"],
              staffCount: 9,
              icon: Sparkles,
              color: "from-emerald-500/20 to-teal-950/40 border-emerald-500/40 text-emerald-400",
              badge: "المهندسون وعن بُعد"
            },
            {
              id: "Rotation Schedule",
              titleAr: "جدول التناوب المؤسسي (A/B Matrix)",
              titleEn: "Rotation Schedule (2x2 / 4x3)",
              time: "تناوب ذكي حسب الذروة الأسبوعية",
              grace: "30 دقيقة سماح",
              days: ["Sun", "Tue", "Thu", "Sat"],
              staffCount: 6,
              icon: RefreshCcw,
              color: "from-rose-500/20 to-pink-950/40 border-rose-500/40 text-rose-400",
              badge: "AI Rotational Engine"
            },
          ].map((shift, i) => {
            const Icon = shift.icon;
            return (
              <div 
                key={i} 
                onClick={() => setSelectedShift(shift.id)}
                className={`p-6 rounded-3xl border bg-gradient-to-b ${shift.color} flex flex-col justify-between space-y-5 shadow-xl hover:scale-[1.02] transition-all duration-300 cursor-pointer relative overflow-hidden`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="p-3 bg-slate-950/80 rounded-2xl border border-white/10 text-white shadow-inner">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="px-2.5 py-1 bg-slate-950/80 rounded-full text-[11px] font-bold text-white font-mono shadow-sm">
                      {shift.badge}
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-white mt-4">{language === "ar" ? shift.titleAr : shift.titleEn}</h3>
                  <div className="text-sm font-mono font-bold text-cyan-300 mt-1">{shift.time}</div>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="text-xs text-slate-300 flex items-center justify-between">
                    <span>{language === "ar" ? "فترة السماح التلقائي:" : "Grace Period:"}</span>
                    <strong className="text-white font-mono">{shift.grace}</strong>
                  </div>

                  <div className="flex items-center gap-1">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                      <span
                        key={day}
                        className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                          shift.days.includes(day) ? "bg-indigo-600 text-white font-bold" : "bg-slate-800 text-slate-500"
                        }`}
                      >
                        {day}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-200">
                  <span className="flex items-center gap-1 font-bold">
                    <Users className="w-4 h-4 text-cyan-400" /> {shift.staffCount} {language === "ar" ? "موظف مخصص" : "Assigned Staff"}
                  </span>
                  <span className="text-[11px] font-bold text-emerald-400 hover:underline">
                    {language === "ar" ? "إعدادات الجدول ↗" : "Edit Rules ↗"}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { title: "يوم التأسيس السعودي (Foundation Day)", date: "22 February 2026", days: "2 أيام إجازة مدفوعة", badge: "عطلة وطنية رسمية", color: "border-emerald-500/40 bg-emerald-950/20 text-emerald-300" },
              { title: "إجازة عيد الفطر المبارك (Eid Al-Fitr)", date: "20 March 2026 - 28 March 2026", days: "9 أيام إجازة شاملة", badge: "عطلة العيد الكبير", color: "border-amber-500/40 bg-amber-950/20 text-amber-300" },
              { title: "إجازة عيد الأضحى المبارك (Eid Al-Adha)", date: "26 May 2026 - 03 June 2026", days: "8 أيام إجازة رسمية", badge: "موسم الحج والعيد", color: "border-purple-500/40 bg-purple-950/20 text-purple-300" },
              { title: "اليوم الوطني السعودي 96 (Saudi National Day)", date: "23 September 2026", days: "يوم واحد إجازة احتفالية", badge: "المناسبة السنوية الوطنية", color: "border-cyan-500/40 bg-cyan-950/20 text-cyan-300" },
              { title: "رأس السنة الهجرية والإدارية الجديدة", date: "01 July 2026", days: "يوم راحة إداري مبرم", badge: "العام المالي والجديد", color: "border-indigo-500/40 bg-indigo-950/20 text-indigo-300" },
              { title: "يوم الابتكار التكريمي لموظفي الذكاء الاصطناعي", date: "15 November 2026", days: "حفلة مكافآت ونهاية مبكرة", badge: "مبادرة داخلية", color: "border-rose-500/40 bg-rose-950/20 text-rose-300" },
            ].map((hol, idx) => (
              <div key={idx} className={`p-5 rounded-3xl border ${hol.color} flex flex-col justify-between space-y-3 shadow-lg hover:scale-[1.02] transition-transform`}>
                <div className="flex items-start justify-between">
                  <span className="font-bold text-sm text-white">{hol.title}</span>
                  <CalendarDays className="w-5 h-5 flex-shrink-0 opacity-80" />
                </div>
                <div className="text-xs font-mono font-bold text-slate-200 mt-1">{hol.date}</div>
                <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] font-bold">
                  <span className="text-emerald-300">{hol.days}</span>
                  <span className="px-2 py-0.5 bg-black/40 rounded-lg">{hol.badge}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
