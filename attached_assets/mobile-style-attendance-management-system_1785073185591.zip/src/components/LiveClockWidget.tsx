"use client";
import React, { useState, useEffect } from "react";
import { Clock, Calendar, Globe } from "lucide-react";

interface ClockProps {
  mode?: string; // "digital" | "analog" | "3d_cyber" | "minimalist"
  showSeconds?: boolean;
  showDate?: boolean;
  language?: string; // "ar" | "en"
}

export default function LiveClockWidget({
  mode = "3d_cyber",
  showSeconds = true,
  showDate = true,
  language = "ar",
}: ClockProps) {
  const [time, setTime] = useState(new Date());
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!mounted) {
    return (
      <div className="h-14 w-44 bg-slate-800/40 animate-pulse rounded-2xl flex items-center justify-center text-xs text-slate-400">
        تحميل الساعة الحية...
      </div>
    );
  }

  const hours = time.getHours();
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();

  const hours12 = hours % 12 || 12;
  const ampm = hours >= 12 ? (language === "ar" ? "م" : "PM") : (language === "ar" ? "ص" : "AM");

  const formattedTime = `${hours12 < 10 ? "0" + hours12 : hours12}:${minutes < 10 ? "0" + minutes : minutes}${
    showSeconds ? `:${seconds < 10 ? "0" + seconds : seconds}` : ""
  } ${ampm}`;

  const options: Intl.DateTimeFormatOptions = {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
  };

  const dateStr = time.toLocaleDateString(language === "ar" ? "ar-SA" : "en-US", options);

  // Analog Clock Math
  const secondDeg = seconds * 6;
  const minuteDeg = minutes * 6 + seconds * 0.1;
  const hourDeg = (hours % 12) * 30 + minutes * 0.5;

  if (mode === "analog") {
    return (
      <div className="flex items-center gap-3 bg-gradient-to-r from-slate-900/80 to-indigo-950/80 backdrop-blur-md px-4 py-2 rounded-2xl border border-indigo-500/30 shadow-lg shadow-indigo-500/10">
        <div className="relative w-12 h-12 rounded-full border-2 border-indigo-400/60 bg-slate-950 flex items-center justify-center shadow-inner">
          {/* Numbers points */}
          <div className="absolute top-0.5 w-1 h-1 bg-indigo-300 rounded-full"></div>
          <div className="absolute bottom-0.5 w-1 h-1 bg-indigo-300 rounded-full"></div>
          <div className="absolute left-0.5 w-1 h-1 bg-indigo-300 rounded-full"></div>
          <div className="absolute right-0.5 w-1 h-1 bg-indigo-300 rounded-full"></div>

          {/* Hour Hand */}
          <div
            className="absolute w-0.5 h-3 bg-indigo-200 rounded-full origin-bottom bottom-6 transition-transform duration-300"
            style={{ transform: `rotate(${hourDeg}deg)` }}
          />
          {/* Minute Hand */}
          <div
            className="absolute w-0.5 h-4 bg-cyan-400 rounded-full origin-bottom bottom-6 transition-transform duration-300"
            style={{ transform: `rotate(${minuteDeg}deg)` }}
          />
          {/* Second Hand */}
          {showSeconds && (
            <div
              className="absolute w-[1px] h-4 bg-rose-500 rounded-full origin-bottom bottom-6 transition-transform duration-75"
              style={{ transform: `rotate(${secondDeg}deg)` }}
            />
          )}
          <div className="w-1.5 h-1.5 rounded-full bg-white z-10"></div>
        </div>

        <div className="flex flex-col text-right">
          <span className="text-xs font-mono font-bold text-cyan-300 tracking-wider">{formattedTime}</span>
          {showDate && <span className="text-[10px] text-slate-300 font-medium">{dateStr}</span>}
        </div>
      </div>
    );
  }

  if (mode === "3d_cyber") {
    return (
      <div className="relative group overflow-hidden bg-gradient-to-r from-indigo-900/40 via-purple-900/40 to-slate-900/60 backdrop-blur-xl px-4 py-2 rounded-2xl border border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.25)] flex items-center gap-3 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_25px_rgba(168,85,247,0.45)]">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 animate-pulse pointer-events-none" />
        <div className="w-9 h-9 rounded-xl bg-purple-500/20 flex items-center justify-center border border-purple-400/40 shadow-inner">
          <Clock className="w-5 h-5 text-purple-300 animate-spin" style={{ animationDuration: "12s" }} />
        </div>
        <div className="flex flex-col z-10">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base sm:text-lg font-mono font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-purple-300 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]">
              {hours12 < 10 ? "0" + hours12 : hours12}:{minutes < 10 ? "0" + minutes : minutes}
            </span>
            {showSeconds && (
              <span className="text-xs font-mono font-bold text-emerald-400 animate-pulse">
                :{seconds < 10 ? "0" + seconds : seconds}
              </span>
            )}
            <span className="text-[11px] font-bold text-purple-200 uppercase bg-purple-900/60 px-1 rounded">
              {ampm}
            </span>
          </div>
          {showDate && (
            <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
              <Calendar className="w-3 h-3 text-cyan-400" />
              <span>{dateStr}</span>
              <span className="text-[10px] bg-cyan-950/80 text-cyan-300 px-1 rounded font-mono">
                {language === "ar" ? "الرياض 5G" : "UTC+3"}
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Default Digital
  return (
    <div className="flex items-center gap-3 bg-slate-900/70 backdrop-blur-md px-4 py-2 rounded-2xl border border-slate-700/60 shadow-md">
      <Clock className="w-5 h-5 text-indigo-400" />
      <div className="flex flex-col">
        <span className="text-sm font-mono font-bold text-white tracking-wider">{formattedTime}</span>
        {showDate && <span className="text-[10px] text-slate-400">{dateStr}</span>}
      </div>
    </div>
  );
}
