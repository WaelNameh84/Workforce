"use client";
import React, { useState } from "react";
import { 
  DollarSign, Calculator, FileText, Download, Printer, 
  TrendingUp, TrendingDown, Shield, Sparkles, User, CheckCircle2, 
  Percent, RefreshCcw, CreditCard, Layers, X
} from "lucide-react";
import confetti from "canvas-confetti";

interface PayrollProps {
  language: string;
  payrolls: any[];
  employees: any[];
  onRefresh: () => void;
}

export default function PayrollModule({ language = "ar", payrolls = [], employees = [], onRefresh }: PayrollProps) {
  const [selectedEmpId, setSelectedEmpId] = useState<number>(employees[0]?.id || 1);
  const [showPayslipModal, setShowPayslipModal] = useState(false);
  const [simulatedBonus, setSimulatedBonus] = useState(2500);
  const [simulatedDeduction, setSimulatedDeduction] = useState(0);
  const [simulatedOvertimeHours, setSimulatedOvertimeHours] = useState(12);
  const [generating, setGenerating] = useState(false);

  const targetEmp = employees.find(e => e.id === Number(selectedEmpId)) || employees[0];
  const targetPay = payrolls.find(p => p.employeeId === Number(selectedEmpId)) || payrolls[0];

  // Calculations
  const basic = targetEmp?.basicSalary || 24000;
  const daily = targetEmp?.dailyWage || (basic / 25);
  const hourly = targetEmp?.hourlyWage || (daily / 8);
  const minuteRate = hourly / 60;
  const overtimePay = simulatedOvertimeHours * (hourly * 1.5);
  const insurance = Math.round(basic * 0.05); // 5% GOSI Insurance
  const tax = 0; // 0% income tax
  const finalSalary = Math.round(basic + overtimePay + simulatedBonus - simulatedDeduction - insurance - tax);

  const handleGeneratePayroll = async () => {
    setGenerating(true);
    try {
      const res = await fetch("/api/payroll/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          employeeId: selectedEmpId,
          monthYear: "April 2026",
          bonuses: simulatedBonus,
          deductions: simulatedDeduction,
          overtimeHours: simulatedOvertimeHours
        }),
      });
      const data = await res.json();
      if (data.status === "success") {
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
        onRefresh();
        setShowPayslipModal(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGenerating(false);
    }
  };

  const handlePrintPayslip = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950/70 to-slate-900 p-6 rounded-3xl border border-purple-500/30 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-emerald-400" />
            <span>{language === "ar" ? "نظام مسيرات الرواتب واحتساب الأجور والدقائق" : "Enterprise Payroll & Minute Wage Processor"}</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            {language === "ar" 
              ? "تفصيل حي للأجر الأساسي، الأجر اليومي والساعة، احتساب الدقائق (Minute Calc)، الساعات الإضافية، التأمينات وإصدار قسائم PDF."
              : "Precise card calculations for Basic Salary, Daily/Hourly Wage, Minute Calculation & Payslip generation."}
          </p>
        </div>

        {/* Employee selector */}
        <div className="w-full sm:w-auto p-2.5 bg-slate-950 rounded-2xl border border-slate-800 flex items-center gap-3">
          <img src={targetEmp?.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150"} alt="" className="w-11 h-11 rounded-xl object-cover border border-purple-500/50" />
          <div className="flex flex-col text-right pr-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase">{language === "ar" ? "حدد الموظف للحساب" : "Target Subject"}</span>
            <select
              value={selectedEmpId}
              onChange={(e) => setSelectedEmpId(Number(e.target.value))}
              className="bg-transparent font-black text-xs text-cyan-300 focus:outline-none cursor-pointer"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id} className="bg-slate-900 text-white">
                  {language === "ar" ? emp.fullNameAr : emp.fullNameEn}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 4 Core Wage Breakdown Cards (No Tables!) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Basic Salary */}
        <div className="p-5 rounded-3xl border border-slate-800 bg-gradient-to-b from-indigo-950/50 to-slate-900 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-indigo-400 pb-2">
            <span className="font-bold text-xs">{language === "ar" ? "الراتب الأساسي الشهري" : "Basic Salary"}</span>
            <CreditCard className="w-5 h-5" />
          </div>
          <div className="text-2xl font-black font-mono text-white mt-2">{basic?.toLocaleString()} <span className="text-xs font-sans text-slate-400">SAR</span></div>
          <div className="text-[10px] text-emerald-400 font-mono mt-2 font-bold">{language === "ar" ? "100% عقد دائم موثق" : "100% Contract Base"}</div>
        </div>

        {/* Card 2: Daily Wage */}
        <div className="p-5 rounded-3xl border border-slate-800 bg-gradient-to-b from-cyan-950/50 to-slate-900 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-cyan-400 pb-2">
            <span className="font-bold text-xs">{language === "ar" ? "الأجر اليومي المحتسب" : "Daily Wage Rate"}</span>
            <Layers className="w-5 h-5" />
          </div>
          <div className="text-2xl font-black font-mono text-cyan-300 mt-2">{daily?.toFixed(0)} <span className="text-xs font-sans text-slate-400">SAR/Day</span></div>
          <div className="text-[10px] text-slate-400 font-mono mt-2">{language === "ar" ? "مبني على 25 يوم عمل" : "Based on 25 working days"}</div>
        </div>

        {/* Card 3: Hourly Wage */}
        <div className="p-5 rounded-3xl border border-slate-800 bg-gradient-to-b from-amber-950/50 to-slate-900 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-400 pb-2">
            <span className="font-bold text-xs">{language === "ar" ? "أجر الساعة (Hourly)" : "Hourly Wage"}</span>
            <Calculator className="w-5 h-5" />
          </div>
          <div className="text-2xl font-black font-mono text-amber-300 mt-2">{hourly?.toFixed(1)} <span className="text-xs font-sans text-slate-400">SAR/Hr</span></div>
          <div className="text-[10px] text-slate-400 font-mono mt-2">{language === "ar" ? "8 ساعات دوام في اليوم" : "8 standard work hours/day"}</div>
        </div>

        {/* Card 4: Minute Calculation (Special highlight!) */}
        <div className="p-5 rounded-3xl border border-emerald-500/40 bg-gradient-to-b from-emerald-950/70 to-slate-900 shadow-[0_0_20px_rgba(16,185,129,0.2)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-300 pb-2">
            <span className="font-bold text-xs flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-yellow-400" /> {language === "ar" ? "احتساب الدقيقة (Minute Calc)" : "Minute Calculation"}
            </span>
            <span className="text-[10px] bg-emerald-500/20 px-1.5 py-0.5 rounded font-mono font-bold">PRECISION</span>
          </div>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-2">{minuteRate?.toFixed(2)} <span className="text-xs font-sans text-slate-300">SAR/Min</span></div>
          <div className="text-[10px] text-emerald-200 font-mono mt-2 font-bold">{language === "ar" ? "9,750 دقيقة عمل مؤكده هذا الشهر" : "9,750 verified active minutes"}</div>
        </div>
      </div>

      {/* Salary Computation & Final Total Interactive Studio Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Adjusters Card (Bonuses, Overtime, Deductions) */}
        <div className="lg:col-span-2 bg-slate-900/90 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl space-y-5">
          <h3 className="font-bold text-white text-base flex items-center justify-between border-b border-slate-800 pb-3">
            <span>{language === "ar" ? "محاكاة وضبط المتغيرات (Overtime, Bonuses & Deductions)" : "Dynamic Compensation & Adjustments Card"}</span>
            <span className="text-xs text-indigo-400 font-mono">{language === "ar" ? "تحديث تلقائي لحظي" : "Live reactive equation"}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Overtime Hours Slider */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-300">
                <span>{language === "ar" ? "ساعات العمل الإضافي" : "Overtime Hours"}</span>
                <span className="font-mono bg-indigo-900/60 px-2 py-0.5 rounded text-white">{simulatedOvertimeHours}h</span>
              </div>
              <input 
                type="range" min="0" max="40" step="1" 
                value={simulatedOvertimeHours} 
                onChange={(e) => setSimulatedOvertimeHours(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer" 
              />
              <div className="text-[11px] font-mono font-bold text-emerald-400 text-right">
                + {Math.round(overtimePay).toLocaleString()} SAR ({language === "ar" ? "بمعدل 150%" : "@ 150% rate"})
              </div>
            </div>

            {/* Bonuses Input */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-300">
                <span>{language === "ar" ? "المكافآت والحوافز (Bonuses)" : "Bonuses & KPI Reward"}</span>
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              </div>
              <input 
                type="number" 
                value={simulatedBonus} 
                onChange={(e) => setSimulatedBonus(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-slate-900 text-emerald-300 font-mono font-bold text-sm rounded-xl border border-slate-700" 
              />
              <div className="text-[10px] text-slate-400">{language === "ar" ? "مكافآت الإنتاجية والقيادة الذكية" : "AI Performance bonuses"}</div>
            </div>

            {/* Deductions Input */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-rose-400">
                <span>{language === "ar" ? "الخصومات والغياب (Deductions)" : "Deductions & Late Penalties"}</span>
                <TrendingDown className="w-4 h-4 text-rose-400" />
              </div>
              <input 
                type="number" 
                value={simulatedDeduction} 
                onChange={(e) => setSimulatedDeduction(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-slate-900 text-rose-300 font-mono font-bold text-sm rounded-xl border border-slate-700" 
              />
              <div className="text-[10px] text-slate-400">{language === "ar" ? "خصومات التأخر الصباحي التلقائية" : "Auto tardiness log reductions"}</div>
            </div>
          </div>

          {/* Taxes & Insurance Badges */}
          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div className="text-right">
                <span className="text-xs font-bold text-slate-300">{language === "ar" ? "التأمينات الاجتماعية (Insurance GOSI)" : "Social Insurance (GOSI)"}</span>
                <span className="block text-[10px] text-slate-500 font-mono">5% deduction amount</span>
              </div>
              <span className="text-sm font-mono font-bold text-amber-400">- {insurance.toLocaleString()} SAR</span>
            </div>

            <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div className="text-right">
                <span className="text-xs font-bold text-slate-300">{language === "ar" ? "الضرائب المستحقة (Taxes)" : "Income Taxes"}</span>
                <span className="block text-[10px] text-slate-500 font-mono">Local Kingdom Exemption (0%)</span>
              </div>
              <span className="text-sm font-mono font-bold text-emerald-400">0.00 SAR</span>
            </div>
          </div>
        </div>

        {/* Final Salary Checkout & Payslip Trigger Card */}
        <div className="bg-gradient-to-b from-indigo-950 via-slate-900 to-purple-950 p-6 rounded-3xl border border-purple-500/50 shadow-2xl flex flex-col justify-between space-y-6 text-center">
          <div>
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 text-xs font-mono rounded-full font-bold border border-emerald-500/30">
              {language === "ar" ? "الراتب النهائي المحتسب (Final Salary)" : "Final Netto Salary Computation"}
            </span>
            <div className="text-4xl font-mono font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-cyan-300 to-white mt-4 tracking-tight drop-shadow">
              {finalSalary.toLocaleString()}
            </div>
            <span className="text-xs text-purple-200 font-bold tracking-widest uppercase block mt-1">SAR (ريال سعودي صافي)</span>
          </div>

          <div className="text-[11px] text-slate-300 bg-black/40 p-3 rounded-2xl border border-white/10 text-right leading-relaxed">
            {language === "ar"
              ? `تم اعتماد الحسبة للموظف (${targetEmp?.fullNameAr}) لشهر أبريل 2026، متضمنةً الراتب الأساسي ومحاسبة הדקות وإصدار القسيمة الإلكترونية.`
              : `Audited payment tally for ${targetEmp?.fullNameEn} for April 2026 inclusive of GOSI, overtime minutes & AI efficiency bonus.`}
          </div>

          <button
            onClick={handleGeneratePayroll}
            disabled={generating}
            className="w-full py-4 bg-gradient-to-r from-emerald-500 via-cyan-500 to-indigo-600 hover:opacity-90 text-white font-black rounded-2xl shadow-xl flex items-center justify-center gap-2 transform active:scale-95 transition-all text-sm"
          >
            <FileText className="w-5 h-5 animate-bounce" />
            <span>{generating ? (language === "ar" ? "جاري إصدار الكشوف..." : "Generating...") : (language === "ar" ? "إصدار قسيمة كشف الراتب (Payslip PDF)" : "Generate Payslip PDF Card")}</span>
          </button>
        </div>
      </div>

      {/* Interactive Printable Payslip PDF Modal */}
      {showPayslipModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white text-slate-900 rounded-3xl p-8 shadow-2xl space-y-6 my-8 animate-scale-in relative border-[8px] border-slate-900">
            {/* Header & Logo */}
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-xl shadow">
                  EP
                </div>
                <div>
                  <h2 className="font-black text-xl text-slate-950">تطبيق دوام الذكي (Enterprise AI Punch)</h2>
                  <p className="text-xs text-slate-500 font-mono">Payslip Reference: PAY-2026-04-{targetEmp?.employeeNumber}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-mono rounded-lg font-black block w-max ml-auto">
                  PAID INVOICE
                </span>
                <span className="text-xs text-slate-600 font-bold block mt-1">تاريخ الإصدار: {new Date().toISOString().split("T")[0]}</span>
              </div>
            </div>

            {/* Employee Info Section */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-slate-100 rounded-2xl text-xs">
              <div className="text-right space-y-1">
                <div className="text-slate-500 font-bold">اسم الموظف الرسمي:</div>
                <div className="text-base font-black text-slate-950">{language === "ar" ? targetEmp?.fullNameAr : targetEmp?.fullNameEn}</div>
                <div className="text-slate-600 font-mono font-semibold">ID: {targetEmp?.employeeNumber}</div>
              </div>
              <div className="text-right space-y-1 border-r border-slate-200 pr-4">
                <div className="text-slate-500 font-bold">المسمى الوظيفي والقسم:</div>
                <div className="text-sm font-black text-indigo-900">{targetEmp?.position}</div>
                <div className="text-emerald-700 font-mono font-bold">IBAN Direct Deposit / 5G Bio Sync</div>
              </div>
            </div>

            {/* Breakdown Invoice Cards */}
            <div className="space-y-2">
              <h4 className="font-bold text-sm text-slate-800">تفاصيل البدلات والاستحواذ المالي (Breakdown):</h4>
              <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
                <div className="flex justify-between p-3.5 border-b border-slate-200 bg-slate-50 font-bold">
                  <span>الراتب الأساسي (Basic Salary - 25 Days / 160 Hours)</span>
                  <span className="font-mono">{basic.toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between p-3.5 border-b border-slate-200 font-bold text-indigo-700">
                  <span>مكافآت العمل الإضافي ({simulatedOvertimeHours} ساعات @ 150% Overtime Rate)</span>
                  <span className="font-mono">+ {Math.round(overtimePay).toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between p-3.5 border-b border-slate-200 bg-slate-50 font-bold text-emerald-700">
                  <span>المكافآت والحوافز الذكية (Bonuses & AI Efficiency)</span>
                  <span className="font-mono">+ {simulatedBonus.toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between p-3.5 border-b border-slate-200 font-bold text-rose-700">
                  <span>التأمينات الاجتماعية GOSI Insurance (5%)</span>
                  <span className="font-mono">- {insurance.toLocaleString()} SAR</span>
                </div>
                {simulatedDeduction > 0 && (
                  <div className="flex justify-between p-3.5 border-b border-slate-200 bg-rose-50 font-bold text-rose-700">
                    <span>خصومات التأخر الصباحي (Deductions & Late Arrival)</span>
                    <span className="font-mono">- {simulatedDeduction.toLocaleString()} SAR</span>
                  </div>
                )}
                <div className="flex justify-between p-4 bg-slate-950 text-white font-black text-base">
                  <span>إجمالي الراتب المستحق والصافي (Final Salary):</span>
                  <span className="font-mono text-emerald-400">{finalSalary.toLocaleString()} SAR</span>
                </div>
              </div>
            </div>

            {/* Signatures & Actions */}
            <div className="flex items-center justify-between pt-6 border-t-2 border-slate-200">
              <div className="text-[11px] text-slate-500">
                تم الإصدار والمصادقة آلياً عبر محرك الذكاء الاصطناعي وبصمة الـ WPA3 • لا يتطلب ختم ورقي
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowPayslipModal(false)}
                  className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl text-xs transition-all"
                >
                  إغلاق (Close)
                </button>
                <button
                  onClick={handlePrintPayslip}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-xl text-xs shadow-lg flex items-center gap-2 transition-all"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة وحفظ بصيغة PDF (Export PDF)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
