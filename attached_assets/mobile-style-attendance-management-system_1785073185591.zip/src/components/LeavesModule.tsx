"use client";
import React, { useState } from "react";
import { 
  Calendar, CheckCircle2, Clock, XCircle, Plus, Sparkles, 
  ShieldCheck, AlertTriangle, ChevronLeft, ArrowRight, UserCheck, X
} from "lucide-react";
import confetti from "canvas-confetti";

interface LeavesProps {
  language: string;
  leaves: any[];
  employees: any[];
  onRefresh: () => void;
}

export default function LeavesModule({ language = "ar", leaves = [], employees = [], onRefresh }: LeavesProps) {
  const [showModal, setShowModal] = useState(false);
  const [selectedEmp, setSelectedEmp] = useState<number>(employees[0]?.id || 1);
  const [leaveType, setLeaveType] = useState("Annual Leave (إجازة سنوية)");
  const [daysCount, setDaysCount] = useState(5);
  const [reason, setReason] = useState("");

  const handleSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/leaves/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          employeeId: selectedEmp,
          leaveType,
          startDate: new Date().toISOString().split("T")[0],
          endDate: new Date(Date.now() + daysCount * 86400000).toISOString().split("T")[0],
          daysCount,
          reason: reason || "طلب عبر منصة الكروت الذكية"
        }),
      });
      const data = await res.json();
      if (data.status === "success") {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
        setShowModal(false);
        onRefresh();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleStatusChange = async (leaveId: number, newStatus: string) => {
    try {
      await fetch("/api/leaves/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "status", leaveId, status: newStatus, step: `حالة معتمدة (${newStatus}) عبر المدير` }),
      });
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Title & Quick Actions */}
      <div className="bg-slate-900/80 backdrop-blur-2xl p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-emerald-400" />
            <span>{language === "ar" ? "إدارة الإجازات، أرصدة الأيام ودورة الموافقة الذكية" : "Leave Management & Approval Workflow Cards"}</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            {language === "ar"
              ? "متابعة دقيقة للأرصدة المتبقية (سنوية، مرضية، طارئة، أمومة، بدون أجر) مع تدقيق الاعتماد الذكي (AI Approval Workflow)."
              : "Visual balances for Annual, Sick, Emergency & Unpaid leave requests with instant AI status routing."}
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 font-bold text-white text-xs rounded-2xl shadow-lg flex items-center gap-2 transition-transform active:scale-95"
        >
          <Plus className="w-4 h-4 text-white" />
          <span>{language === "ar" ? "تقديم طلب إجازة جديد (New Request)" : "Submit Leave Request"}</span>
        </button>
      </div>

      {/* 5 Leave Type Balance Meter Cards (No Tables!) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {[
          { title: language === "ar" ? "الإجازة السنوية" : "Annual Leave", balance: "21 أيام", total: 30, pct: "70%", color: "from-emerald-900/60 to-slate-900 border-emerald-500/40 text-emerald-400" },
          { title: language === "ar" ? "الإجازة المرضية" : "Sick Leave", balance: "14 أيام", total: 15, pct: "93%", color: "from-cyan-900/60 to-slate-900 border-cyan-500/40 text-cyan-400" },
          { title: language === "ar" ? "الإجازة الطارئة" : "Emergency Leave", balance: "5 أيام", total: 5, pct: "100%", color: "from-amber-900/60 to-slate-900 border-amber-500/40 text-amber-400" },
          { title: language === "ar" ? "إجازة الأمومة والولادة" : "Maternity Leave", balance: "70 يوماً", total: 70, pct: "100%", color: "from-purple-900/60 to-slate-900 border-purple-500/40 text-purple-400" },
          { title: language === "ar" ? "إجازة غير مدفوعة الأجر" : "Unpaid Leave", balance: "حسب الطلب", total: 30, pct: "N/A", color: "from-rose-900/60 to-slate-900 border-rose-500/40 text-rose-400" },
        ].map((item, i) => (
          <div key={i} className={`p-4 rounded-3xl border bg-gradient-to-b ${item.color} flex flex-col justify-between shadow-md text-center`}>
            <div className="font-bold text-xs text-white truncate">{item.title}</div>
            <div className="my-3 flex flex-col items-center justify-center">
              <div className="w-14 h-14 rounded-full bg-slate-950 border-4 border-current flex items-center justify-center shadow-inner font-mono font-black text-sm text-white">
                {item.pct}
              </div>
            </div>
            <div className="text-xs font-mono font-bold text-slate-300">{item.balance} {language === "ar" ? "متبقي" : "Left"}</div>
          </div>
        ))}
      </div>

      {/* Approval Workflow Interactive Tracker Card */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 rounded-3xl border border-indigo-500/30 shadow-xl">
        <h3 className="text-base font-bold text-white flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-yellow-400 animate-pulse" />
          <span>{language === "ar" ? "دورة الموافقة الآلية والتحقق الذكي (Approval Workflow Protocol)" : "Automated Leave Approval Workflow Step Protocol"}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[
            { step: "1. Submission", ar: "1. إيداع الطلب بالمحمول", desc: "الموظف يقدم الطلب وتحديد أيام الغياب.", status: "Done", icon: CheckCircle2, color: "text-emerald-400 border-emerald-500/40" },
            { step: "2. AI Balance Check", ar: "2. تدقيق الذكاء الاصطناعي", desc: "التحقق من الرصيد وعدم تعارض مواعيد المناوبة.", status: "Done", icon: CheckCircle2, color: "text-cyan-400 border-cyan-500/40" },
            { step: "3. HR Director Review", ar: "3. موافقة مدير الموارد", desc: "المراجعة النهائية واعتمادات شؤون الموظفين.", status: "Active", icon: Clock, color: "text-amber-400 border-amber-500/40 animate-pulse" },
            { step: "4. Schedule Sync", ar: "4. التحديث التلقائي لروزنامة الورديات", desc: "تخصيص بديل للمناوبة ونشر التقرير الشهري.", status: "Pending", icon: UserCheck, color: "text-purple-400 border-purple-500/40" },
          ].map((s, idx) => {
            const Icon = s.icon;
            return (
              <div key={idx} className={`p-4 bg-slate-950/80 rounded-2xl border ${s.color} flex flex-col justify-between space-y-2 relative shadow-sm`}>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-white">{language === "ar" ? s.ar : s.step}</span>
                  <Icon className="w-4 h-4" />
                </div>
                <p className="text-[11px] text-slate-400 leading-tight">{s.desc}</p>
                <div className="text-[10px] font-mono font-bold uppercase opacity-80 pt-1 border-t border-slate-800">{s.status}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live Leave Requests Card Gallery (No Tables!) */}
      <div className="space-y-3">
        <h3 className="font-bold text-white text-base flex items-center gap-2">
          <span>{language === "ar" ? "سجل طلبات الإجازة المسجلة حالياً في النظام" : "Active & Recent Leave Request Cards"}</span>
        </h3>
        {leaves.map((l) => {
          const emp = employees.find(e => e.id === l.employeeId);
          const isApproved = l.status === "Approved";
          const isPending = l.status === "Pending";
          return (
            <div key={l.id} className="p-5 bg-slate-900/90 rounded-3xl border border-slate-800 hover:border-slate-700 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all">
              <div className="flex items-center gap-4">
                <img src={emp?.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} alt="" className="w-12 h-12 rounded-2xl object-cover border-2 border-indigo-400 shadow-sm" />
                <div className="text-right">
                  <div className="font-bold text-sm text-white flex items-center gap-2">
                    <span>{language === "ar" ? (emp?.fullNameAr || "موظف مجهول") : (emp?.fullNameEn || "Staff Member")}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${isApproved ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-amber-500/20 text-amber-300 border border-amber-500/30"}`}>
                      {l.status}
                    </span>
                  </div>
                  <div className="text-xs text-cyan-300 font-bold mt-0.5">{l.leaveType} • <span className="font-mono text-slate-300">{l.daysCount} أيام</span> ({l.startDate} ➔ {l.endDate})</div>
                  <div className="text-[11px] text-slate-400 mt-1 italic">"{l.reason}"</div>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                {isPending ? (
                  <>
                    <button 
                      onClick={() => handleStatusChange(l.id, "Approved")}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl text-xs shadow-md transition-all flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{language === "ar" ? "اعتماد الطلب" : "Approve"}</span>
                    </button>
                    <button 
                      onClick={() => handleStatusChange(l.id, "Rejected")}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-2xl text-xs shadow-md transition-all flex items-center gap-1"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>{language === "ar" ? "رفض" : "Reject"}</span>
                    </button>
                  </>
                ) : (
                  <span className="text-xs font-mono font-bold text-slate-400 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
                    {l.approvalWorkflowStep || "Step: Final Approved"}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Leave Request Submission Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-3xl border border-emerald-500/40 p-6 shadow-2xl space-y-4 animate-scale-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-black text-lg text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-400" />
                <span>{language === "ar" ? "تقديم إجازة ورصيد جديد" : "Submit Leave Request Card"}</span>
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitLeave} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "الموظف مقدم الطلب" : "Employee"}</label>
                <select 
                  value={selectedEmp} 
                  onChange={(e) => setSelectedEmp(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-slate-950 rounded-xl border border-slate-700 text-white font-bold text-xs"
                >
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{language === "ar" ? emp.fullNameAr : emp.fullNameEn}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "نوع الإجازة المطلوبة" : "Leave Type"}</label>
                <select 
                  value={leaveType} 
                  onChange={(e) => setLeaveType(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 rounded-xl border border-slate-700 text-cyan-300 font-bold text-xs"
                >
                  <option value="Annual Leave (إجازة سنوية رصيد)">الإجازة السنوية (Annual Leave - 21 Days)</option>
                  <option value="Sick Leave (إجازة مرضية مبررة)">الإجازة المرضية (Sick Leave - 15 Days)</option>
                  <option value="Emergency Leave (إجازة طارئة مستعجلة)">الإجازة الطارئة (Emergency Leave - 5 Days)</option>
                  <option value="Maternity Leave (إجازة أمومة وولادة)">إجازة الأمومة والولادة (Maternity Leave - 70 Days)</option>
                  <option value="Unpaid Leave (إجازة بدون أجر)">إجازة غير مدفوعة الأجر (Unpaid Leave)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "عدد الأيام المطلوبة" : "Days Count"}</label>
                <input 
                  type="number" 
                  min="1" max="30" 
                  value={daysCount} 
                  onChange={(e) => setDaysCount(Number(e.target.value))}
                  className="w-full px-3.5 py-2 bg-slate-950 rounded-xl border border-slate-700 text-white font-mono font-black text-sm"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">{language === "ar" ? "سبب الإجازة والتفاصيل" : "Reason & Medical Notes"}</label>
                <textarea 
                  rows={2} 
                  value={reason} 
                  onChange={(e) => setReason(e.target.value)} 
                  placeholder="مثال: إجازة سفر عائلية أو تقرير طبي مبرر من منصة صحتي..."
                  className="w-full px-3.5 py-2 bg-slate-950 rounded-xl border border-slate-700 text-white text-xs font-bold"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-800">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs text-slate-300 font-bold">
                  {language === "ar" ? "إلغاء" : "Cancel"}
                </button>
                <button type="submit" className="px-6 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 rounded-xl text-xs font-bold text-white shadow-lg">
                  {language === "ar" ? "تأكيد وإيداع في مسار الموافقة" : "Submit Leave Request"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
