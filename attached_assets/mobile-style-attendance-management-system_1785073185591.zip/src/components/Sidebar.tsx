"use client";
import React, { useState } from "react";
import { 
  Network, ScanFace, LayoutDashboard, Users, Clock, CalendarDays, 
  DollarSign, BarChart3, Bell, Cpu, ShieldCheck, Settings, Database, 
  ChevronRight, ChevronLeft, Calendar, Sparkles, ShieldAlert 
} from "lucide-react";

interface SidebarProps {
  language: "ar" | "en";
  activeTab: string;
  onSelectTab: (tab: string) => void;
  systemData: any;
}

export default function Sidebar({ language = "ar", activeTab, onSelectTab, systemData }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Complete List of ALL 13 Sections + Master Schema Map
  const navItems = [
    { id: "master_map", ar: "المخطط الهيكلي الشامل", en: "Master Schema Map", icon: Network, badge: "100%", color: "text-cyan-400 border-cyan-500/30 bg-cyan-950/40" },
    { id: "auth", ar: "1. المصادقة والـ Face ID", en: "1. Authentication", icon: ScanFace, badge: "7 Leaves", color: "text-blue-400 border-blue-500/30 bg-blue-950/30" },
    { id: "dashboard", ar: "2. لوحة القيادة الحية", en: "2. Executive Dashboard", icon: LayoutDashboard, badge: "Live", color: "text-indigo-400 border-indigo-500/30 bg-indigo-950/30" },
    { id: "employees", ar: "3. شؤون والملف للموظفين", en: "3. Employee Management", icon: Users, badge: `${systemData.employees?.length || 6}`, color: "text-purple-400 border-purple-500/30 bg-purple-950/30" },
    { id: "attendance", ar: "4. الحضور ولمس البصمة", en: "4. Attendance & Touch", icon: Clock, badge: "5G", color: "text-emerald-400 border-emerald-500/30 bg-emerald-950/30" },
    { id: "shifts", ar: "5. الورديات والتناوب", en: "5. Shift Management", icon: CalendarDays, badge: "5 Shifts", color: "text-amber-400 border-amber-500/30 bg-amber-950/30" },
    { id: "leaves", ar: "6. الإجازات والأرصدة", en: "6. Leave Management", icon: Calendar, badge: "21 Days", color: "text-teal-400 border-teal-500/30 bg-teal-950/30" },
    { id: "payroll", ar: "7. الرواتب واحتساب الدقيقة", en: "7. Payroll & Minute Calc", icon: DollarSign, badge: "SAR", color: "text-emerald-300 border-emerald-400/50 bg-emerald-950/50" },
    { id: "reports", ar: "8. التقارير التحليلية والتصدير", en: "8. Reports & Exporter", icon: BarChart3, badge: "CSV/PDF", color: "text-cyan-300 border-cyan-500/30 bg-cyan-950/30" },
    { id: "notifications", ar: "9. الإشعارات ورسائل البث", en: "9. Notifications", icon: Bell, badge: "4 Channels", color: "text-orange-400 border-orange-500/30 bg-orange-950/30" },
    { id: "ai", ar: "10. محرك الذكاء والمستشار", en: "10. AI Engine & Aura Bot", icon: Cpu, badge: "GPT-4o", color: "text-pink-400 border-pink-500/30 bg-pink-950/30" },
    { id: "security", ar: "11. الأمن السيبراني والتدقيق", en: "11. Security & Vault", icon: ShieldCheck, badge: "AES-256", color: "text-rose-400 border-rose-500/30 bg-rose-950/30" },
    { id: "settings", ar: "12. مركز التحكم الشامل MCC", en: "12. Settings MCC (8 Mods)", icon: Settings, badge: "110+ Items", color: "text-purple-300 border-purple-400 bg-purple-950/50" },
    { id: "database", ar: "13. جداول قاعدة البيانات (15)", en: "13. Database (15 Tables)", icon: Database, badge: "15 Tables", color: "text-emerald-400 border-emerald-500/40 bg-emerald-950/40" },
  ];

  return (
    <aside
      className={`sticky top-0 h-screen bg-slate-950/95 backdrop-blur-2xl border-x border-slate-800/80 shadow-2xl flex flex-col justify-between transition-all duration-300 z-50 flex-shrink-0 ${
        isCollapsed ? "w-20" : "w-72"
      }`}
    >
      {/* Sidebar Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between gap-2">
        {!isCollapsed && (
          <div className="flex items-center gap-3 truncate">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-600 to-cyan-400 flex items-center justify-center font-black text-white text-base shadow-lg shadow-indigo-500/30 flex-shrink-0">
              EA
            </div>
            <div className="truncate">
              <span className="font-black text-sm text-white block truncate">
                {language === "ar" ? "قائمة الأقسام الـ13" : "Executive Navigation"}
              </span>
              <span className="text-[10px] text-cyan-400 font-mono font-bold block truncate">
                {language === "ar" ? "كل قسم مستقل بذاته" : "13 Roots Isolated"}
              </span>
            </div>
          </div>
        )}

        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-xl border border-slate-800 shadow-sm transition-transform active:scale-95 mx-auto"
          title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
        >
          {isCollapsed ? (
            language === "ar" ? <ChevronLeft className="w-5 h-5 text-cyan-400" /> : <ChevronRight className="w-5 h-5 text-cyan-400" />
          ) : (
            language === "ar" ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />
          )}
        </button>
      </div>

      {/* Navigation Links Deck (All 13 architecture sections, each in its own card-row) */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-3 space-y-2">
        <div className="text-[10px] font-mono font-bold uppercase text-slate-400 px-2 mb-1">
          {!isCollapsed ? (language === "ar" ? "تصفح أقسام النظام المنفردة:" : "System Architecture Roots:") : "•"}
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full group px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all flex items-center justify-between gap-3 shadow-sm border active:scale-[0.98] ${
                isActive
                  ? "bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 text-white border-white/40 shadow-lg shadow-indigo-500/25 scale-[1.02]"
                  : `bg-slate-900/60 hover:bg-slate-800 text-slate-300 border-slate-800/80 hover:text-white hover:border-indigo-500/40`
              }`}
            >
              <div className="flex items-center gap-3 truncate">
                <div className={`p-2 rounded-xl border transition-transform group-hover:scale-110 flex-shrink-0 ${
                  isActive ? "bg-slate-950 text-yellow-300 border-white/20 shadow-inner" : item.color
                }`}>
                  <Icon className={`w-4 h-4 ${isActive ? "animate-pulse" : ""}`} />
                </div>
                {!isCollapsed && (
                  <span className="truncate tracking-tight font-black text-[13px]">
                    {language === "ar" ? item.ar : item.en}
                  </span>
                )}
              </div>

              {!isCollapsed && item.badge && (
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-lg font-extrabold flex-shrink-0 ${
                  isActive ? "bg-white text-slate-950 shadow-sm" : "bg-slate-950 text-cyan-300 border border-slate-800"
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Footer Info in Sidebar */}
      {!isCollapsed ? (
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/80 text-center space-y-2">
          <div className="p-3 bg-gradient-to-r from-indigo-950/60 to-purple-950/60 rounded-2xl border border-purple-500/30 text-right">
            <span className="text-xs font-black text-white flex items-center gap-1.5 justify-center">
              <Sparkles className="w-4 h-4 text-yellow-300 animate-spin" style={{ animationDuration: "10s" }} />
              <span>{language === "ar" ? "نظام بدون جداول روتينية" : "Zero Primitive Tables"}</span>
            </span>
            <span className="text-[10px] text-slate-400 block text-center mt-1 font-mono">
              100% Mobile Touch Card UI
            </span>
          </div>
          <div className="text-[10px] font-mono text-emerald-400 font-bold flex items-center justify-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>AI Geofence Matrix Active</span>
          </div>
        </div>
      ) : (
        <div className="p-3 border-t border-slate-800 flex items-center justify-center">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" title="System Online" />
        </div>
      )}
    </aside>
  );
}
