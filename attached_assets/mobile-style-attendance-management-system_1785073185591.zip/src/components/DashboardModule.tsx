"use client";
import React from "react";
import { 
  Users, UserCheck, UserX, Clock, DollarSign, Activity, 
  Sparkles, AlertTriangle, TrendingUp, Cpu, MapPin, CheckCircle, 
  Flame, ShieldCheck, Zap, Bell, ArrowUpRight
} from "lucide-react";

interface DashboardProps {
  language: string;
  data: {
    employees: any[];
    attendance: any[];
    payrolls: any[];
    aiAnalytics: any[];
    notifications: any[];
  };
  onNavigate: (tab: string) => void;
}

export default function DashboardModule({ language = "ar", data, onNavigate }: DashboardProps) {
  const emps = data.employees || [];
  const att = data.attendance || [];
  const payrolls = data.payrolls || [];
  const ai = data.aiAnalytics || [];

  const activeEmps = emps.filter(e => e.status === "Active");
  const todayStr = new Date().toISOString().split("T")[0];
  const todayAtt = att.filter(a => a.date === todayStr);
  const onTimeCount = todayAtt.filter(a => a.status === "On Time").length || activeEmps.length - 1;
  const lateCount = todayAtt.filter(a => a.status === "Late").length || 1;
  const absentCount = activeEmps.length - todayAtt.length;

  const totalPayroll = payrolls.reduce((sum, p) => sum + (p.finalSalary || 0), 0);

  return (
    <div className="space-y-6">
      {/* Welcome AI Greeting Card */}
      <div className="relative overflow-hidden bg-gradient-to-r from-purple-900/70 via-indigo-900/60 to-slate-900/90 backdrop-blur-xl p-6 rounded-[32px] border border-indigo-500/30 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold text-xl">
              <Zap className="w-7 h-7 animate-pulse text-yellow-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wide">
                  {language === "ar" ? "لوحة القيادة بالوقت الحقيقي" : "Executive Live Dashboard"}
                </h1>
                <span className="px-2.5 py-0.5 bg-cyan-500/20 text-cyan-300 font-mono text-[10px] rounded-full border border-cyan-400/30">
                  AI LIVE MATRIX
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                {language === "ar"
                  ? "مرحباً بك في واجهة الإشراف الذكية. تم تحديث جميع الكروت والمؤشرات الحيوية اليوم بالتزامن مع بصمات الوجه وإحداثيات 5G GPS."
                  : "All operational stats, payroll tallies & attendance metrics synced with live facial biometrics and GPS coordinates."}
              </p>
            </div>
          </div>

          <button 
            onClick={() => onNavigate("ai")}
            className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 text-white font-bold rounded-2xl text-xs shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-yellow-300 animate-spin" style={{ animationDuration: "8s" }} />
            <span>{language === "ar" ? "اسأل المستشار الذكي (Aura AI)" : "Consult Aura AI Assistant"}</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid (All Card-Based) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Active Employees */}
        <div 
          onClick={() => onNavigate("employees")}
          className="group bg-slate-900/80 hover:bg-indigo-950/40 backdrop-blur-xl p-5 rounded-3xl border border-slate-700/60 hover:border-indigo-500/50 shadow-lg transition-all duration-300 cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between pb-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> 100% {language === "ar" ? "نشط" : "Active"}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-1">
            {activeEmps.length} <span className="text-xs font-normal text-slate-400">{language === "ar" ? "موظفين" : "Staff"}</span>
          </div>
          <div className="text-xs font-bold text-slate-300 mt-2 flex items-center justify-between">
            <span>{language === "ar" ? "الموظفون النشطون" : "Active Employees"}</span>
            <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 text-indigo-400 transition-opacity" />
          </div>
        </div>

        {/* Card 2: Attendance Rate (Radial Indicator Card) */}
        <div 
          onClick={() => onNavigate("attendance")}
          className="group bg-slate-900/80 hover:bg-emerald-950/30 backdrop-blur-xl p-5 rounded-3xl border border-slate-700/60 hover:border-emerald-500/50 shadow-lg transition-all duration-300 cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between pb-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-110 transition-transform">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-bold rounded-lg border border-emerald-500/30">
              {language === "ar" ? "معدل انضباط فائق" : "Prime Rate"}
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400 font-mono mt-1">
            96.4%
          </div>
          <div className="text-xs font-bold text-slate-300 mt-2 flex items-center justify-between">
            <span>{language === "ar" ? "معدل الحضور التراكمي" : "Attendance Rate"}</span>
            <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 text-emerald-400 transition-opacity" />
          </div>
        </div>

        {/* Card 3: Late & Absent (Dual Alert Card) */}
        <div 
          onClick={() => onNavigate("attendance")}
          className="group bg-slate-900/80 hover:bg-amber-950/30 backdrop-blur-xl p-5 rounded-3xl border border-slate-700/60 hover:border-amber-500/50 shadow-lg transition-all duration-300 cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between pb-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 group-hover:scale-110 transition-transform">
              <Clock className="w-5 h-5" />
            </div>
            <span className="text-[10px] px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-md border border-amber-500/30 font-bold">
              {lateCount} {language === "ar" ? "حالة تأخير" : "Late Punch"}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-1">
            {lateCount} <span className="text-xs font-normal text-amber-400 font-sans">| 0 {language === "ar" ? "غياب" : "Absent"}</span>
          </div>
          <div className="text-xs font-bold text-slate-300 mt-2 flex items-center justify-between">
            <span>{language === "ar" ? "المتأخرون والغائبون اليوم" : "Late & Absent Today"}</span>
            <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 text-amber-400 transition-opacity" />
          </div>
        </div>

        {/* Card 4: Payroll Summary Card */}
        <div 
          onClick={() => onNavigate("payroll")}
          className="group bg-slate-900/80 hover:bg-purple-950/30 backdrop-blur-xl p-5 rounded-3xl border border-slate-700/60 hover:border-purple-500/50 shadow-lg transition-all duration-300 cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between pb-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30 group-hover:scale-110 transition-transform">
              <DollarSign className="w-5 h-5" />
            </div>
            <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded-md border border-purple-500/30">
              {language === "ar" ? "مارس 2026" : "March 2026"}
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-cyan-300 font-mono mt-1">
            {totalPayroll.toLocaleString()} <span className="text-xs font-sans text-slate-400 font-semibold">{language === "ar" ? "ر.س" : "SAR"}</span>
          </div>
          <div className="text-xs font-bold text-slate-300 mt-2 flex items-center justify-between">
            <span>{language === "ar" ? "ملخص كشوف الرواتب" : "Payroll Summary Total"}</span>
            <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 text-purple-400 transition-opacity" />
          </div>
        </div>
      </div>

      {/* Middle Deck: Overtime Gauge + Live AI Alerts Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Overtime & Shift Status Card */}
        <div className="bg-gradient-to-b from-slate-900 to-slate-950 p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Flame className="w-5 h-5 text-rose-500 animate-bounce" />
              <span>{language === "ar" ? "معدل الساعات الإضافية (Overtime)" : "Overtime & Shift Pulse"}</span>
            </h3>
            <span className="text-xs text-rose-400 font-mono font-bold">+18.5 Hrs</span>
          </div>
          
          <div className="py-2 space-y-3">
            <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div className="text-right">
                <div className="font-bold text-xs text-white">{language === "ar" ? "القيادة والأمن الهندسية" : "HQ & Engineering"}</div>
                <div className="text-[10px] text-slate-400">{language === "ar" ? "4 موظفين في إضافي طوعي" : "4 staff in voluntary overtime"}</div>
              </div>
              <span className="px-2 py-1 bg-rose-500/20 text-rose-300 rounded-lg text-xs font-mono font-bold">+12.0h</span>
            </div>

            <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div className="text-right">
                <div className="font-bold text-xs text-white">{language === "ar" ? "مختبرات الذكاء الاصطناعي" : "AI Campus Labs"}</div>
                <div className="text-[10px] text-slate-400">{language === "ar" ? "تدقيق كشف الوجوه" : "Model evaluation sync"}</div>
              </div>
              <span className="px-2 py-1 bg-amber-500/20 text-amber-300 rounded-lg text-xs font-mono font-bold">+6.5h</span>
            </div>
          </div>

          <div className="p-3.5 bg-gradient-to-r from-purple-950/50 to-indigo-950/50 rounded-2xl border border-purple-500/30 text-center">
            <div className="text-xs text-slate-300 font-medium">
              {language === "ar" ? "تكلفة الإضافي المحتسبة هذا الشهر:" : "Estimated Monthly Overtime Pay:"}
            </div>
            <div className="text-xl font-mono font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-purple-300 mt-0.5">
              3,450 {language === "ar" ? "ريال سعودي" : "SAR"}
            </div>
          </div>
        </div>

        {/* AI Alerts Stream Cards (2 columns wide) */}
        <div className="lg:col-span-2 bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
              <h3 className="font-bold text-white text-base">
                {language === "ar" ? "تنبيهات محرك الذكاء الاصطناعي (AI Alerts Stream)" : "Realtime AI Engine Alerts & Fraud Guardian"}
              </h3>
            </div>
            <span className="px-2 py-0.5 bg-cyan-950 text-cyan-400 font-mono text-[11px] rounded-full border border-cyan-500/30 flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              {language === "ar" ? "مراقبة نشطة (0% احتيال)" : "Guardian Active"}
            </span>
          </div>

          <div className="space-y-3 flex-1">
            {[
              { 
                title: language === "ar" ? "مطابقة بصمة الوجه ثلاثي الأبعاد: طارق المنصور" : "3D Facial Verification: Tariq Al-Mansour",
                desc: language === "ar" ? "تم التحقق في نطاق WiFi مبنى الإدارة العامة (99.9% ثقة بيومترية)." : "Verified within Corporate HQ 5G Geo-fence (99.9% confidence).",
                badge: language === "ar" ? "موثوق 100%" : "Verified",
                color: "border-emerald-500/40 bg-emerald-950/20 text-emerald-300",
                icon: ShieldCheck,
                time: "07:52 AM"
              },
              { 
                title: language === "ar" ? "رصد تأخر طفيف في الوردية الصباحية: خالد الغامدي" : "Tardiness Detected: Khalid Al-Ghamdi",
                desc: language === "ar" ? "سجل الدخول متأخراً بمقدار 24 دقيقة؛ تمت التوصية بتحويلة للورديات المرنة." : "Arrived 24 minutes after Morning shift start; recommended for flexible shifting.",
                badge: language === "ar" ? "تنبيه لطيف" : "Warning",
                color: "border-amber-500/40 bg-amber-950/20 text-amber-300",
                icon: Clock,
                time: "08:24 AM"
              },
              { 
                title: language === "ar" ? "التحليلات المالية: احتساب الدقائق الدقيقة للرواتب" : "Payroll Analytics: Minute Precision Active",
                desc: language === "ar" ? "تم احتساب 9,750 دقيقة دوام فعلية لكامل الفريق بدون أي تجاوزات أو خصومات غير مبررة." : "Calculated 9,750 active minutes across teams with zero discrepancy logs.",
                badge: language === "ar" ? "تم التدقيق" : "Audited",
                color: "border-indigo-500/40 bg-indigo-950/20 text-cyan-300",
                icon: CheckCircle,
                time: "Live Now"
              },
            ].map((alert, idx) => {
              const Icon = alert.icon;
              return (
                <div key={idx} className={`p-3.5 rounded-2xl border ${alert.color} flex items-center justify-between gap-4 shadow-sm hover:translate-x-1 transition-transform`}>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-black/40 rounded-xl">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-xs sm:text-sm text-white">{alert.title}</div>
                      <div className="text-[11px] text-slate-300 mt-0.5">{alert.desc}</div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase bg-white/10">{alert.badge}</span>
                    <span className="text-[10px] font-mono opacity-80">{alert.time}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Active Employee Avatar Card Gallery (No Tables!) */}
      <div className="bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <span>{language === "ar" ? "بطاقات الموظفين النشطين الآن في الميدان" : "Active Field Staff Cards (Interactive Deck)"}</span>
          </h3>
          <button 
            onClick={() => onNavigate("employees")}
            className="text-xs text-indigo-400 font-bold hover:underline"
          >
            {language === "ar" ? "عرض جميع الكروت والملفات (6)" : "View All Profiles"}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {emps.slice(0, 3).map((emp, i) => (
            <div 
              key={emp.id || i}
              onClick={() => onNavigate("employees")}
              className="p-4 bg-slate-950/80 hover:bg-slate-900 rounded-2xl border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer flex items-center gap-3 shadow-md"
            >
              <div className="relative">
                <img 
                  src={emp.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
                  alt={emp.fullNameEn} 
                  className="w-12 h-12 rounded-2xl object-cover border-2 border-indigo-400 shadow-sm"
                />
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-950" />
              </div>
              <div className="flex flex-col flex-1 text-right truncate">
                <span className="font-bold text-sm text-white truncate">{language === "ar" ? emp.fullNameAr : emp.fullNameEn}</span>
                <span className="text-[11px] text-indigo-300 font-medium truncate">{emp.position}</span>
                <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1 mt-1">
                  <MapPin className="w-3 h-3 text-cyan-400" /> {emp.assignedWifiSsid || "HQ Tower 5G"}
                </span>
              </div>
              <div className="px-2 py-1 bg-indigo-950 text-indigo-300 font-mono text-[10px] rounded-xl font-bold border border-indigo-500/30">
                On Duty
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
