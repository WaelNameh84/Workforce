"use client";
import React, { useState } from "react";
import { 
  Sparkles, Cpu, ShieldAlert, CheckCircle2, TrendingUp, 
  MessageSquare, Send, Bot, User, Zap, Lock, ScanFace, Award 
} from "lucide-react";

interface AIProps {
  language: string;
  aiAnalytics: any[];
  employees: any[];
}

export default function AIEngineModule({ language = "ar", aiAnalytics = [], employees = [] }: AIProps) {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      text: language === "ar"
        ? "مرحباً بك! أنا «المستشار الذكي (Aura AI)» المسؤول عن التدقيق البيومتري وكشف التحايل وتحليل مسيرات الرواتب في الوقت الحقيقي. اسألني عن حالة الحضور اليوم أو المخاطر البيومترية!"
        : "Hello! I am Aura AI Assistant, your dedicated enterprise attendance predictive intelligence & fraud detection guardian. Ask me about attendance forecasts or payroll analyses!"
    }
  ]);
  const [input, setInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;
    const newMsg = { role: "user", text: input };
    setMessages(prev => [...prev, newMsg]);
    setInput("");
    setChatLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: newMsg.text }),
      });
      const data = await res.json();
      if (data.status === "success" && data.reply) {
        setMessages(prev => [...prev, { role: "assistant", text: data.reply }]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-purple-950 via-indigo-900 to-slate-900 p-6 rounded-3xl border border-purple-500/40 shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg text-white font-bold">
            <Cpu className="w-7 h-7 text-white animate-spin" style={{ animationDuration: "12s" }} />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <span>{language === "ar" ? "محرك الذكاء الاصطناعي والاستشراف التنبؤي" : "Artificial Intelligence Engine & Predictive Matrix"}</span>
              <span className="text-[10px] px-2.5 py-0.5 bg-cyan-500/20 text-cyan-300 font-mono rounded-full border border-cyan-400/30">
                GPT-4o + CLAUDE 3.5
              </span>
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-lg">
              {language === "ar"
                ? "نماذج تنبؤية فائقة لمراقبة الانضباط الوظيفي، كشف التلاعب بالبصمة وإصدار التقارير التلقائية بدون تدخل بشري."
                : "Neural network evaluating face depth maps, attendance accuracy, productivity forecasts & automatic HR diagnostics."}
            </p>
          </div>
        </div>
      </div>

      {/* 4 Core AI Metric Cards (No Tables!) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Attendance Prediction */}
        <div className="p-5 bg-gradient-to-b from-indigo-950/60 to-slate-900 rounded-3xl border border-indigo-500/40 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between text-indigo-300">
            <span className="font-bold text-xs">{language === "ar" ? "توقعات الحضور (Prediction)" : "Attendance Prediction"}</span>
            <TrendingUp className="w-5 h-5 text-indigo-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-mono font-black text-white my-2">98.5% <span className="text-xs text-emerald-400 font-sans">+0.4%</span></div>
          <div className="text-[10px] text-slate-300 font-mono">{language === "ar" ? "توقعات الانضباط لغداً في الوردية الصباحية" : "Forecasted punctuality for tomorrow"}</div>
        </div>

        {/* Card 2: Fraud Detection Guardian */}
        <div className="p-5 bg-gradient-to-b from-emerald-950/60 to-slate-900 rounded-3xl border border-emerald-500/40 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-300">
            <span className="font-bold text-xs">{language === "ar" ? "كشف الاحتيال (Fraud Risk)" : "Fraud Detection Guardian"}</span>
            <ShieldAlert className="w-5 h-5 text-emerald-400 animate-pulse" />
          </div>
          <div className="text-2xl sm:text-3xl font-mono font-black text-emerald-400 my-2">0.02% <span className="text-xs text-slate-400 font-sans font-normal">Safe</span></div>
          <div className="text-[10px] text-slate-300 font-mono">{language === "ar" ? "صفر حالات اختراق أو ثغرة بصمية" : "Zero biometric spoofing incidents"}</div>
        </div>

        {/* Card 3: Face Matching Confidence */}
        <div className="p-5 bg-gradient-to-b from-purple-950/60 to-slate-900 rounded-3xl border border-purple-500/40 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between text-purple-300">
            <span className="font-bold text-xs">{language === "ar" ? "دقة مطابقة الوجه (Face Matching)" : "Face Matching Confidence"}</span>
            <ScanFace className="w-5 h-5 text-purple-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-mono font-black text-cyan-300 my-2">99.9%</div>
          <div className="text-[10px] text-slate-300 font-mono">{language === "ar" ? "تحقق الأبعاد الثلاثية والتموضع الحراري" : "3D infrared spatial scan validation"}</div>
        </div>

        {/* Card 4: Productivity Analysis */}
        <div className="p-5 bg-gradient-to-b from-amber-950/60 to-slate-900 rounded-3xl border border-amber-500/40 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-300">
            <span className="font-bold text-xs">{language === "ar" ? "تحليل الإنتاجية (Productivity)" : "Productivity Analysis"}</span>
            <Award className="w-5 h-5 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-mono font-black text-amber-300 my-2">97.4%</div>
          <div className="text-[10px] text-slate-300 font-mono">{language === "ar" ? "كفاءة الفرق الفنية والهندسية" : "High aggregate task alignment"}</div>
        </div>
      </div>

      {/* Main Deck: AI Chatbot Assistant + Performance Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Aura AI Chatbot */}
        <div className="lg:col-span-2 bg-slate-900/90 backdrop-blur-2xl rounded-3xl border border-slate-800 shadow-2xl flex flex-col justify-between h-[520px] overflow-hidden">
          {/* Chat Header */}
          <div className="p-4 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-indigo-500 flex items-center justify-center text-white shadow-md">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-sm text-white flex items-center gap-2">
                  <span>{language === "ar" ? "المستشار الذكي (Aura AI)" : "Aura AI Smart Assistant"}</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                </div>
                <div className="text-[10px] font-mono text-slate-400">Connected to Live Drizzle Database & Biometric Stream</div>
              </div>
            </div>
            <span className="text-[10px] font-mono font-bold px-2.5 py-1 bg-purple-950/80 text-purple-300 rounded-xl border border-purple-500/30">
              Interactive Bot
            </span>
          </div>

          {/* Messages Window */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 no-scrollbar bg-slate-950/40">
            {messages.map((m, idx) => (
              <div key={idx} className={`flex items-start gap-3 ${m.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                <div className={`w-8 h-8 rounded-2xl flex items-center justify-center flex-shrink-0 ${m.role === "user" ? "bg-cyan-600 text-white" : "bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow"}`}>
                  {m.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className={`max-w-md p-4 rounded-3xl text-xs sm:text-sm font-bold leading-relaxed shadow-md ${
                  m.role === "user" ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-br-none" : "bg-slate-900 text-slate-100 rounded-bl-none border border-slate-800"
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {chatLoading && (
              <div className="flex items-center gap-2 text-xs text-slate-400 italic animate-pulse">
                <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" />
                <span>{language === "ar" ? "المستشار الذكي يقوم بالبحث في قواعد البيانات الحية..." : "Aura AI analyzing biometric & payroll tables..."}</span>
              </div>
            )}
          </div>

          {/* Quick suggestions & input */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 space-y-2">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 text-[11px]">
              {[
                { ar: "ما هي إحصائيات الدوام اليوم؟", en: "What is today's attendance rate?" },
                { ar: "هل توجد مخاطر احتيال بيومترية؟", en: "Check biometric fraud logs" },
                { ar: "ما إجمالي ملخص الرواتب لشهر مارس؟", en: "Show March payroll summary" },
              ].map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => { setInput(language === "ar" ? q.ar : q.en); }}
                  className="px-3 py-1 bg-slate-900 hover:bg-indigo-900/60 rounded-xl text-slate-300 font-bold whitespace-nowrap border border-slate-800 transition-colors"
                >
                  {language === "ar" ? q.ar : q.en}
                </button>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={language === "ar" ? "اكتب سؤالك للمستشار الذكي هنا..." : "Type your query for Aura AI..."}
                className="flex-1 px-4 py-3 bg-slate-900 rounded-2xl border border-slate-800 text-white font-bold text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="p-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 rounded-2xl text-white font-bold shadow-lg transition-transform active:scale-95"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>

        {/* Right 1 Col: Performance Insights & Recommendations Cards */}
        <div className="bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Award className="w-4 h-4 text-yellow-400" />
              <span>{language === "ar" ? "رؤى الأداء والتوصيات (Insights & Recommendations)" : "AI Smart Insights & Recommendations"}</span>
            </h3>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-[380px] no-scrollbar">
            {aiAnalytics.map((item, i) => {
              const emp = employees.find(e => e.id === item.employeeId);
              return (
                <div key={i} className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2 shadow-sm">
                  <div className="flex items-center justify-between font-bold text-xs text-cyan-300">
                    <span>{language === "ar" ? (emp?.fullNameAr || "موظف متميز") : (emp?.fullNameEn || "Staff")}</span>
                    <span className="text-[10px] font-mono bg-indigo-950 px-2 py-0.5 rounded text-indigo-300">Score: {item.productivityScore}%</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">{item.performanceSummary}</p>
                  <div className="p-2.5 bg-emerald-950/30 rounded-xl border border-emerald-500/30 text-[11px] text-emerald-300 font-bold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-300 flex-shrink-0" />
                    <span>{item.smartRecommendations}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <button 
            onClick={() => alert(language === "ar" ? "تم توليد التقرير التلقائي بالكامل من قبل الذكاء الاصطناعي بنجاح." : "Automated Executive Report compiled and added to Reports deck!")}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-2xl text-xs shadow-md flex items-center justify-center gap-2 transition-all"
          >
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>{language === "ar" ? "توليد تقرير استشرافي تلقائي (Automatic Reports)" : "Generate Automatic AI Summary"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
