"use client";
import React from "react";
import LiveClockWidget from "./LiveClockWidget";
import { Smartphone, Monitor, Globe, ShieldCheck, Sparkles, ScanFace } from "lucide-react";

interface NavbarProps {
  language: string;
  onLanguageChange: (lang: string) => void;
  isMobileMode: boolean;
  onToggleMobileMode: () => void;
  clockMode: string;
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export default function Navbar({
  language = "ar",
  onLanguageChange,
  isMobileMode,
  onToggleMobileMode,
  clockMode = "3d_cyber",
  activeTab,
  onSelectTab,
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-2xl border-b border-slate-800/80 shadow-2xl px-3 sm:px-6 py-3 transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Logo & Branding */}
        <div 
          onClick={() => onSelectTab("dashboard")}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/30 group-hover:scale-105 transition-transform text-white font-black text-lg">
            A
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-base sm:text-lg text-white tracking-wide">
                {language === "ar" ? "دوام الذكي Pro" : "Enterprise Punch AI"}
              </span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                MOBILE UI
              </span>
            </div>
            <span className="text-[10px] text-slate-400 block font-sans">
              {language === "ar" ? "بدون جداول روتينية • كروت ولمس تفاعلي" : "100% Touch Cards • Zero Boring Tables"}
            </span>
          </div>
        </div>

        {/* Center: Live Clock Widget */}
        <div className="hidden md:flex items-center">
          <LiveClockWidget mode={clockMode} language={language} showSeconds={true} showDate={true} />
        </div>

        {/* Right Tools: Language + Mobile Simulator Toggle */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => onLanguageChange(language === "ar" ? "en" : "ar")}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-2xl text-xs font-black text-slate-200 flex items-center gap-1.5 transition-all shadow-md active:scale-95"
          >
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>{language === "ar" ? "English" : "العربية"}</span>
          </button>

          <button
            onClick={onToggleMobileMode}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center gap-2 shadow-lg ${
              isMobileMode
                ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white border border-white/20 shadow-purple-500/30 animate-pulse"
                : "bg-slate-900 text-cyan-300 border border-cyan-500/50 hover:bg-slate-800"
            }`}
          >
            {isMobileMode ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4 text-cyan-400" />}
            <span className="hidden sm:inline">
              {isMobileMode 
                ? (language === "ar" ? "عرض شاشة الساحة المطلق" : "Expand Desktop Mode") 
                : (language === "ar" ? "وضع محاكي الهاتف الذكي" : "Mobile Phone UI Mode")}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
