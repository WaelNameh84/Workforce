"use client";
import React, { useState } from "react";
import { 
  Check, Clock, MapPin, Wifi, Smartphone, ScanFace, 
  Play, Square, Coffee, CheckCircle, RefreshCw, AlertCircle, 
  ShieldCheck, Radio, Sparkles, Navigation, Lock
} from "lucide-react";
import confetti from "canvas-confetti";

interface AttendanceProps {
  language: string;
  employees: any[];
  attendance: any[];
  onRefresh: () => void;
}

export default function AttendanceModule({ language = "ar", employees = [], attendance = [], onRefresh }: AttendanceProps) {
  const [selectedEmpId, setSelectedEmpId] = useState<number>(employees[0]?.id || 1);
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [autoAttendanceEnabled, setAutoAttendanceEnabled] = useState(true);

  const activeEmployee = employees.find(e => e.id === Number(selectedEmpId)) || employees[0];
  const todayStr = new Date().toISOString().split("T")[0];
  const todayRecord = attendance.find(a => a.employeeId === Number(selectedEmpId) && a.date === todayStr) || {
    checkInTime: "07:52:14 AM",
    checkOutTime: null,
    breakStartTime: null,
    breakEndTime: null,
    status: "On Time",
    verificationMethod: "Face ID & 5G GeoFence"
  };

  const handlePunchAction = async (actionType: string) => {
    setLoadingAction(actionType);
    try {
      const res = await fetch("/api/attendance/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          employeeId: selectedEmpId,
          actionType,
          method: "3D Face Recognition & 5G SSID",
          latitude: activeEmployee?.assignedLatitude || 24.7136,
          longitude: activeEmployee?.assignedLongitude || 46.6753,
          wifiSsid: activeEmployee?.assignedWifiSsid || "Corporate_HQ_5G"
        }),
      });
      const data = await res.json();
      if (data.status === "success") {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
        onRefresh();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAction(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Subject Selector Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white">
              {language === "ar" ? "محطة البصمة التفاعلية والتحقق المحمول" : "Interactive Touch Terminal & Biometric Sync"}
            </h2>
            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-mono text-[10px] rounded-full border border-emerald-500/30 font-bold">
              LIVE 5G GEOFENCE
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            {language === "ar" 
              ? "واجهة لمسية متطورة لتسجيل الحضور، الانصراف، والاستراحة مع التحقق من الموقع وشبكة WiFi وبصمة الجهاز العضوية."
              : "Tactile card terminal for Check In/Out & Breaks verified via GPS Coordinates, Router SSID and Hardware NFC token."}
          </p>
        </div>

        {/* Employee switch */}
        <div className="w-full sm:w-auto p-2 bg-slate-950 rounded-2xl border border-slate-800 flex items-center gap-3">
          <img src={activeEmployee?.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150"} alt="" className="w-11 h-11 rounded-xl object-cover border border-indigo-500/50" />
          <div className="flex flex-col text-right pr-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase">{language === "ar" ? "حدد الموظف للتجربة" : "Select Subject"}</span>
            <select
              value={selectedEmpId}
              onChange={(e) => setSelectedEmpId(Number(e.target.value))}
              className="bg-transparent font-black text-xs text-cyan-300 focus:outline-none cursor-pointer"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id} className="bg-slate-900 text-white">
                  {language === "ar" ? emp.fullNameAr : emp.fullNameEn}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 4 Massive Tactile Action Touch Buttons (No Boring Tables!) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Check In */}
        <button
          onClick={() => handlePunchAction("check_in")}
          disabled={loadingAction === "check_in"}
          className="group relative p-5 bg-gradient-to-b from-emerald-600/90 to-teal-800 hover:from-emerald-500 hover:to-teal-700 active:scale-95 transition-all duration-200 rounded-[28px] shadow-[0_10px_25px_rgba(16,185,129,0.3)] text-white text-right border border-emerald-400/30 flex flex-col justify-between h-36 overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-white/10 rounded-full blur-2xl pointer-events-none group-hover:bg-white/20 transition-all" />
          <div className="flex items-center justify-between z-10 w-full">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              {loadingAction === "check_in" ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5 fill-white" />}
            </div>
            <span className="px-2 py-0.5 bg-slate-950/40 text-emerald-200 font-mono text-[10px] rounded-lg">CHECK IN</span>
          </div>
          <div className="z-10 mt-2">
            <div className="text-lg sm:text-xl font-black tracking-wide">{language === "ar" ? "تسجيل الحضور" : "Check In"}</div>
            <div className="text-[11px] font-mono opacity-90">{todayRecord?.checkInTime ? `بصمة: ${todayRecord.checkInTime}` : "انقر لتفعيل البصمة الآن"}</div>
          </div>
        </button>

        {/* 2. Break Start */}
        <button
          onClick={() => handlePunchAction("break_start")}
          disabled={loadingAction === "break_start"}
          className="group relative p-5 bg-gradient-to-b from-amber-600/90 to-orange-800 hover:from-amber-500 hover:to-orange-700 active:scale-95 transition-all duration-200 rounded-[28px] shadow-[0_10px_25px_rgba(245,158,11,0.3)] text-white text-right border border-amber-400/30 flex flex-col justify-between h-36 overflow-hidden"
        >
          <div className="flex items-center justify-between z-10 w-full">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              {loadingAction === "break_start" ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Coffee className="w-5 h-5" />}
            </div>
            <span className="px-2 py-0.5 bg-slate-950/40 text-amber-200 font-mono text-[10px] rounded-lg">BREAK START</span>
          </div>
          <div className="z-10 mt-2">
            <div className="text-lg sm:text-xl font-black tracking-wide">{language === "ar" ? "بدء استراحة" : "Break Start"}</div>
            <div className="text-[11px] font-mono opacity-90">{todayRecord?.breakStartTime ? `استراحة: ${todayRecord.breakStartTime}` : "تفعيل مؤقت الغداء/القهوة"}</div>
          </div>
        </button>

        {/* 3. Break End */}
        <button
          onClick={() => handlePunchAction("break_end")}
          disabled={loadingAction === "break_end"}
          className="group relative p-5 bg-gradient-to-b from-blue-600/90 to-indigo-800 hover:from-blue-500 hover:to-indigo-700 active:scale-95 transition-all duration-200 rounded-[28px] shadow-[0_10px_25px_rgba(59,130,246,0.3)] text-white text-right border border-blue-400/30 flex flex-col justify-between h-36 overflow-hidden"
        >
          <div className="flex items-center justify-between z-10 w-full">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              {loadingAction === "break_end" ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5 text-cyan-300 fill-cyan-300" />}
            </div>
            <span className="px-2 py-0.5 bg-slate-950/40 text-cyan-200 font-mono text-[10px] rounded-lg">BREAK END</span>
          </div>
          <div className="z-10 mt-2">
            <div className="text-lg sm:text-xl font-black tracking-wide">{language === "ar" ? "إنهاء الاستراحة" : "Break End"}</div>
            <div className="text-[11px] font-mono opacity-90">{todayRecord?.breakEndTime ? `عودة: ${todayRecord.breakEndTime}` : "العودة للعمل المحسوب"}</div>
          </div>
        </button>

        {/* 4. Check Out */}
        <button
          onClick={() => handlePunchAction("check_out")}
          disabled={loadingAction === "check_out"}
          className="group relative p-5 bg-gradient-to-b from-rose-600/90 to-purple-900 hover:from-rose-500 hover:to-purple-800 active:scale-95 transition-all duration-200 rounded-[28px] shadow-[0_10px_25px_rgba(244,63,94,0.3)] text-white text-right border border-rose-400/30 flex flex-col justify-between h-36 overflow-hidden"
        >
          <div className="flex items-center justify-between z-10 w-full">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              {loadingAction === "check_out" ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Square className="w-5 h-5 fill-white" />}
            </div>
            <span className="px-2 py-0.5 bg-slate-950/40 text-rose-200 font-mono text-[10px] rounded-lg">CHECK OUT</span>
          </div>
          <div className="z-10 mt-2">
            <div className="text-lg sm:text-xl font-black tracking-wide">{language === "ar" ? "تسجيل الانصراف" : "Check Out"}</div>
            <div className="text-[11px] font-mono opacity-90">{todayRecord?.checkOutTime ? `انصراف: ${todayRecord.checkOutTime}` : "إنهاء الوردية واحتساب الساعات"}</div>
          </div>
        </button>
      </div>

      {/* 6 Biometric & Geotechnical Verification Cards Deck */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Card 1: GPS Verification */}
        <div className="p-5 bg-slate-900/90 rounded-3xl border border-slate-800 shadow-lg flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-rose-500/20 text-rose-400 rounded-2xl">
              <MapPin className="w-5 h-5 animate-bounce" />
            </div>
            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold text-[10px] rounded-lg border border-emerald-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> GPS VERIFIED
            </span>
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">{language === "ar" ? "التحقق الجغرافي (GPS Geofence)" : "GPS Coordinates & Geofencing"}</h4>
            <p className="text-xs text-slate-300 font-mono mt-1">
              24.7136° N, 46.6753° E (Riyadh Innovation HQ Tower)
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{language === "ar" ? "دقة التموضع:" : "Accuracy Range:"} 2.1m (Within Bounds)</span>
            <span className="text-cyan-400 font-bold cursor-pointer hover:underline" onClick={() => window.open(`https://www.google.com/maps?q=${activeEmployee?.assignedLatitude || 24.7136},${activeEmployee?.assignedLongitude || 46.6753}`, "_blank")}>
              {language === "ar" ? "الخريطة الحية ↗" : "Live Map ↗"}
            </span>
          </div>
        </div>

        {/* Card 2: WiFi Verification */}
        <div className="p-5 bg-slate-900/90 rounded-3xl border border-slate-800 shadow-lg flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-cyan-500/20 text-cyan-400 rounded-2xl">
              <Wifi className="w-5 h-5 animate-pulse" />
            </div>
            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold text-[10px] rounded-lg border border-emerald-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> SSID MATCHED
            </span>
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">{language === "ar" ? "التحقق عبر نطاق واي-فاي (WiFi SSID)" : "WiFi SSID Router Verification"}</h4>
            <p className="text-xs text-cyan-300 font-mono font-bold mt-1">
              {activeEmployee?.assignedWifiSsid || "Corporate_HQ_5G_VIP"}
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{language === "ar" ? "حالة الإشارة:" : "Signal Strength:"} 5 GHz / Excellent (-45 dBm)</span>
            <span className="text-emerald-400 font-mono font-bold">Encrypted WPA3</span>
          </div>
        </div>

        {/* Card 3: Face Recognition Status */}
        <div className="p-5 bg-slate-900/90 rounded-3xl border border-slate-800 shadow-lg flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-purple-500/20 text-purple-400 rounded-2xl">
              <ScanFace className="w-5 h-5" />
            </div>
            <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 font-bold text-[10px] rounded-lg border border-purple-500/30">
              99.8% CONFIDENCE
            </span>
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">{language === "ar" ? "بصمة التعرف على الوجه 3D" : "Face Recognition 3D Biometric"}</h4>
            <p className="text-xs text-slate-300 mt-1">
              {language === "ar" ? "تطابق حي للنموذج العصبي بدون ثغرات صور أو التلاعب بالشاشات." : "Neural deep infrared depth coordinates validated against face models."}
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{language === "ar" ? "التصنيف التنبؤي:" : "Security Level:"} High Assurance</span>
            <span className="text-cyan-400 font-bold">Live Infrared</span>
          </div>
        </div>

        {/* Card 4: Device Verification */}
        <div className="p-5 bg-slate-900/90 rounded-3xl border border-slate-800 shadow-lg flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-indigo-500/20 text-indigo-400 rounded-2xl">
              <Smartphone className="w-5 h-5" />
            </div>
            <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold text-[10px] rounded-lg border border-indigo-500/30">
              TRUSTED TERMINAL
            </span>
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">{language === "ar" ? "التحقق من الجهاز الموثوق" : "Device Hardware Verification"}</h4>
            <p className="text-xs text-slate-300 font-mono mt-1">
              iPhone 15 Pro Max (Secure Apple Enclave / UDID Bound)
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{language === "ar" ? "ربط الشابكة:" : "Hardware Bound:"} Corporate NFC Tag</span>
            <Lock className="w-3.5 h-3.5 text-indigo-400" />
          </div>
        </div>

        {/* Card 5: Shift Validation */}
        <div className="p-5 bg-slate-900/90 rounded-3xl border border-slate-800 shadow-lg flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-2xl">
              <Clock className="w-5 h-5" />
            </div>
            <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 font-bold text-[10px] rounded-lg border border-amber-500/30">
              SHIFT MATCHED
            </span>
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">{language === "ar" ? "التحقق من الوردية والجدول" : "Shift Validation & Schedule Match"}</h4>
            <p className="text-xs text-slate-300 mt-1">
              {language === "ar" ? "مطابق للوردية الصباحية المباشرة (Morning Shift 08:00 - 16:00) بفترة سماح 15 دقيقة." : "Aligned with active Morning Shift schedule (08:00 - 16:00) with 15m grace."}
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{language === "ar" ? "حالة الانضباط:" : "Status today:"} <strong className="text-emerald-400">On Time (في الوقت)</strong></span>
            <span className="font-mono font-bold text-xs text-amber-300">0h Overtime</span>
          </div>
        </div>

        {/* Card 6: Automatic Attendance Toggle */}
        <div className="p-5 bg-gradient-to-br from-indigo-900/50 via-purple-950/50 to-slate-900 rounded-3xl border border-purple-500/40 shadow-lg flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-gradient-to-br from-cyan-400 to-purple-500 text-white rounded-2xl shadow-md">
              <Sparkles className="w-5 h-5 animate-spin" style={{ animationDuration: "10s" }} />
            </div>
            {/* Custom Switch Toggle */}
            <button
              onClick={() => setAutoAttendanceEnabled(!autoAttendanceEnabled)}
              className={`w-12 h-7 rounded-full transition-colors flex items-center p-1 ${autoAttendanceEnabled ? "bg-emerald-500" : "bg-slate-700"}`}
            >
              <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${autoAttendanceEnabled ? "translate-x-5" : "translate-x-0"}`} />
            </button>
          </div>
          <div>
            <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
              <span>{language === "ar" ? "التسجيل التلقائي الذكي (Auto-Punch)" : "Automatic Geofenced Attendance"}</span>
            </h4>
            <p className="text-xs text-slate-300 mt-1">
              {language === "ar" 
                ? "عند التفعيل، يقوم التطبيق بتوثيق الدخول والانصراف تلقائياً عند عبور الهاتف لنطاق إحداثيات الشركة والاتصال بـ WiFi."
                : "Automatically registers check-in/out the second the employee mobile terminal enters WiFi/5G Geofenced perimeter."}
            </p>
          </div>
          <div className="pt-2 border-t border-purple-500/30 text-[11px] text-purple-300 flex items-center justify-between font-bold">
            <span>{language === "ar" ? "الحالة حالياً:" : "Current status:"} {autoAttendanceEnabled ? "مفعّل وآلي 100%" : "متوقف يدوي"}</span>
            <span className="text-xs">🤖 AI Synced</span>
          </div>
        </div>
      </div>
    </div>
  );
}
