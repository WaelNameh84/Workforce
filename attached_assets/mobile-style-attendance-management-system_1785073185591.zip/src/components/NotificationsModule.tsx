"use client";
import React, { useState } from "react";
import { 
  Bell, Mail, MessageSquare, Smartphone, Send, CheckCircle2, 
  Sparkles, Globe, ShieldCheck, Clock, Check, Volume2 
} from "lucide-react";
import confetti from "canvas-confetti";

interface NotificationsProps {
  language: string;
  notifications: any[];
  employees: any[];
  onRefresh: () => void;
}

export default function NotificationsModule({ language = "ar", notifications = [], employees = [], onRefresh }: NotificationsProps) {
  const [activeChannel, setActiveChannel] = useState<string>("all");
  const [broadcastTitle, setBroadcastTitle] = useState("");
  const [broadcastMsg, setBroadcastMsg] = useState("");

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMsg) return;
    confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
    alert(language === "ar" ? `تم إرسال إشعار البث المباشر "${broadcastTitle}" عبر جميع القنوات (WhatsApp & Push & SMS) بنجاح إلى جميع الموظفين!` : "Broadcast Alert transmitted across all enterprise communication networks!");
    setBroadcastTitle("");
    setBroadcastMsg("");
  };

  const filteredNotifs = activeChannel === "all" ? notifications : notifications.filter(n => n.channel.toLowerCase().includes(activeChannel));

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-slate-900/80 backdrop-blur-2xl p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Bell className="w-6 h-6 text-amber-400 animate-bounce" />
            <span>{language === "ar" ? "مركز الإشعارات، الرسائل وقنوات التواصل المتعددة" : "Enterprise Communications & Notifications Feed"}</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            {language === "ar"
              ? "تتبع مباشر لإشعارات البريد الإلكتروني، رسائل SMS، تنبيهات التطبيق Push، وبث رسائل WhatsApp Business الموثقة."
              : "Monitor verified deliveries across Email, SMS, Push, WhatsApp & In-App notification routers."}
          </p>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            { id: "all", label: "All Channels" },
            { id: "whatsapp", label: "WhatsApp" },
            { id: "push", label: "Push Alerts" },
            { id: "email", label: "Email" },
            { id: "sms", label: "SMS" },
          ].map((ch) => (
            <button
              key={ch.id}
              onClick={() => setActiveChannel(ch.id)}
              className={`px-3.5 py-1.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
                activeChannel === ch.id ? "bg-indigo-600 text-white shadow-md" : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-white"
              }`}
            >
              {ch.label}
            </button>
          ))}
        </div>
      </div>

      {/* Broadcast Simulator Studio Card */}
      <div className="p-6 bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 rounded-3xl border border-indigo-500/40 shadow-xl space-y-4">
        <h3 className="font-bold text-white text-base flex items-center gap-2">
          <Send className="w-5 h-5 text-cyan-400" />
          <span>{language === "ar" ? "إرسال إشعار تنبيهي جماعي (Broadcast Simulator)" : "Transmit Corporate Broadcast Message"}</span>
        </h3>
        <form onSubmit={handleSendBroadcast} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input
            type="text"
            required
            value={broadcastTitle}
            onChange={(e) => setBroadcastTitle(e.target.value)}
            placeholder={language === "ar" ? "عنوان التنبيه: مثال: تذكير بموعد الاجتماع الصباحي" : "Broadcast Title..."}
            className="px-4 py-3 bg-slate-950 rounded-2xl border border-slate-700 text-white text-xs font-bold"
          />
          <input
            type="text"
            required
            value={broadcastMsg}
            onChange={(e) => setBroadcastMsg(e.target.value)}
            placeholder={language === "ar" ? "نص الرسالة: يرجى التوجه لمبنى الابتكار لتأكيد الحضور..." : "Message content to send via WhatsApp/SMS..."}
            className="px-4 py-3 bg-slate-950 rounded-2xl border border-slate-700 text-white text-xs font-bold"
          />
          <button
            type="submit"
            className="py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-white font-bold rounded-2xl text-xs shadow-lg flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span>{language === "ar" ? "بث فوري عبر جميع القنوات" : "Transmit Broadcast Now"}</span>
          </button>
        </form>
      </div>

      {/* 5 Communication Channels Cards Deck */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNotifs.map((notif: any, idx: number) => {
          const isWhatsApp = notif.channel === "WhatsApp";
          return (
            <div
              key={notif.id || idx}
              className={`p-5 rounded-3xl border flex flex-col justify-between space-y-3 shadow-md ${
                isWhatsApp
                  ? "bg-gradient-to-r from-slate-950 via-emerald-950/40 to-slate-950 border-emerald-500/40"
                  : "bg-slate-900/90 border-slate-800"
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 ${
                    isWhatsApp ? "bg-emerald-500 text-slate-950 font-black" : "bg-indigo-950 text-indigo-300 border border-indigo-500/30"
                  }`}>
                    {isWhatsApp ? <MessageSquare className="w-3.5 h-3.5 fill-current" /> : <Bell className="w-3.5 h-3.5" />}
                    {notif.channel}
                  </span>
                  {isWhatsApp && <span className="text-[10px] bg-emerald-950 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Verified Business</span>}
                </div>
                <span className="text-[11px] font-mono text-slate-400">Delivered • Just now</span>
              </div>

              <div className="text-right">
                <div className="font-bold text-base text-white">{notif.title}</div>
                <div className="text-xs text-slate-300 mt-1 leading-relaxed bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 font-normal">
                  {notif.message}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-bold">
                <span>{language === "ar" ? "المستلم:" : "Recipient:"} <strong className="text-cyan-300 font-normal">{notif.recipientName} ({notif.recipientPhoneOrEmail})</strong></span>
                <span className="flex items-center gap-1 text-emerald-400 font-mono text-xs"><CheckCircle2 className="w-4 h-4" /> Sent</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
