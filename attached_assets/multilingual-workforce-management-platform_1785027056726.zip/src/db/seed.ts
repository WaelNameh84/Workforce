import 'dotenv/config';
import { db } from './index';
import { users, companies, departments, employees, attendance, leaves, schedules, payroll, requests, assets } from './schema';
import bcrypt from 'bcryptjs';

export async function seedDatabase() {
  console.log('🌱 Seeding database...');

  // Create company
  const [company] = await db.insert(companies).values({
    name: 'Global Tech Solutions',
    industry: 'Technology',
    country: 'Sweden',
    currency: 'SEK',
    timezone: 'Europe/Stockholm',
    language: 'sv',
    workStartHour: '09:00',
    workEndHour: '17:00',
  }).returning();

  // Create departments
  const departmentsData = await db.insert(departments).values([
    { name: 'Engineering', companyId: company.id, description: 'Software Development' },
    { name: 'Human Resources', companyId: company.id, description: 'HR Department' },
    { name: 'Finance', companyId: company.id, description: 'Finance & Accounting' },
    { name: 'Marketing', companyId: company.id, description: 'Marketing & Sales' },
  ]).returning();

  // Create admin user
  const hashedPassword = await bcrypt.hash('admin123', 10);
  const [adminUser] = await db.insert(users).values({
    email: 'admin@company.com',
    password: hashedPassword,
    fullName: 'Admin User',
    role: 'admin',
    companyId: company.id,
    isActive: true,
  }).returning();

  // Create employees
  const employeesData = [
    { employeeCode: 'EMP001', fullName: 'John Smith', email: 'john@company.com', phone: '+1234567890', position: 'Senior Developer', salary: '5000', departmentId: departmentsData[0].id },
    { employeeCode: 'EMP002', fullName: 'Sarah Johnson', email: 'sarah@company.com', phone: '+1234567891', position: 'HR Manager', salary: '4500', departmentId: departmentsData[1].id },
    { employeeCode: 'EMP003', fullName: 'Mohammed Ali', email: 'mohammed@company.com', phone: '+1234567892', position: 'Frontend Developer', salary: '4000', departmentId: departmentsData[0].id },
    { employeeCode: 'EMP004', fullName: 'Emma Wilson', email: 'emma@company.com', phone: '+1234567893', position: 'Accountant', salary: '3800', departmentId: departmentsData[2].id },
    { employeeCode: 'EMP005', fullName: 'Lars Svensson', email: 'lars@company.com', phone: '+1234567894', position: 'Marketing Specialist', salary: '3500', departmentId: departmentsData[3].id },
    { employeeCode: 'EMP006', fullName: 'Fatima Hassan', email: 'fatima@company.com', phone: '+1234567895', position: 'Backend Developer', salary: '4200', departmentId: departmentsData[0].id },
  ];

  const createdEmployees = await db.insert(employees).values(
    employeesData.map(emp => ({
      ...emp,
      companyId: company.id,
      status: 'active',
      joinDate: '2024-01-15',
    }))
  ).returning();

  // Create user accounts for employees
  await db.insert(users).values(
    createdEmployees.map(emp => ({
      email: emp.email,
      password: hashedPassword,
      fullName: emp.fullName,
      role: 'employee',
      companyId: company.id,
      employeeId: emp.id,
      isActive: true,
    }))
  );

  // Create attendance records for today
  const today = new Date().toISOString().split('T')[0];
  await db.insert(attendance).values(
    createdEmployees.slice(0, 4).map(emp => ({
      employeeId: emp.id,
      date: today,
      clockIn: new Date(`${today}T09:00:00`),
      clockOut: new Date(`${today}T17:00:00`),
      totalHours: '8.00',
      location: 'Office',
      method: 'Manual',
      status: 'present',
      isLate: false,
    }))
  );

  // Create leave requests
  await db.insert(leaves).values([
    { employeeId: createdEmployees[0].id, type: 'annual', startDate: '2026-02-01', endDate: '2026-02-05', daysCount: 5, reason: 'Family vacation', status: 'approved' },
    { employeeId: createdEmployees[1].id, type: 'sick', startDate: '2026-01-20', endDate: '2026-01-21', daysCount: 2, reason: 'Flu', status: 'approved' },
    { employeeId: createdEmployees[2].id, type: 'emergency', startDate: '2026-01-25', endDate: '2026-01-25', daysCount: 1, reason: 'Personal emergency', status: 'pending' },
  ]);

  // Create schedules for next week
  const nextWeek = new Date();
  nextWeek.setDate(nextWeek.getDate() + 7);
  for (let i = 0; i < 5; i++) {
    const date = new Date(nextWeek);
    date.setDate(date.getDate() + i);
    const dateStr = date.toISOString().split('T')[0];
    
    await db.insert(schedules).values(
      createdEmployees.map(emp => ({
        employeeId: emp.id,
        date: dateStr,
        shiftType: 'morning',
        startTime: '09:00',
        endTime: '17:00',
        isRemote: i % 2 === 0,
      }))
    );
  }

  // Create payroll records
  await db.insert(payroll).values(
    createdEmployees.map(emp => ({
      employeeId: emp.id,
      period: '2026-01',
      basicSalary: emp.salary || '0',
      overtime: '200',
      bonus: '100',
      deductions: '50',
      tax: '500',
      netSalary: (parseFloat(emp.salary || '0') + 200 + 100 - 50 - 500).toString(),
      status: 'paid',
      paidAt: new Date(),
    }))
  );

  // Create requests
  await db.insert(requests).values([
    { employeeId: createdEmployees[0].id, type: 'overtime', title: 'Weekend Work', description: 'Requesting overtime for weekend project', status: 'pending' },
    { employeeId: createdEmployees[1].id, type: 'shift_change', title: 'Shift Change Request', description: 'Need to change from morning to evening shift', status: 'pending' },
    { employeeId: createdEmployees[2].id, type: 'expense', title: 'Travel Expense', description: 'Business trip expenses', status: 'approved', approvedBy: adminUser.id, approvedAt: new Date() },
  ]);

  // Create assets
  await db.insert(assets).values([
    { companyId: company.id, name: 'MacBook Pro 16"', type: 'laptop', serialNumber: 'SN001', assignedTo: createdEmployees[0].id, status: 'assigned' },
    { companyId: company.id, name: 'iPhone 15 Pro', type: 'phone', serialNumber: 'SN002', assignedTo: createdEmployees[1].id, status: 'assigned' },
    { companyId: company.id, name: 'Dell Monitor 27"', type: 'monitor', serialNumber: 'SN003', status: 'available' },
    { companyId: company.id, name: 'Office Key Card', type: 'card', serialNumber: 'SN004', assignedTo: createdEmployees[2].id, status: 'assigned' },
  ]);

  console.log('✅ Database seeded successfully!');
  console.log('📧 Admin login: admin@company.com / admin123');
}

// Run seed if called directly
if (require.main === module) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error('Seed failed:', err);
      process.exit(1);
    });
}
