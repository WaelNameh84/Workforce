import { NextResponse } from 'next/server';
import { db } from '@/db';
import { employees, attendance, leaves, requests, payroll } from '@/db/schema';
import { eq, and, gte, lte, sql } from 'drizzle-orm';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get('companyId');

    if (!companyId) {
      return NextResponse.json({ error: 'Company ID required' }, { status: 400 });
    }

    const companyIdNum = parseInt(companyId);

    // Total employees
    const [totalEmployees] = await db.select({ count: sql<number>`count(*)` })
      .from(employees)
      .where(eq(employees.companyId, companyIdNum));

    // Today's attendance
    const today = new Date().toISOString().split('T')[0];
    const [presentToday] = await db.select({ count: sql<number>`count(*)` })
      .from(attendance)
      .where(and(eq(attendance.date, today), eq(attendance.status, 'present')));

    // On leave today
    const [onLeave] = await db.select({ count: sql<number>`count(*)` })
      .from(leaves)
      .where(and(
        lte(leaves.startDate, today),
        gte(leaves.endDate, today),
        eq(leaves.status, 'approved')
      ));

    // Pending requests
    const [pendingRequests] = await db.select({ count: sql<number>`count(*)` })
      .from(requests)
      .where(eq(requests.status, 'pending'));

    // Monthly payroll total
    const currentMonth = new Date().toISOString().slice(0, 7);
    const [monthlyPayroll] = await db.select({ total: sql<number>`sum(net_salary)` })
      .from(payroll)
      .where(eq(payroll.period, currentMonth));

    // Recent attendance (last 7 days)
    const recentAttendance = await db.select({
      date: attendance.date,
      present: sql<number>`count(*) filter (where ${attendance.status} = 'present')`,
      absent: sql<number>`count(*) filter (where ${attendance.status} = 'absent')`,
    })
      .from(attendance)
      .where(gte(attendance.date, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]))
      .groupBy(attendance.date)
      .orderBy(attendance.date);

    // Department distribution
    const departmentStats = await db.select({
      department: employees.departmentId,
      count: sql<number>`count(*)`,
    })
      .from(employees)
      .where(eq(employees.companyId, companyIdNum))
      .groupBy(employees.departmentId);

    return NextResponse.json({
      totalEmployees: totalEmployees?.count || 0,
      presentToday: presentToday?.count || 0,
      onLeave: onLeave?.count || 0,
      pendingRequests: pendingRequests?.count || 0,
      monthlyPayroll: monthlyPayroll?.total || 0,
      recentAttendance,
      departmentStats,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
