'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useTheme } from '@/app/providers';
import { Globe, Mail, Lock, User, Building2, ArrowRight, Moon, Sun } from 'lucide-react';

export default function RegisterPage() {
  const { t, locale, setLocale } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const router = useRouter();
  const [form, setForm] = useState({ fullName: '', email: '', password: '', company: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Registration failed');
        setLoading(false);
        return;
      }

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      router.push('/dashboard');
    } catch (err) {
      setError('Network error');
      setLoading(false);
    }
  };

  const languages = [
    { code: 'en', flag: '🇺🇸' },
    { code: 'ar', flag: '🇸🇦' },
    { code: 'sv', flag: '🇸🇪' },
  ];

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--background)', color: 'var(--foreground)' }}>
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-purple-600 via-pink-600 to-rose-600">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        </div>
        <div className="relative z-10 p-12 flex flex-col justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Globe className="w-7 h-7" />
            </div>
            <span className="text-2xl font-bold">{t('appName')}</span>
          </div>
          <div>
            <h1 className="text-4xl font-bold mb-4 leading-tight">
              Start Managing Your Workforce Today
            </h1>
            <p className="text-lg opacity-90 mb-8">
              Join 10,000+ companies already using {t('appName')} to transform their HR operations.
            </p>
            <div className="space-y-3">
              {[
                '✓ 14-day free trial',
                '✓ No credit card required',
                '✓ Full access to all features',
                '✓ 24/7 customer support',
              ].map((item, i) => (
                <div key={i} className="text-lg font-medium">{item}</div>
              ))}
            </div>
          </div>
          <div className="text-sm opacity-80">
            © 2026 {t('appName')}
          </div>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="flex justify-between items-center mb-8">
            <Link href="/" className="flex items-center gap-2 lg:hidden">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">{t('appName')}</span>
            </Link>
            <div className="flex items-center gap-2 ms-auto">
              <div className="flex items-center gap-1 p-1 rounded-lg" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setLocale(lang.code as any)}
                    className={`px-2 py-1 rounded text-xs font-medium ${locale === lang.code ? 'bg-indigo-500 text-white' : ''}`}
                  >
                    {lang.flag}
                  </button>
                ))}
              </div>
              <button onClick={toggleTheme} className="p-2 rounded-lg" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('registerTitle')}</h2>
            <p style={{ color: 'var(--muted)' }}>{t('registerSubtitle')}</p>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">{t('fullName')}</label>
              <div className="relative">
                <User className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
                <input
                  type="text"
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  className={`w-full rounded-lg px-10 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">{t('email')}</label>
              <div className="relative">
                <Mail className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className={`w-full rounded-lg px-10 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">{t('company')}</label>
              <div className="relative">
                <Building2 className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
                <input
                  type="text"
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                  className={`w-full rounded-lg px-10 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">{t('password')}</label>
              <div className="relative">
                <Lock className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
                <input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className={`w-full rounded-lg px-10 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  required
                />
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 text-red-500 text-sm">{error}</div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  {t('register')}
                  <ArrowRight className={`w-4 h-4 ${locale === 'ar' ? 'rotate-180' : ''}`} />
                </>
              )}
            </button>
          </form>

          <p className="text-center mt-6 text-sm" style={{ color: 'var(--muted)' }}>
            {t('hasAccount')}{' '}
            <Link href="/login" className="text-indigo-500 hover:underline font-medium">
              {t('login')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
