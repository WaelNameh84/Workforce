'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Shield, Lock, Key, Eye, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function SecurityPage() {
  const { t } = useLanguage();

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('security')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Enterprise-grade security and compliance</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'AES-256', desc: 'Encryption', icon: Lock },
          { label: 'JWT', desc: 'Authentication', icon: Key },
          { label: 'MFA', desc: 'Multi-factor', icon: Shield },
          { label: 'GDPR', desc: 'Compliance', icon: CheckCircle2 },
        ].map((item, i) => (
          <div key={i} className="p-5 rounded-2xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-rose-500 flex items-center justify-center mx-auto mb-3">
              <item.icon className="w-6 h-6 text-white" />
            </div>
            <div className="font-bold">{item.label}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>{item.desc}</div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">Security Features</h3>
        <div className="space-y-3">
          {[
            { feature: 'AES-256 Data Encryption', status: 'Active', icon: Lock },
            { feature: 'JWT Token Authentication', status: 'Active', icon: Key },
            { feature: 'Multi-Factor Authentication', status: 'Active', icon: Shield },
            { feature: 'Session Management', status: 'Active', icon: Eye },
            { feature: 'Audit Logging', status: 'Active', icon: AlertCircle },
            { feature: 'GDPR Compliance', status: 'Compliant', icon: CheckCircle2 },
            { feature: 'ISO 27001 Certification', status: 'Certified', icon: CheckCircle2 },
            { feature: 'SOC 2 Type II', status: 'Certified', icon: CheckCircle2 },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between p-4 rounded-xl" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center text-red-500">
                  <item.icon className="w-5 h-5" />
                </div>
                <span className="font-medium">{item.feature}</span>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-500/10 text-green-500">
                {item.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
