'use client';

import { useState } from 'react';
import { useLanguage } from '@/i18n/LanguageProvider';
import { Search, Plus, Filter, Mail, Phone, MoreVertical, Download, Upload, UserPlus } from 'lucide-react';

const demoEmployees = [
  { id: 1, name: 'John Smith', email: 'john@company.com', phone: '+1234567890', department: 'Engineering', position: 'Senior Developer', salary: '$5,000', status: 'active', joinDate: '2024-01-15', avatar: 'JS' },
  { id: 2, name: 'Sarah Johnson', email: 'sarah@company.com', phone: '+1234567891', department: 'Human Resources', position: 'HR Manager', salary: '$4,500', status: 'active', joinDate: '2023-11-20', avatar: 'SJ' },
  { id: 3, name: 'Mohammed Ali', email: 'mohammed@company.com', phone: '+1234567892', department: 'Engineering', position: 'Frontend Developer', salary: '$4,000', status: 'active', joinDate: '2024-03-10', avatar: 'MA' },
  { id: 4, name: 'Emma Wilson', email: 'emma@company.com', phone: '+1234567893', department: 'Finance', position: 'Accountant', salary: '$3,800', status: 'active', joinDate: '2024-02-05', avatar: 'EW' },
  { id: 5, name: 'Lars Svensson', email: 'lars@company.com', phone: '+1234567894', department: 'Marketing', position: 'Marketing Specialist', salary: '$3,500', status: 'on-leave', joinDate: '2023-08-12', avatar: 'LS' },
  { id: 6, name: 'Fatima Hassan', email: 'fatima@company.com', phone: '+1234567895', department: 'Engineering', position: 'Backend Developer', salary: '$4,200', status: 'active', joinDate: '2024-04-01', avatar: 'FH' },
  { id: 7, name: 'Ahmed Khalid', email: 'ahmed@company.com', phone: '+1234567896', department: 'Sales', position: 'Sales Manager', salary: '$4,800', status: 'active', joinDate: '2023-06-15', avatar: 'AK' },
  { id: 8, name: 'Anna Lindqvist', email: 'anna@company.com', phone: '+1234567897', department: 'HR', position: 'Recruiter', salary: '$3,200', status: 'inactive', joinDate: '2024-05-20', avatar: 'AL' },
];

export default function EmployeesPage() {
  const { t, locale } = useLanguage();
  const [search, setSearch] = useState('');
  const [filterDept, setFilterDept] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredEmployees = demoEmployees.filter(emp => {
    const matchesSearch = emp.name.toLowerCase().includes(search.toLowerCase()) ||
      emp.email.toLowerCase().includes(search.toLowerCase());
    const matchesDept = filterDept === 'all' || emp.department === filterDept;
    return matchesSearch && matchesDept;
  });

  const departments = ['all', ...Array.from(new Set(demoEmployees.map(e => e.department)))];

  const getStatusColor = (status: string) => {
    if (status === 'active') return 'bg-green-500/10 text-green-500';
    if (status === 'on-leave') return 'bg-amber-500/10 text-amber-500';
    return 'bg-gray-500/10 text-gray-500';
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">{t('employees')}</h1>
          <p className="text-sm" style={{ color: 'var(--muted)' }}>{t('employeeList')} - {demoEmployees.length} employees</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <Upload className="w-4 h-4" />
            Import
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-medium text-sm"
          >
            <UserPlus className="w-4 h-4" />
            {t('addEmployee')}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
          <input
            type="text"
            placeholder={t('search') + '...'}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full rounded-lg px-10 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${locale === 'ar' ? 'pe-10 ps-4' : ''}`}
            style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
          />
        </div>
        <select
          value={filterDept}
          onChange={(e) => setFilterDept(e.target.value)}
          className="px-4 py-2.5 rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
          style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
        >
          {departments.map(dept => (
            <option key={dept} value={dept}>{dept === 'all' ? 'All Departments' : dept}</option>
          ))}
        </select>
      </div>

      {/* Employees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEmployees.map((emp) => (
          <div
            key={emp.id}
            className="p-6 rounded-2xl transition hover:shadow-lg cursor-pointer"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
                  {emp.avatar}
                </div>
                <div>
                  <div className="font-bold">{emp.name}</div>
                  <div className="text-xs" style={{ color: 'var(--muted)' }}>{emp.position}</div>
                </div>
              </div>
              <button className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--muted)' }}>
                <Mail className="w-3 h-3" />
                <span className="truncate">{emp.email}</span>
              </div>
              <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--muted)' }}>
                <Phone className="w-3 h-3" />
                <span>{emp.phone}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: 'var(--border)' }}>
              <div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{t('department')}</div>
                <div className="text-sm font-medium">{emp.department}</div>
              </div>
              <div className="text-right">
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{t('salary')}</div>
                <div className="text-sm font-medium">{emp.salary}</div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(emp.status)}`}>
                {t(emp.status as any) || emp.status}
              </span>
              <div className="text-xs" style={{ color: 'var(--muted)' }}>
                {t('joinDate')}: {emp.joinDate}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAddModal(false)}>
          <div className="rounded-2xl p-6 w-full max-w-lg" style={{ background: 'var(--card)' }} onClick={(e) => e.stopPropagation()}>
            <h2 className="text-xl font-bold mb-6">{t('addEmployee')}</h2>
            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">{t('fullName')}</label>
                  <input type="text" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">{t('email')}</label>
                  <input type="email" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">{t('department')}</label>
                  <select className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }}>
                    <option>Engineering</option>
                    <option>HR</option>
                    <option>Finance</option>
                    <option>Marketing</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">{t('position')}</label>
                  <input type="text" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">{t('salary')}</label>
                  <input type="number" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">{t('joinDate')}</label>
                  <input type="date" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setShowAddModal(false)} className="flex-1 px-4 py-2.5 rounded-lg font-medium" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
                  {t('cancel')}
                </button>
                <button type="submit" className="flex-1 px-4 py-2.5 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-medium">
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
