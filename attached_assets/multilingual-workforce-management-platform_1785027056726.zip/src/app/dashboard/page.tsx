'use client';

import { useEffect, useState } from 'react';
import { useLanguage } from '@/i18n/LanguageProvider';
import {
  Users, UserCheck, FileClock, FileClock as FileCheck, DollarSign,
  TrendingUp, Clock, Calendar, Activity, ArrowUpRight, ArrowDownRight,
  Bot, Sparkles
} from 'lucide-react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

export default function DashboardPage() {
  const { t } = useLanguage();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const userStr = localStorage.getItem('user');
    if (userStr) setUser(JSON.parse(userStr));
  }, []);

  // Demo data
  const stats = [
    { icon: Users, label: t('totalEmployees'), value: '248', change: '+12%', trend: 'up', color: 'from-blue-500 to-cyan-500' },
    { icon: UserCheck, label: t('presentToday'), value: '219', change: '+3%', trend: 'up', color: 'from-green-500 to-emerald-500' },
    { icon: FileCheck, label: t('onLeave'), value: '18', change: '-5%', trend: 'down', color: 'from-amber-500 to-orange-500' },
    { icon: FileClock, label: t('pendingRequests'), value: '7', change: '+2', trend: 'up', color: 'from-purple-500 to-pink-500' },
    { icon: DollarSign, label: t('monthlyPayroll'), value: '$284K', change: '+8.2%', trend: 'up', color: 'from-rose-500 to-red-500' },
    { icon: Clock, label: t('overtimeHours'), value: '1,247h', change: '+15%', trend: 'up', color: 'from-indigo-500 to-blue-500' },
  ];

  const weeklyData = [
    { day: 'Mon', present: 210, absent: 38 },
    { day: 'Tue', present: 225, absent: 23 },
    { day: 'Wed', present: 220, absent: 28 },
    { day: 'Thu', present: 218, absent: 30 },
    { day: 'Fri', present: 205, absent: 43 },
    { day: 'Sat', present: 45, absent: 203 },
    { day: 'Sun', present: 12, absent: 236 },
  ];

  const departmentData = [
    { name: 'Engineering', value: 85, color: '#6366f1' },
    { name: 'Marketing', value: 42, color: '#10b981' },
    { name: 'Sales', value: 58, color: '#f59e0b' },
    { name: 'HR', value: 25, color: '#ef4444' },
    { name: 'Finance', value: 38, color: '#8b5cf6' },
  ];

  const monthlyPayroll = [
    { month: 'Jan', amount: 245000 },
    { month: 'Feb', amount: 251000 },
    { month: 'Mar', amount: 258000 },
    { month: 'Apr', amount: 262000 },
    { month: 'May', amount: 275000 },
    { month: 'Jun', amount: 284000 },
  ];

  const recentActivities = [
    { user: 'John Smith', action: 'Clocked in', time: '2 min ago', type: 'clock-in' },
    { user: 'Sarah Johnson', action: 'Submitted leave request', time: '15 min ago', type: 'leave' },
    { user: 'Mohammed Ali', action: 'Approved overtime', time: '1 hour ago', type: 'approval' },
    { user: 'Emma Wilson', action: 'Updated profile', time: '2 hours ago', type: 'profile' },
    { user: 'Lars Svensson', action: 'Clocked out', time: '3 hours ago', type: 'clock-out' },
  ];

  const aiInsights = [
    { icon: TrendingUp, title: 'Productivity Up 12%', desc: 'Team productivity increased this month', color: 'bg-green-500' },
    { icon: Activity, title: 'Absenteeism Alert', desc: 'Higher than usual in Engineering dept', color: 'bg-red-500' },
    { icon: Sparkles, title: 'Cost Optimization', desc: 'Potential $12K savings identified', color: 'bg-blue-500' },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl p-8 bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 text-white">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5" />
            <span className="text-sm font-medium">AI-Powered Insights</span>
          </div>
          <h1 className="text-3xl font-bold mb-2">
            {t('welcome')}, {user?.fullName || 'User'}! 👋
          </h1>
          <p className="text-white/80 max-w-2xl">
            Here's what's happening with your workforce today. You have 7 pending requests and 3 upcoming deadlines.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button className="px-4 py-2 bg-white text-indigo-600 rounded-lg font-medium text-sm hover:scale-105 transition">
              {t('clockIn')}
            </button>
            <button className="px-4 py-2 bg-white/10 backdrop-blur rounded-lg font-medium text-sm hover:bg-white/20 transition">
              {t('newRequest')}
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat, i) => (
          <div
            key={i}
            className="p-6 rounded-2xl transition hover:shadow-lg"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className={`flex items-center gap-1 text-sm font-medium ${stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
                {stat.trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                {stat.change}
              </div>
            </div>
            <div className="text-3xl font-bold mb-1">{stat.value}</div>
            <div className="text-sm" style={{ color: 'var(--muted)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold">{t('attendanceOverview')}</h3>
              <p className="text-sm" style={{ color: 'var(--muted)' }}>Last 7 days</p>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1 rounded-lg text-xs font-medium bg-indigo-500 text-white">{t('weekly')}</button>
              <button className="px-3 py-1 rounded-lg text-xs font-medium" style={{ background: 'var(--background)' }}>{t('monthly')}</button>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="present" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="absent" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="day" stroke="var(--muted)" />
              <YAxis stroke="var(--muted)" />
              <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px' }} />
              <Legend />
              <Area type="monotone" dataKey="present" stroke="#10b981" fill="url(#present)" />
              <Area type="monotone" dataKey="absent" stroke="#ef4444" fill="url(#absent)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <h3 className="text-lg font-bold mb-6">{t('departmentDistribution')}</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={departmentData} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value">
                {departmentData.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-4">
            {departmentData.map((dept, i) => (
              <div key={i} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: dept.color }}></div>
                  <span>{dept.name}</span>
                </div>
                <span className="font-medium">{dept.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Payroll & Activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold">{t('monthlyPayroll')}</h3>
              <p className="text-sm" style={{ color: 'var(--muted)' }}>Last 6 months</p>
            </div>
            <DollarSign className="w-5 h-5 text-green-500" />
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthlyPayroll}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted)" />
              <YAxis stroke="var(--muted)" />
              <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px' }} />
              <Bar dataKey="amount" fill="url(#payrollGradient)" radius={[8, 8, 0, 0]} />
              <defs>
                <linearGradient id="payrollGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#8b5cf6" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <h3 className="text-lg font-bold mb-4">{t('recentActivity')}</h3>
          <div className="space-y-4">
            {recentActivities.map((activity, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {activity.user.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{activity.user}</div>
                  <div className="text-xs" style={{ color: 'var(--muted)' }}>{activity.action}</div>
                  <div className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{activity.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-fuchsia-500/10 via-purple-500/10 to-indigo-500/10 border border-purple-500/20">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-fuchsia-500 to-purple-600 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold">{t('insights')}</h3>
            <p className="text-sm" style={{ color: 'var(--muted)' }}>Powered by AI analytics</p>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {aiInsights.map((insight, i) => (
            <div key={i} className="p-4 rounded-xl" style={{ background: 'var(--card)' }}>
              <div className={`w-8 h-8 rounded-lg ${insight.color} flex items-center justify-center mb-3`}>
                <insight.icon className="w-4 h-4 text-white" />
              </div>
              <div className="font-bold mb-1">{insight.title}</div>
              <div className="text-sm" style={{ color: 'var(--muted)' }}>{insight.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
