'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { UserCheck, QrCode, Calendar, Shield } from 'lucide-react';

export default function VisitorsPage() {
  const { t } = useLanguage();

  const visitors = [
    { name: 'Ahmed Al-Rashid', company: 'Tech Corp', purpose: 'Meeting', time: '09:30', status: 'checked-in' },
    { name: 'Maria Garcia', company: 'Design Studio', purpose: 'Interview', time: '10:00', status: 'expected' },
    { name: 'Chen Wei', company: 'Investment Group', purpose: 'Presentation', time: '11:00', status: 'expected' },
    { name: 'Sarah Brown', company: 'Vendor', purpose: 'Delivery', time: '14:00', status: 'checked-out' },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('visitors')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Manage visitor access and appointments</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'Today', value: '12', icon: UserCheck, color: 'from-blue-500 to-cyan-500' },
          { label: 'Expected', value: '8', icon: Calendar, color: 'from-green-500 to-emerald-500' },
          { label: 'Checked In', value: '4', icon: QrCode, color: 'from-purple-500 to-pink-500' },
          { label: 'Security Checks', value: '45', icon: Shield, color: 'from-red-500 to-rose-500' },
        ].map((stat, i) => (
          <div key={i} className="p-5 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">Today's Visitors</h3>
        <div className="space-y-3">
          {visitors.map((visitor, i) => (
            <div key={i} className="flex items-center gap-4 p-4 rounded-xl" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
                {visitor.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div className="flex-1">
                <div className="font-medium">{visitor.name}</div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{visitor.company} • {visitor.purpose}</div>
              </div>
              <div className="text-right">
                <div className="font-medium text-sm">{visitor.time}</div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  visitor.status === 'checked-in' ? 'bg-green-500/10 text-green-500' :
                  visitor.status === 'expected' ? 'bg-blue-500/10 text-blue-500' :
                  'bg-gray-500/10 text-gray-500'
                }`}>
                  {visitor.status.replace('-', ' ')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
