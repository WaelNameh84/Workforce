'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Workflow, Zap, Bell, CheckCircle2, Clock } from 'lucide-react';

export default function AutomationPage() {
  const { t } = useLanguage();

  const automations = [
    { name: 'Auto-approve leave < 3 days', trigger: 'Leave request submitted', action: 'Auto approve', runs: 45, active: true },
    { name: 'Late arrival notification', trigger: 'Clock in after 9:15 AM', action: 'Send email to manager', runs: 12, active: true },
    { name: 'Payroll reminder', trigger: '5 days before payday', action: 'Send reminder to finance', runs: 1, active: true },
    { name: 'Birthday greeting', trigger: 'Employee birthday', action: 'Send WhatsApp message', runs: 3, active: false },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('automation')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Automate workflows with IF/THEN rules</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: 'Active Rules', value: '24', icon: Zap, color: 'from-amber-500 to-orange-500' },
          { label: 'Executions Today', value: '156', icon: Workflow, color: 'from-blue-500 to-cyan-500' },
          { label: 'Time Saved', value: '48h', icon: Clock, color: 'from-green-500 to-emerald-500' },
        ].map((stat, i) => (
          <div key={i} className="p-5 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        {automations.map((auto, i) => (
          <div key={i} className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                <Workflow className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-bold">{auto.name}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${auto.active ? 'bg-green-500/10 text-green-500' : 'bg-gray-500/10 text-gray-500'}`}>
                    {auto.active ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="space-y-1 text-sm">
                  <div><strong>IF:</strong> <span style={{ color: 'var(--muted)' }}>{auto.trigger}</span></div>
                  <div><strong>THEN:</strong> <span style={{ color: 'var(--muted)' }}>{auto.action}</span></div>
                </div>
                <div className="flex items-center gap-4 mt-3 text-xs" style={{ color: 'var(--muted)' }}>
                  <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />{auto.runs} runs</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
