'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Settings, Bell, Building2, Globe, Palette, Shield, Key, Database, Moon, Sun } from 'lucide-react';
import { useState } from 'react';

export default function SettingsPage() {
  const { t, locale, setLocale } = useLanguage();
  const [theme, setTheme] = useState('light');
  const [saved, setSaved] = useState(false);

  const save = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('settings')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Customize your workspace</p>
      </div>

      {saved && (
        <div className="p-4 rounded-xl bg-green-500/10 text-green-500 font-medium">{t('savedSuccessfully')}</div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Company Info */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-6">
              <Building2 className="w-5 h-5 text-indigo-500" />
              <h3 className="text-lg font-bold">{t('companyInfo')}</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Company Name</label>
                <input defaultValue="Global Tech Solutions" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Industry</label>
                <input defaultValue="Technology" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Country</label>
                <select className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }}>
                  <option>🇸🇪 Sweden</option>
                  <option>🇸🇦 Saudi Arabia</option>
                  <option>🇺🇸 United States</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Currency</label>
                <select className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }}>
                  <option>SEK - Swedish Krona</option>
                  <option>USD - US Dollar</option>
                  <option>SAR - Saudi Riyal</option>
                </select>
              </div>
            </div>
          </div>

          {/* Working Hours */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <h3 className="text-lg font-bold mb-6">{t('workingHours')}</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Start Time</label>
                <input type="time" defaultValue="09:00" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">End Time</label>
                <input type="time" defaultValue="17:00" className="w-full rounded-lg px-4 py-2.5 text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)', color: 'var(--foreground)' }} />
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-5 h-5 text-amber-500" />
              <h3 className="text-lg font-bold">{t('notifications')}</h3>
            </div>
            <div className="space-y-4">
              {['Email notifications', 'Push notifications', 'SMS alerts', 'WhatsApp updates'].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2">
                  <span className="text-sm">{item}</span>
                  <label className="relative inline-block w-12 h-6">
                    <input type="checkbox" defaultChecked className="opacity-0 w-0 h-0 peer" />
                    <span className="absolute cursor-pointer top-0 left-0 right-0 bottom-0 bg-gray-300 peer-checked:bg-indigo-500 transition rounded-full before:content-[''] before:absolute before:h-5 before:w-5 before:left-0.5 before:bottom-0.5 before:bg-white before:rounded-full before:transition peer-checked:before:translate-x-6"></span>
                  </label>
                </div>
              ))}
            </div>
          </div>

          <button onClick={save} className="w-full md:w-auto px-8 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-medium">
            {t('save')}
          </button>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          {/* Theme */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-4">
              <Palette className="w-5 h-5 text-pink-500" />
              <h3 className="font-bold">{t('theme')}</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button className="p-4 rounded-xl text-center" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
                <Sun className="w-5 h-5 mx-auto mb-2" />
                <div className="text-xs font-medium">{t('lightMode')}</div>
              </button>
              <button className="p-4 rounded-xl text-center bg-gray-800 text-white">
                <Moon className="w-5 h-5 mx-auto mb-2" />
                <div className="text-xs font-medium">{t('darkMode')}</div>
              </button>
            </div>
          </div>

          {/* Language */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-4">
              <Globe className="w-5 h-5 text-blue-500" />
              <h3 className="font-bold">{t('language')}</h3>
            </div>
            <div className="space-y-2">
              {[
                { code: 'en', name: 'English', flag: '🇺🇸' },
                { code: 'ar', name: 'العربية', flag: '🇸🇦' },
                { code: 'sv', name: 'Svenska', flag: '🇸🇪' },
              ].map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLocale(lang.code as any)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition ${locale === lang.code ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                  style={locale !== lang.code ? { background: 'var(--background)', border: '1px solid var(--border)' } : {}}
                >
                  <span className="text-xl">{lang.flag}</span>
                  <span className="font-medium text-sm">{lang.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Security */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-5 h-5 text-red-500" />
              <h3 className="font-bold">{t('security')}</h3>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span>AES-256 Encryption</span><span className="text-green-500">✓</span></div>
              <div className="flex justify-between"><span>JWT Tokens</span><span className="text-green-500">✓</span></div>
              <div className="flex justify-between"><span>MFA</span><span className="text-green-500">✓</span></div>
              <div className="flex justify-between"><span>GDPR Compliance</span><span className="text-green-500">✓</span></div>
            </div>
          </div>

          {/* API Keys */}
          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-4">
              <Key className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold">{t('apiKeys')}</h3>
            </div>
            <div className="space-y-2 text-xs font-mono">
              <div className="p-2 rounded-lg break-all" style={{ background: 'var(--background)' }}>pk_live_••••••••••••••••</div>
              <div className="p-2 rounded-lg break-all" style={{ background: 'var(--background)' }}>sk_live_••••••••••••••••</div>
            </div>
          </div>

          <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3 mb-4">
              <Database className="w-5 h-5 text-green-500" />
              <h3 className="font-bold">Backup</h3>
            </div>
            <div className="text-sm" style={{ color: 'var(--muted)' }}>Last backup: 2 hours ago</div>
            <button className="mt-3 w-full py-2 rounded-lg text-sm font-medium bg-green-500 text-white">
              Backup Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
