'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Award, TrendingUp, Target, Star } from 'lucide-react';

export default function PerformancePage() {
  const { t } = useLanguage();

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('performance')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Track and manage employee performance</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Avg. Score', value: '8.4/10', icon: Star, color: 'from-amber-500 to-orange-500' },
          { label: 'Top Performers', value: '42', icon: Award, color: 'from-purple-500 to-pink-500' },
          { label: 'Goals Achieved', value: '89%', icon: Target, color: 'from-green-500 to-emerald-500' },
          { label: 'Improvement', value: '+12%', icon: TrendingUp, color: 'from-blue-500 to-cyan-500' },
        ].map((stat, i) => (
          <div key={i} className="p-5 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">Top Performers</h3>
        <div className="space-y-3">
          {[
            { name: 'John Smith', score: 9.5, goals: 12, position: 'Senior Developer' },
            { name: 'Sarah Johnson', score: 9.2, goals: 10, position: 'HR Manager' },
            { name: 'Mohammed Ali', score: 8.9, goals: 11, position: 'Frontend Developer' },
            { name: 'Emma Wilson', score: 8.7, goals: 9, position: 'Accountant' },
          ].map((emp, i) => (
            <div key={i} className="flex items-center gap-4 p-4 rounded-xl" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
                {emp.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div className="flex-1">
                <div className="font-medium">{emp.name}</div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{emp.position}</div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-indigo-500">{emp.score}</div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{emp.goals} goals</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
