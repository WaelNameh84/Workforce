'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Package, Laptop, Phone, Car, CreditCard, Check, X } from 'lucide-react';

export default function AssetsPage() {
  const { t } = useLanguage();

  const assets = [
    { name: 'MacBook Pro 16"', type: 'laptop', serial: 'SN001', assigned: 'John Smith', status: 'assigned' },
    { name: 'iPhone 15 Pro', type: 'phone', serial: 'SN002', assigned: 'Sarah Johnson', status: 'assigned' },
    { name: 'Dell Monitor 27"', type: 'monitor', serial: 'SN003', assigned: null, status: 'available' },
    { name: 'Office Key Card', type: 'card', serial: 'SN004', assigned: 'Mohammed Ali', status: 'assigned' },
    { name: 'Company Vehicle', type: 'vehicle', serial: 'SN005', assigned: 'Emma Wilson', status: 'assigned' },
  ];

  const typeIcons: Record<string, any> = {
    laptop: <Laptop className="w-5 h-5" />,
    phone: <Phone className="w-5 h-5" />,
    monitor: <Package className="w-5 h-5" />,
    card: <CreditCard className="w-5 h-5" />,
    vehicle: <Car className="w-5 h-5" />,
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('assets')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Manage company assets and equipment</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'Total Assets', value: '156', color: 'from-blue-500 to-cyan-500' },
          { label: 'Assigned', value: '124', color: 'from-green-500 to-emerald-500' },
          { label: 'Available', value: '28', color: 'from-amber-500 to-orange-500' },
          { label: 'Maintenance', value: '4', color: 'from-red-500 to-rose-500' },
        ].map((stat, i) => (
          <div key={i} className="p-5 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className={`h-1 rounded-full mb-4 bg-gradient-to-r ${stat.color}`}></div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-2xl overflow-x-auto" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">Asset Inventory</h3>
        <table className="w-full min-w-[700px]">
          <thead>
            <tr className="text-sm" style={{ color: 'var(--muted)' }}>
              <th className="text-left py-3 px-2 font-medium">Asset</th>
              <th className="text-left py-3 px-2 font-medium">Type</th>
              <th className="text-left py-3 px-2 font-medium">Serial</th>
              <th className="text-left py-3 px-2 font-medium">Assigned To</th>
              <th className="text-left py-3 px-2 font-medium">{t('status')}</th>
            </tr>
          </thead>
          <tbody>
            {assets.map((asset, i) => (
              <tr key={i} className="text-sm border-t" style={{ borderColor: 'var(--border)' }}>
                <td className="py-3 px-2 font-medium">{asset.name}</td>
                <td className="py-3 px-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-500">
                      {typeIcons[asset.type]}
                    </div>
                    <span className="capitalize">{asset.type}</span>
                  </div>
                </td>
                <td className="py-3 px-2 font-mono text-xs">{asset.serial}</td>
                <td className="py-3 px-2">{asset.assigned || '-'}</td>
                <td className="py-3 px-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${asset.status === 'assigned' ? 'bg-green-500/10 text-green-500' : 'bg-amber-500/10 text-amber-500'}`}>
                    {asset.status === 'assigned' ? <Check className="w-3 h-3 inline me-1" /> : <X className="w-3 h-3 inline me-1" />}
                    {asset.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
