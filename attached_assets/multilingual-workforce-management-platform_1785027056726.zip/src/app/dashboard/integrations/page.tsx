'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Plug, CheckCircle2, ExternalLink } from 'lucide-react';

export default function IntegrationsPage() {
  const { t } = useLanguage();

  const integrations = [
    { name: 'Google Workspace', desc: 'Calendar, Drive, Gmail', connected: true, color: 'from-blue-500 via-red-500 to-yellow-500' },
    { name: 'Microsoft 365', desc: 'Outlook, Teams, OneDrive', connected: true, color: 'from-blue-600 to-blue-800' },
    { name: 'Slack', desc: 'Team messaging', connected: true, color: 'from-purple-500 to-pink-500' },
    { name: 'Zoom', desc: 'Video conferencing', connected: false, color: 'from-blue-500 to-cyan-500' },
    { name: 'Stripe', desc: 'Payment processing', connected: true, color: 'from-indigo-500 to-purple-600' },
    { name: 'PayPal', desc: 'Online payments', connected: false, color: 'from-blue-600 to-blue-800' },
    { name: 'SAP', desc: 'Enterprise resource planning', connected: false, color: 'from-blue-700 to-blue-900' },
    { name: 'Oracle', desc: 'Database & ERP', connected: false, color: 'from-red-600 to-red-800' },
    { name: 'QuickBooks', desc: 'Accounting software', connected: true, color: 'from-green-500 to-emerald-600' },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('integrations')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Connect with your favorite tools</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {integrations.map((int, i) => (
          <div key={i} className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${int.color} flex items-center justify-center`}>
                <Plug className="w-6 h-6 text-white" />
              </div>
              {int.connected && <CheckCircle2 className="w-5 h-5 text-green-500" />}
            </div>
            <h3 className="font-bold mb-1">{int.name}</h3>
            <p className="text-xs mb-4" style={{ color: 'var(--muted)' }}>{int.desc}</p>
            <button className={`w-full py-2 rounded-lg text-sm font-medium ${int.connected ? 'bg-green-500/10 text-green-500' : 'bg-indigo-500 text-white'}`}>
              {int.connected ? '✓ Connected' : 'Connect'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
