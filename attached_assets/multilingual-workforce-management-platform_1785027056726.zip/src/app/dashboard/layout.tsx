'use client';

import { useEffect, useState, ReactNode } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useTheme } from '@/app/providers';
import {
  LayoutDashboard, Users, Clock, Calendar, FileText, DollarSign,
  SendHorizontal, BarChart3, Settings, LogOut, Globe, Moon, Sun,
  Bell, Search, Menu, X, MessageSquare, Award, Package, UserCheck,
  Workflow, Plug, Shield, Code2, Bot, ChevronDown
} from 'lucide-react';

interface User {
  id: number;
  email: string;
  fullName: string;
  role: string;
  companyId: number;
}

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const { t, locale, setLocale } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<User | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');
    if (!token || !userStr) {
      router.push('/login');
      return;
    }
    try {
      setUser(JSON.parse(userStr));
    } catch {
      router.push('/login');
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/login');
  };

  const navGroups = [
    {
      title: 'Main',
      items: [
        { href: '/dashboard', icon: LayoutDashboard, label: t('dashboard') },
      ],
    },
    {
      title: 'HR Management',
      items: [
        { href: '/dashboard/employees', icon: Users, label: t('employees') },
        { href: '/dashboard/attendance', icon: Clock, label: t('attendance') },
        { href: '/dashboard/schedule', icon: Calendar, label: t('schedule') },
        { href: '/dashboard/leaves', icon: FileText, label: t('leaves') },
        { href: '/dashboard/payroll', icon: DollarSign, label: t('payroll') },
        { href: '/dashboard/requests', icon: SendHorizontal, label: t('requests') },
      ],
    },
    {
      title: 'Advanced',
      items: [
        { href: '/dashboard/reports', icon: BarChart3, label: t('reports') },
        { href: '/dashboard/ai', icon: Bot, label: t('aiAssistant') },
        { href: '/dashboard/communication', icon: MessageSquare, label: t('communication') },
        { href: '/dashboard/performance', icon: Award, label: t('performance') },
        { href: '/dashboard/assets', icon: Package, label: t('assets') },
        { href: '/dashboard/visitors', icon: UserCheck, label: t('visitors') },
      ],
    },
    {
      title: 'System',
      items: [
        { href: '/dashboard/automation', icon: Workflow, label: t('automation') },
        { href: '/dashboard/integrations', icon: Plug, label: t('integrations') },
        { href: '/dashboard/security', icon: Shield, label: t('security') },
        { href: '/dashboard/developers', icon: Code2, label: t('developers') },
        { href: '/dashboard/settings', icon: Settings, label: t('settings') },
      ],
    },
  ];

  const languages = [
    { code: 'en', flag: '🇺🇸', name: 'English' },
    { code: 'ar', flag: '🇸🇦', name: 'العربية' },
    { code: 'sv', flag: '🇸🇪', name: 'Svenska' },
  ];

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--background)' }}>
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--background)', color: 'var(--foreground)' }}>
      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 h-screen w-72 border-r z-40 transition-transform overflow-y-auto ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'} ${locale === 'ar' ? 'right-0 lg:right-0 translate-x-full lg:translate-x-0' : ''}`} style={{ background: 'var(--card)', borderColor: 'var(--border)' }}>
        <div className="p-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-lg">{t('appName')}</span>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-3 space-y-6">
          {navGroups.map((group, gi) => (
            <div key={gi}>
              <div className="px-3 mb-2 text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted)' }}>
                {group.title}
              </div>
              <div className="space-y-1">
                {group.items.map((item, i) => {
                  const isActive = item.href === '/dashboard' ? pathname === '/dashboard' : pathname.startsWith(item.href);
                  return (
                    <Link
                      key={i}
                      href={item.href}
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition ${
                        isActive ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)}></div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-20 border-b backdrop-blur-lg" style={{ background: 'color-mix(in srgb, var(--background) 80%, transparent)', borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-between h-16 px-4 lg:px-8">
            <div className="flex items-center gap-4 flex-1">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden">
                <Menu className="w-6 h-6" />
              </button>
              <div className="relative flex-1 max-w-md hidden md:block">
                <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 left-3" style={{ color: 'var(--muted)' }} />
                <input
                  type="text"
                  placeholder={t('search') + '...'}
                  className="w-full ps-10 pe-4 py-2 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </button>

              <div className="relative">
                <select
                  value={locale}
                  onChange={(e) => setLocale(e.target.value as any)}
                  className="appearance-none ps-2 pe-6 py-2 rounded-lg text-sm font-medium cursor-pointer focus:outline-none"
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                >
                  {languages.map((lang) => (
                    <option key={lang.code} value={lang.code}>{lang.flag} {lang.name}</option>
                  ))}
                </select>
              </div>

              <button className="relative p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                <Bell className="w-4 h-4" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>

              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold">
                    {user.fullName.charAt(0)}
                  </div>
                  <div className="hidden md:block text-left">
                    <div className="text-sm font-medium">{user.fullName}</div>
                    <div className="text-xs" style={{ color: 'var(--muted)' }}>{user.role}</div>
                  </div>
                  <ChevronDown className="w-4 h-4 hidden md:block" />
                </button>

                {userMenuOpen && (
                  <div className="absolute top-full right-0 mt-2 w-56 rounded-xl shadow-lg py-1" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
                      <div className="font-medium">{user.fullName}</div>
                      <div className="text-xs" style={{ color: 'var(--muted)' }}>{user.email}</div>
                    </div>
                    <Link href="/dashboard/settings" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                      <Settings className="w-4 h-4" />
                      {t('settings')}
                    </Link>
                    <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                      <LogOut className="w-4 h-4" />
                      {t('logout')}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
