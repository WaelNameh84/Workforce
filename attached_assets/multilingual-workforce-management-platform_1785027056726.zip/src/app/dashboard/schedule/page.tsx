'use client';

import { useState } from 'react';
import { useLanguage } from '@/i18n/LanguageProvider';
import { Calendar, ChevronLeft, ChevronRight, Clock, Sun, Moon, Home, Briefcase } from 'lucide-react';

const demoSchedule = [
  { day: 'Mon', shift: 'morning', time: '09:00 - 17:00', remote: false },
  { day: 'Tue', shift: 'morning', time: '09:00 - 17:00', remote: true },
  { day: 'Wed', shift: 'morning', time: '09:00 - 17:00', remote: false },
  { day: 'Thu', shift: 'evening', time: '14:00 - 22:00', remote: false },
  { day: 'Fri', shift: 'morning', time: '09:00 - 15:00', remote: true },
  { day: 'Sat', shift: 'off', time: 'Off', remote: false },
  { day: 'Sun', shift: 'off', time: 'Off', remote: false },
];

export default function SchedulePage() {
  const { t } = useLanguage();
  const [view, setView] = useState<'week' | 'month'>('week');

  const shiftColors = {
    morning: 'bg-gradient-to-br from-amber-400 to-orange-500',
    evening: 'bg-gradient-to-br from-purple-500 to-pink-500',
    night: 'bg-gradient-to-br from-indigo-600 to-blue-900',
    off: 'bg-gradient-to-br from-gray-300 to-gray-400',
  };

  const shiftIcons = {
    morning: <Sun className="w-4 h-4" />,
    evening: <Briefcase className="w-4 h-4" />,
    night: <Moon className="w-4 h-4" />,
    off: <Home className="w-4 h-4" />,
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">{t('schedule')}</h1>
          <p className="text-sm" style={{ color: 'var(--muted)' }}>Plan and manage work schedules</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setView('week')} className={`px-4 py-2 rounded-lg text-sm font-medium ${view === 'week' ? 'bg-indigo-500 text-white' : ''}`} style={view !== 'week' ? { background: 'var(--card)', border: '1px solid var(--border)' } : {}}>
            {t('weekly')}
          </button>
          <button onClick={() => setView('month')} className={`px-4 py-2 rounded-lg text-sm font-medium ${view === 'month' ? 'bg-indigo-500 text-white' : ''}`} style={view !== 'month' ? { background: 'var(--card)', border: '1px solid var(--border)' } : {}}>
            {t('monthly')}
          </button>
        </div>
      </div>

      {/* Week Navigation */}
      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div className="flex items-center justify-between mb-6">
          <button className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h3 className="text-lg font-bold">January 20-26, 2026</h3>
          <button className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-3">
          {demoSchedule.map((day, i) => (
            <div key={i} className={`p-4 rounded-xl text-white ${shiftColors[day.shift as keyof typeof shiftColors]} min-h-[180px]`}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-xs opacity-80">{day.day}</div>
                  <div className="text-2xl font-bold">{20 + i}</div>
                </div>
                {shiftIcons[day.shift as keyof typeof shiftIcons]}
              </div>
              <div className="text-sm font-medium mb-1">
                {day.shift === 'off' ? 'Day Off' : day.shift.charAt(0).toUpperCase() + day.shift.slice(1)}
              </div>
              {day.shift !== 'off' && (
                <div className="flex items-center gap-1 text-xs opacity-90">
                  <Clock className="w-3 h-3" />
                  {day.time}
                </div>
              )}
              {day.remote && (
                <div className="mt-2 inline-block px-2 py-1 bg-white/20 backdrop-blur rounded text-xs">
                  🏠 Remote
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Shift Types */}
      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">{t('shiftType')}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { type: 'morning', name: t('morningShift'), time: '06:00 - 14:00', color: 'from-amber-400 to-orange-500', icon: '🌅' },
            { type: 'evening', name: t('eveningShift'), time: '14:00 - 22:00', color: 'from-purple-500 to-pink-500', icon: '🌇' },
            { type: 'night', name: t('nightShift'), time: '22:00 - 06:00', color: 'from-indigo-600 to-blue-900', icon: '🌙' },
            { type: 'flexible', name: 'Flexible', time: 'Any', color: 'from-green-500 to-emerald-500', icon: '⏰' },
          ].map((shift, i) => (
            <div key={i} className={`p-4 rounded-xl bg-gradient-to-br ${shift.color} text-white`}>
              <div className="text-2xl mb-2">{shift.icon}</div>
              <div className="font-bold">{shift.name}</div>
              <div className="text-xs opacity-80 mt-1">{shift.time}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Team Schedule */}
      <div className="p-6 rounded-2xl overflow-x-auto" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">Team Schedule</h3>
        <table className="w-full min-w-[600px]">
          <thead>
            <tr className="text-sm" style={{ color: 'var(--muted)' }}>
              <th className="text-left py-2 px-2 font-medium">Employee</th>
              <th className="text-center py-2 px-2 font-medium">Mon</th>
              <th className="text-center py-2 px-2 font-medium">Tue</th>
              <th className="text-center py-2 px-2 font-medium">Wed</th>
              <th className="text-center py-2 px-2 font-medium">Thu</th>
              <th className="text-center py-2 px-2 font-medium">Fri</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {['John Smith', 'Sarah Johnson', 'Mohammed Ali', 'Emma Wilson'].map((name, i) => (
              <tr key={i} className="border-t" style={{ borderColor: 'var(--border)' }}>
                <td className="py-3 px-2 font-medium">{name}</td>
                {[0, 1, 2, 3, 4].map((d) => {
                  const shifts = ['morning', 'morning', 'evening', 'morning', 'off'];
                  return (
                    <td key={d} className="py-2 px-1">
                      <div className={`mx-auto w-12 h-12 rounded-lg ${shiftColors[shifts[d] as keyof typeof shiftColors]} text-white flex items-center justify-center text-xs`}>
                        {shiftIcons[shifts[d] as keyof typeof shiftIcons]}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
