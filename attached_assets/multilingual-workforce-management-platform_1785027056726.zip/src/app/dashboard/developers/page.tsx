'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { Code2, Key, FileText, Globe, Terminal } from 'lucide-react';

export default function DevelopersPage() {
  const { t } = useLanguage();

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('developers')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>API documentation and developer tools</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: 'API Endpoints', value: '124', icon: Globe, color: 'from-blue-500 to-cyan-500' },
          { label: 'API Calls Today', value: '45.2K', icon: Terminal, color: 'from-green-500 to-emerald-500' },
          { label: 'Active Keys', value: '8', icon: Key, color: 'from-purple-500 to-pink-500' },
        ].map((stat, i) => (
          <div key={i} className="p-5 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="flex items-center gap-3 mb-4">
            <Code2 className="w-5 h-5 text-indigo-500" />
            <h3 className="text-lg font-bold">REST API</h3>
          </div>
          <div className="space-y-3 text-sm">
            <div className="p-3 rounded-lg font-mono text-xs" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
              GET /api/v1/employees<br />
              POST /api/v1/attendance<br />
              PUT /api/v1/employees/:id<br />
              DELETE /api/v1/employees/:id
            </div>
            <button className="w-full py-2 rounded-lg bg-indigo-500 text-white font-medium">
              View Full Docs
            </button>
          </div>
        </div>

        <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="flex items-center gap-3 mb-4">
            <Key className="w-5 h-5 text-amber-500" />
            <h3 className="text-lg font-bold">API Keys</h3>
          </div>
          <div className="space-y-2 text-sm">
            {[
              { name: 'Production', key: 'pk_live_••••••••••', created: 'Jan 1, 2026' },
              { name: 'Development', key: 'pk_test_••••••••••', created: 'Jan 15, 2026' },
            ].map((key, i) => (
              <div key={i} className="p-3 rounded-lg" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium">{key.name}</span>
                  <span className="text-xs" style={{ color: 'var(--muted)' }}>{key.created}</span>
                </div>
                <div className="font-mono text-xs" style={{ color: 'var(--muted)' }}>{key.key}</div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-medium">
            Generate New Key
          </button>
        </div>
      </div>

      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div className="flex items-center gap-3 mb-4">
          <FileText className="w-5 h-5 text-green-500" />
          <h3 className="text-lg font-bold">Documentation</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {['Getting Started', 'Authentication', 'Webhooks', 'SDKs', 'GraphQL', 'Rate Limits'].map((doc, i) => (
            <button key={i} className="p-4 rounded-xl text-left hover:shadow-lg transition" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
              <FileText className="w-5 h-5 mb-2 text-indigo-500" />
              <div className="font-medium text-sm">{doc}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
