'use client';

import { useState } from 'react';
import { useLanguage } from '@/i18n/LanguageProvider';
import { Clock, MapPin, Play, Square, Coffee, CheckCircle2, XCircle, AlertCircle, Calendar } from 'lucide-react';

const demoAttendance = [
  { date: '2026-01-20', clockIn: '09:00', clockOut: '17:00', break: '60min', hours: 8, status: 'present', late: false, location: 'Office' },
  { date: '2026-01-19', clockIn: '09:15', clockOut: '17:30', break: '60min', hours: 8.25, status: 'present', late: true, location: 'Office' },
  { date: '2026-01-18', clockIn: '08:55', clockOut: '17:00', break: '60min', hours: 8, status: 'present', late: false, location: 'Remote' },
  { date: '2026-01-17', clockIn: '-', clockOut: '-', break: '-', hours: 0, status: 'leave', late: false, location: '-' },
  { date: '2026-01-16', clockIn: '09:05', clockOut: '17:00', break: '60min', hours: 8, status: 'present', late: false, location: 'Office' },
];

export default function AttendancePage() {
  const { t } = useLanguage();
  const [clockedIn, setClockedIn] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useState(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  });

  const statusColor = (status: string) => {
    if (status === 'present') return 'bg-green-500/10 text-green-500';
    if (status === 'absent') return 'bg-red-500/10 text-red-500';
    if (status === 'leave') return 'bg-amber-500/10 text-amber-500';
    return 'bg-gray-500/10 text-gray-500';
  };

  const stats = [
    { label: 'This Month', value: '22 days', sub: 'Present' },
    { label: 'Late Arrivals', value: '3', sub: 'Times' },
    { label: 'Total Hours', value: '176h', sub: 'This month' },
    { label: 'Overtime', value: '12h', sub: 'This month' },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h1 className="text-2xl font-bold">{t('attendance')}</h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Track and manage your attendance</p>
      </div>

      {/* Clock Widget */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1 p-8 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 text-white">
          <div className="text-sm opacity-80 mb-2">{t('time')}</div>
          <div className="text-5xl font-bold mb-2">
            {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}
          </div>
          <div className="text-sm opacity-80 mb-6">
            {currentTime.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <div className="flex gap-3">
            {!clockedIn ? (
              <button
                onClick={() => setClockedIn(true)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white text-indigo-600 rounded-xl font-semibold hover:scale-105 transition"
              >
                <Play className="w-4 h-4" />
                {t('clockIn')}
              </button>
            ) : (
              <button
                onClick={() => setClockedIn(false)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white/10 backdrop-blur text-white rounded-xl font-semibold hover:bg-white/20 transition"
              >
                <Square className="w-4 h-4" />
                {t('clockOut')}
              </button>
            )}
            <button className="px-4 py-3 bg-white/10 backdrop-blur rounded-xl hover:bg-white/20 transition">
              <Coffee className="w-4 h-4" />
            </button>
          </div>
          <div className="mt-4 pt-4 border-t border-white/20 grid grid-cols-2 gap-2 text-sm">
            <div>
              <div className="opacity-80">Clock In</div>
              <div className="font-semibold">09:00</div>
            </div>
            <div>
              <div className="opacity-80">{t('totalHours')}</div>
              <div className="font-semibold">6h 23m</div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="md:col-span-2 grid grid-cols-2 gap-4">
          {stats.map((stat, i) => (
            <div key={i} className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <div className="text-sm" style={{ color: 'var(--muted)' }}>{stat.label}</div>
              <div className="text-3xl font-bold mt-2">{stat.value}</div>
              <div className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{stat.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Methods */}
      <div className="p-6 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <h3 className="text-lg font-bold mb-4">Check-in Methods</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {[
            { icon: '📍', name: 'GPS' },
            { icon: '📶', name: 'WiFi' },
            { icon: '🔵', name: 'Bluetooth' },
            { icon: '📷', name: t('faceId') },
            { icon: '📱', name: t('qrCode') },
            { icon: '💳', name: t('nfc') },
          ].map((method, i) => (
            <button key={i} className="p-4 rounded-xl text-center hover:scale-105 transition" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
              <div className="text-2xl mb-2">{method.icon}</div>
              <div className="text-sm font-medium">{method.name}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Attendance Table */}
      <div className="p-6 rounded-2xl overflow-x-auto" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold">Attendance History</h3>
          <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm" style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
            <Calendar className="w-4 h-4" />
            This Month
          </button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="text-sm border-b" style={{ borderColor: 'var(--border)', color: 'var(--muted)' }}>
              <th className="text-left py-3 px-2 font-medium">{t('date')}</th>
              <th className="text-left py-3 px-2 font-medium">{t('clockIn')}</th>
              <th className="text-left py-3 px-2 font-medium">{t('clockOut')}</th>
              <th className="text-left py-3 px-2 font-medium">Break</th>
              <th className="text-left py-3 px-2 font-medium">{t('totalHours')}</th>
              <th className="text-left py-3 px-2 font-medium">{t('location')}</th>
              <th className="text-left py-3 px-2 font-medium">{t('status')}</th>
            </tr>
          </thead>
          <tbody>
            {demoAttendance.map((att, i) => (
              <tr key={i} className="text-sm border-b last:border-0" style={{ borderColor: 'var(--border)' }}>
                <td className="py-3 px-2 font-medium">{att.date}</td>
                <td className="py-3 px-2">
                  {att.clockIn !== '-' ? (
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-green-500" />{att.clockIn}</span>
                  ) : '-'}
                </td>
                <td className="py-3 px-2">
                  {att.clockOut !== '-' ? (
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-red-500" />{att.clockOut}</span>
                  ) : '-'}
                </td>
                <td className="py-3 px-2">{att.break}</td>
                <td className="py-3 px-2 font-medium">{att.hours}h</td>
                <td className="py-3 px-2">
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{att.location}</span>
                </td>
                <td className="py-3 px-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor(att.status)}`}>
                    {att.status === 'present' && <CheckCircle2 className="w-3 h-3 inline me-1" />}
                    {att.status === 'leave' && <Calendar className="w-3 h-3 inline me-1" />}
                    {att.status}
                    {att.late && <AlertCircle className="w-3 h-3 inline ms-1 text-amber-500" />}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
