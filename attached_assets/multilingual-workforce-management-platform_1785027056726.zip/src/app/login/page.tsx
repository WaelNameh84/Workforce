'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useTheme } from '@/app/providers';
import {
  Globe, Mail, Lock, ArrowRight, Moon, Sun, Fingerprint, QrCode,
  Smartphone, KeyRound, Wifi
} from 'lucide-react';

export default function LoginPage() {
  const { t, locale, setLocale } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const router = useRouter();
  const [email, setEmail] = useState('admin@company.com');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Login failed');
        setLoading(false);
        return;
      }

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      router.push('/dashboard');
    } catch (err) {
      setError('Network error');
      setLoading(false);
    }
  };

  const languages = [
    { code: 'en', flag: '🇺🇸' },
    { code: 'ar', flag: '🇸🇦' },
    { code: 'sv', flag: '🇸🇪' },
  ];

  const authMethods = [
    { icon: KeyRound, name: 'Password', color: 'bg-indigo-500' },
    { icon: Fingerprint, name: t('faceId'), color: 'bg-blue-500' },
    { icon: Smartphone, name: t('fingerprint'), color: 'bg-purple-500' },
    { icon: QrCode, name: t('qrCode'), color: 'bg-green-500' },
    { icon: Wifi, name: t('nfc'), color: 'bg-orange-500' },
    { icon: Shield, name: 'SSO', color: 'bg-red-500' },
  ];

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--background)', color: 'var(--foreground)' }}>
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        </div>
        <div className="relative z-10 p-12 flex flex-col justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Globe className="w-7 h-7" />
            </div>
            <span className="text-2xl font-bold">{t('appName')}</span>
          </div>
          <div>
            <h1 className="text-4xl font-bold mb-4 leading-tight">
              {t('heroTitle')}
            </h1>
            <p className="text-lg opacity-90 mb-8">
              {t('heroSubtitle')}
            </p>
            <div className="grid grid-cols-2 gap-4">
              {[
                { value: '10K+', label: 'Companies' },
                { value: '2M+', label: 'Employees' },
                { value: '150+', label: 'Countries' },
                { value: '24/7', label: 'Support' },
              ].map((stat, i) => (
                <div key={i} className="p-4 rounded-xl bg-white/10 backdrop-blur">
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm opacity-80">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="text-sm opacity-80">
            © 2026 {t('appName')}. All rights reserved.
          </div>
        </div>
      </div>

      {/* Right side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="flex justify-between items-center mb-8">
            <Link href="/" className="flex items-center gap-2 lg:hidden">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">{t('appName')}</span>
            </Link>
            <div className="flex items-center gap-2 ms-auto">
              <div className="flex items-center gap-1 p-1 rounded-lg" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setLocale(lang.code as any)}
                    className={`px-2 py-1 rounded text-xs font-medium transition ${
                      locale === lang.code ? 'bg-indigo-500 text-white' : ''
                    }`}
                  >
                    {lang.flag}
                  </button>
                ))}
              </div>
              <button onClick={toggleTheme} className="p-2 rounded-lg" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('loginTitle')}</h2>
            <p style={{ color: 'var(--muted)' }}>{t('loginSubtitle')}</p>
          </div>

          {/* Auth Methods */}
          <div className="mb-6">
            <div className="flex flex-wrap gap-2 mb-4">
              {authMethods.map((method, i) => (
                <button
                  key={i}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition hover:scale-105"
                  style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
                >
                  <div className={`w-5 h-5 rounded ${method.color} flex items-center justify-center`}>
                    <method.icon className="w-3 h-3 text-white" />
                  </div>
                  {method.name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <div className="flex-1 h-px" style={{ background: 'var(--border)' }}></div>
            <span className="text-xs font-medium" style={{ color: 'var(--muted)' }}>{t('orContinueWith').toUpperCase()}</span>
            <div className="flex-1 h-px" style={{ background: 'var(--border)' }}></div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">{t('email')}</label>
              <div className="relative">
                <Mail className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full rounded-lg px-10 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${locale === 'ar' ? 'text-right' : ''}`}
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  placeholder="admin@company.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">{t('password')}</label>
              <div className="relative">
                <Lock className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 ${locale === 'ar' ? 'right-3' : 'left-3'}`} style={{ color: 'var(--muted)' }} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full rounded-lg px-10 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${locale === 'ar' ? 'text-right' : ''}`}
                  style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 text-red-500 text-sm">
                {error}
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="rounded" />
                <span>Remember me</span>
              </label>
              <a href="#" className="text-indigo-500 hover:underline">Forgot password?</a>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  {t('login')}
                  <ArrowRight className={`w-4 h-4 ${locale === 'ar' ? 'rotate-180' : ''}`} />
                </>
              )}
            </button>
          </form>

          <p className="text-center mt-6 text-sm" style={{ color: 'var(--muted)' }}>
            {t('noAccount')}{' '}
            <Link href="/register" className="text-indigo-500 hover:underline font-medium">
              {t('register')}
            </Link>
          </p>

          <div className="mt-6 p-3 rounded-lg text-xs text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <strong>Demo:</strong> admin@company.com / admin123
          </div>
        </div>
      </div>
    </div>
  );
}

function Shield({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  );
}
